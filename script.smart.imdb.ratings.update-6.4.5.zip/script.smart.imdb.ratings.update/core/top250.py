# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################


import sys
import os
import xbmcvfs
import re
import xbmcgui, xbmc, xbmcaddon

from support.common import *
from support.httptools import get_page

# FILE Top250.txt WITH TOP250 MOVIES.
# FORMAT MUST BE AS FOLLOW (of course without leading #):
#1|tt0111161
#2|tt0068646
#[...]
#249|tt4430212
#250|tt8108198

addon = xbmcaddon.Addon()
TOP250_URL = "http://top250.info/charts/"
ADDON_DATA_PATH = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
DB_FOLDER = os.path.join(ADDON_DATA_PATH, "db")
LOGS_FOLDER = os.path.join(ADDON_DATA_PATH, "logs")
TIMESTAMP_TOP250_HISTORY_FILE = os.path.join(LOGS_FOLDER, "_top250_html.timestamp.history.log")



def validate_credentials(creds):
    # login:password
    pattern = r"^[^:]+:[^:]+$"
    return re.match(pattern, creds) is not None


def validate_location(location):
    if not location.startswith("//"):
        return False
    if not location.lower().endswith(".txt"):
        return False
    return True


def validate_top250_file(path):
    try:
        with open(path, "r") as f:
            lines = [x.strip() for x in f.readlines() if x.strip()]
        if len(lines) != 250:
            return False
        for idx, line in enumerate(lines, start=1):
            pattern = r"^%d\|tt\d+$" % idx
            if not re.match(pattern, line):
                return False
        return True
    except Exception as e:
        logError("Top250","File validation failed: %s" % str(e))
        return False


def get_local_top250_path(addonSettings):
    return (xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/db/Top250.txt")


def get_remote_top250_path(addonSettings):
    Top250Location = addonSettings.getSetting("Top250Location")
    Top250Authenticate = addonSettings.getSetting("Top250Authenticate")
    Top250Creds = addonSettings.getSetting("Top250Creds")
    # normalize slashes
    Top250Location = Top250Location.replace("\\", "/")
    # =========================
    # VALIDATE LOCATION
    # =========================
    if not validate_location(Top250Location):
        logInfo("Top250","Invalid location")
        xbmcgui.Dialog().ok(addonName, "Top250 file location is invalid.\n\nIt MUST start with // and end with .txt")
        return None
    # =========================
    # LINUX -> NFS
    # =========================
    if sys.platform.startswith("linux"):
        return "nfs:" + Top250Location
    # =========================
    # WINDOWS -> SMB
    # =========================
    elif sys.platform.startswith("win"):
        smb = "smb:" + Top250Location
        # =========================
        # AUTHENTICATION
        # =========================
        if Top250Authenticate == "true":
            if not validate_credentials(Top250Creds):
                logInfo("Top250","Invalid credentials")
                xbmcgui.Dialog().ok(addonName, "Top250 credentials are invalid.\n\nRequired format:\nuser:password")
                return None
            smb = smb.replace(
                "smb://",
                "smb://%s@" % Top250Creds,
                1
            )
        return smb
    return None



def get_remote_mtime():
    try:
        remote_path = get_remote_top250_path(addonSettings)
        if not remote_path:
            return None
        stat = xbmcvfs.Stat(remote_path)
        return stat.st_mtime()
    except Exception as e:
        logError("Top250","Stat failed: %s" % str(e))
        return None

def update_if_needed(addonSettings, db_folder):
    Top250SelectLocation = addonSettings.getSetting("Top250SelectLocation")
    # =========================================================
    # LOCAL MODE
    # =========================================================
    if Top250SelectLocation == "0":
        local_top250 = get_local_top250_path(addonSettings)
        if not xbmcvfs.exists(local_top250):
            logInfo("Top250","Local file missing")
            return
        if not validate_top250_file(local_top250):
            logInfo("Top250","Local file invalid")
            xbmcgui.Dialog().ok(addonName, "Local Top250.txt file is invalid.")
            return
        logInfo("Top250","Local mode: using local file")
        return
    if Top250SelectLocation == "2":
        update_from_html()
        return
    else:
        local_file = os.path.join(db_folder, "Top250.txt")
        temp_file = os.path.join(db_folder, "Top250_temp.txt")
        remote_path = get_remote_top250_path(addonSettings)
        if not remote_path:
            logInfo("Top250","Invalid remote path")
            xbmcgui.Dialog().ok(addonName, "Top250 remote path is invalid or inaccessible.")
            return
        logInfo("Top250","Remote path: %s" % remote_path)
        remote_mtime = get_remote_mtime()
        if not remote_mtime:
            logInfo("Top250","Cannot read remote file")
            return
        local_mtime = addonSettings.getSetting("Top250MTime")
        if str(remote_mtime) == local_mtime and xbmcvfs.exists(local_file):
            logInfo("Top250","Top250 file up to date")
            return
        logInfo("Top250","Updating...")
        try:
            # =========================
            # COPY TO TEMP
            # =========================
            success = xbmcvfs.copy(remote_path, temp_file)
            if not success:
                logInfo("Top250","Top 250 file copy failed")
                if addonSettings.getSetting("Top250Authenticate") == "true":
                    xbmcgui.Dialog().ok(addonName, "Failed to copy Top250 file from remote location.\n\nCheck remote path and credentials.")
                else:
                    xbmcgui.Dialog().ok(addonName, "Failed to copy Top250 file from remote location.")
                return
            # =========================
            # VALIDATE TEMP FILE
            # =========================
            if not validate_top250_file(temp_file):
                logInfo("Top250","Top 250 file validation failed")
                xbmcgui.Dialog().ok(addonName, "Top250 remote file is invalid.\n\nIt MUST contain exactly:\n1|tt0111161\n...\n250|tt1234567")
                if xbmcvfs.exists(temp_file):
                    xbmcvfs.delete(temp_file)
                return
            # =========================
            # REPLACE REAL FILE
            # =========================
            if xbmcvfs.exists(local_file):
                xbmcvfs.delete(local_file)
            xbmcvfs.rename(temp_file, local_file)
            addonSettings.setSetting("Top250MTime", str(remote_mtime))
            logInfo("Top250","Top 250 file updated")
        except Exception as e:
            logError("Top250", "Exception: %s" % str(e))


def update_from_html():
    try:
        logInfo("TOP250HTML", "Downloading data from top250.info")
        (html, status, statusInfo) = get_page(TOP250_URL)
        if status != "OK":
            logError("TOP250HTML", "Failed downloading from HTML source: %s" % statusInfo)
            return False
        if not html:
            logError("TOP250HTML", "Source returned empty page")
            return False
        logInfo("TOP250HTML", "Downloaded (%d chars)" % len(html))
        pattern = re.compile(
            r'<td align="center">(\d+)</td>\s*'
            r'<td align="center">.*?</td>\s*'
            r'<td><a href="/movie/\?(\d+)">',
            re.DOTALL
        )
        matches = pattern.findall(html)
        if len(matches) != 250:
            logError("TOP250HTML", "Source returned %d entries instead of 250" % len(matches))
            return False
        top250 = []
        for rank, imdb_numeric in matches:
            imdb_id = "tt%s" % imdb_numeric
            top250.append("%s|%s" % (rank, imdb_id))
        output_file = os.path.join(DB_FOLDER, "Top250.txt")
        temp_file = output_file + ".tmp"

        timestamp_match = re.search(r'<title>IMDb Top 250 Informer:\s*(.*?)</title>', html)
        if timestamp_match:
            source_timestamp = timestamp_match.group(1).strip()
            logInfo("TOP250HTML", "Source timestamp: %s" % source_timestamp)
            append_html_timestamp_history(source_timestamp)
        else:
            logError("TOP250HTML", "Failed to extract source timestamp")

        with open(temp_file, "w") as f:
            f.write("\n".join(top250))
        if xbmcvfs.exists(output_file):
            xbmcvfs.delete(output_file)
        xbmcvfs.rename(temp_file, output_file)
        logInfo("TOP250HTML", "File updated: %d entries" % len(top250))
        logInfo("TOP250HTML", "Top250 sample (for quick verification): first=%s last=%s" % (top250[0], top250[-1]))
        return True

    except Exception as e:
        logError("TOP250HTML", "Update failed: %s" % str(e))
        return False


def append_html_timestamp_history(source_timestamp):
    try:
        # Check last logged entry
        if xbmcvfs.exists(TIMESTAMP_TOP250_HISTORY_FILE):
            with open(TIMESTAMP_TOP250_HISTORY_FILE, "r", encoding="utf-8") as f:
                lines = f.readlines()
            if lines:
                last_line = lines[-1].strip()
                if " - " in last_line:
                    last_timestamp = last_line.split(" - ", 1)[1]
                    if last_timestamp == source_timestamp:
                        return
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(TIMESTAMP_TOP250_HISTORY_FILE, "a", encoding="utf-8") as f:
            f.write("%s - %s\n" % (timestamp, source_timestamp))
    except Exception as e:
        logError("TOP250", "Failed to update timestamp history: %s" % str(e))