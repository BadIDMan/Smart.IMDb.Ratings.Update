# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc, xbmcgui
import json as jSon

from datetime import datetime, timedelta
from support.common import *
from _thread import start_new_thread, allocate_lock
from support.httptools import wait_for_internet
from core.imdb_scraper import parse_IMDb_page, parse_IMDbAPI_page
from core.tmdb_api import get_TMDB_rating
from core.tmdb_api import get_TMDB_ID_from_TVDB
from core.tmdb_api import get_IMDb_ID_from_TMDb
from core.tmdb_api import search_TMDB_by_title
from core.tmdb_api import get_TVDB_episode_ID_from_TMDB
from core.tmdb_api import get_TMDB_episode_ID_from_IMDb
from core.tmdb_api import get_TMDB_movie_ID_from_IMDb
from core.tmdb_api import get_TMDB_tvshow_ID_from_IMDb
from core.imdb_dataset import get_local_rating
from core.top250 import get_local_top250_path
from core.tvdb_api import GetTVDBEpisodeIMDbID


max_threads = int(NumberOfThreads) - 1    #0 - 1 thread, 1 - 2 threads ...
num_threads = 0



def get_episode_number(episodeid):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0",'
            '"method":"VideoLibrary.GetEpisodeDetails",'
            '"params":{"episodeid":%d,"properties":["episode"]},'
            '"id":1}'
        ) % episodeid
        result = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        return result["result"]["episodedetails"]["episode"]
    except:
        return None


def get_tvshow_tmdb_id(tvshowid):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0",'
            '"method":"VideoLibrary.GetTVShowDetails",'
            '"params":{"tvshowid":%d,"properties":["uniqueid"]},'
            '"id":1}'
        ) % tvshowid
        result = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        unique_id = (result["result"]["tvshowdetails"].get("uniqueid", {}))
        return unique_id.get("tmdb")
    except Exception as e:
        logError("UPDATE", "get_tvshow_tmdb_id failed: %s" % str(e))
        return None


def doUpdateEpisodesBySeason(tvshowid, IMDb, season, progress, percentage, flock, source_override=None):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
            '"params":{"tvshowid":%d,'
            '"season":%d,'
            '"properties":["uniqueid","episode","season","showtitle"],'
            '"sort":{"method":"episode"}},'
            '"id":1}'
        ) % (tvshowid, season)

        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        episodes = jSonResponse.get("result", {}).get("episodes", [])
        total = len(episodes)
        count = 0
        lock = allocate_lock()
        for item in episodes:
            episodeid = item.get("episodeid")
            season_num = item.get("season")
            episode_num = "%02d" % item.get("episode")
            title = (
                item.get("showtitle")
                + " "
                + str(season_num)
                + "x"
                + episode_num
            )
            unique_id = item.get("uniqueid", {})
            IMDb = unique_id.get("imdb")
            TVDB = unique_id.get("tvdb")
            TMDB = unique_id.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(
                IMDb,
                TVDB,
                TMDB
            )
            count += 1
            current_percentage = int(
                (count / float(total)) * 100
            ) if total > 0 else 100
            if ShowProgress == "true":
                progress.update(
                    current_percentage,
                    get_progress_title(source_override),
                    "%s (%d/%d)"
                    % (title, count, total)
                )
            thread_parse_IMDb_page(
                "episode",
                episodeid,
                IMDb,
                TVDB,
                TMDB,
                title,
                season_num,
                tvshowid,
                progress,
                current_percentage,
                lock,
                flock,
                source_override
            )
    except Exception as e:
        logError("Season", "Season update exception: %s" % str(e))
    return


def get_tvshow_IMDb_ID(updateitem, tvshowid, TVDB, TMDB, Title):
    IMDb = None
    if updateitem != "tvshow":
        TVDB = None; TMDB = None
        jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"properties":["uniqueid","title"]},"id":1}'
        jSonResponse = xbmc.executeJSONRPC( jSonQuery )
        jSonResponse = jSon.loads( jSonResponse )
        item = jSonResponse['result']['tvshowdetails']
        Title = item.get('title')
        unique_id = item.get('uniqueid')
        if unique_id != None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
    sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
    statusInfo = "Method get_tvshow_IMDb_ID - " + Title + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: "+ sTMDB + ")"
    if IMDb == None:
        (IMDb, add_statusInfo) = get_IMDb_ID_from_TMDb("tvshow", TMDB)
        statusInfo = statusInfo + "\n" + add_statusInfo
        if IMDb == None:
            return(None, statusInfo)
        else:
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"uniqueid": {"imdb": "' + IMDb + '"}},"id":1}'
            jSonResponse = xbmc.executeJSONRPC( jSonQuery )
    return (IMDb, "OK")

def thread_parse_IMDb_page(updateitem, updateitem_id, IMDb, TVDB, TMDB, title, season, tvshowid, progress, percentage, lock, flock, source_override=None):
    global LocalIMDbSQL
    global IMDbSource

    if DebugLog == "true":
        logDebug("UPDATE", "=== START thread === %s | ID=%s | IMDb=%s | TVDB=%s | TMDB=%s | season=%s | tvshowid=%s" % (updateitem, updateitem_id, IMDb, TVDB, TMDB, season, tvshowid))
    # -------------------------------------------------
    # CONTEXT SOURCE OVERRIDE
    # -------------------------------------------------
    if DebugLog == "true":
        logDebug("UPDATE", "Source override BEFORE: LocalIMDbSQL=%s IMDbSource=%s" % (LocalIMDbSQL, IMDbSource))
    if source_override == "api":
        LocalIMDbSQL = False
        IMDbSource = 0
    elif source_override == "dataset":
        LocalIMDbSQL = True
        IMDbSource = 0
    elif source_override == "html":
        LocalIMDbSQL = False
        IMDbSource = 1
    if DebugLog == "true":
        logDebug("UPDATE", "Source override AFTER: LocalIMDbSQL=%s IMDbSource=%s" % (LocalIMDbSQL, IMDbSource))
    fallback_chain = []
    global num_threads
    provider = None
    updatedRating = None
    updatedVotes = None
    updatedTop250 = 0
    statusInfo = ""
    if updateitem in ("movie", "tvshow", "episode"):
        if DebugLog == "true":
            logDebug("UPDATE", "Enter main processing block")

        # =========================================================
        # PRIORITY 0.5 - LOCAL IMDb DATASET first
        # =========================================================
        if IMDb and LocalIMDbSQL:
            if DebugLog == "true":
                logDebug("UPDATE", "[P0.5] IMDb=%s LocalIMDbSQL=%s" % (IMDb, LocalIMDbSQL))
                logDebug("UPDATE", "[P0.5] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season))
            try:
                if DebugLog == "true":
                    logDebug("UPDATE", "[P0.5] Using dataset for querying IMDb=%s" % IMDb)
                (updatedRating, updatedVotes) = get_local_rating(IMDb)
                if DebugLog == "true":
                    logDebug("UPDATE", "[P0.5] Dataset result: rating=%s votes=%s" % (updatedRating, updatedVotes))
                if updatedRating is not None:
                    provider = "imdb"
                    statusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (updatedRating, updatedVotes)
                    if updateitem == "movie":
                        updatedTop250 = get_top250_rank(IMDb)
                    else:
                        updatedTop250 = 0
            except Exception as e:
                logError("Update", "[P0.5] Exception: %s" % str(e))
                updatedRating = None
                statusInfo = "Local IMDb lookup error: %s" % str(e)
        # ============================================================================================================
        # PRIORITY 0.6 - Recover TMDB IDs for TV shows, episodes, movies from IMDb ID and episode TVDB ID from TMDB ID
        # ============================================================================================================
        if IMDb:
            try:
                # ---------------------------------------------------
                # Step 1: Recovery episode TVDB ID from TMDB ID
                # ---------------------------------------------------
                if updateitem == "episode" and not TVDB and TMDB:
                    if DebugLog == "true":
                        logDebug("UPDATE", "[P0.6] [S1] Recovering TVDB episode from TMDB =%s" % TMDB)
                    episode_num = get_episode_number(updateitem_id)
                    tvshow_tmdb = get_tvshow_tmdb_id(tvshowid)
                    if DebugLog == "true":
                        logDebug("UPDATE", "[P0.6] [S1] Recovery lookups results: episode=%s tvshow_tmdb=%s" % (episode_num, tvshow_tmdb))
                    recovered_tvdb = get_TVDB_episode_ID_from_TMDB(tvshow_tmdb, season, episode_num)
                    if recovered_tvdb:
                        jSonQuery = (
                            '{"jsonrpc":"2.0",'
                            '"method":"VideoLibrary.SetEpisodeDetails",'
                            '"params":{"episodeid":%d,'
                            '"uniqueid":{"tvdb":"%s"}},'
                            '"id":1}'
                        ) % (
                            updateitem_id,
                            recovered_tvdb
                        )
                        xbmc.executeJSONRPC(jSonQuery)
                        logInfo("Update", "[P0.6] Recovered missing TVDB episode ID %s from TMDB ID %s" % (recovered_tvdb, TMDB))
                # ---------------------------------------------------
                # Step 2: Recovery episode TMDB ID from IMDb ID
                # ---------------------------------------------------
                if updateitem == "episode" and not TMDB and IMDb:
                    if DebugLog == "true":
                        logDebug("UPDATE", "[P0.6][S2] Recovering TMDB episode ID from IMDb=%s" % IMDb)
                    recovered_tmdb = get_TMDB_episode_ID_from_IMDb(IMDb)
                    if DebugLog == "true":
                        logDebug("UPDATE", "[P0.6][S2] TMDB lookup result=%s" % recovered_tmdb)
                    if recovered_tmdb:
                        jSonQuery = (
                            '{"jsonrpc":"2.0",'
                            '"method":"VideoLibrary.SetEpisodeDetails",'
                            '"params":{"episodeid":%d,'
                            '"uniqueid":{"tmdb":"%s"}},'
                            '"id":1}'
                        ) % (
                            updateitem_id,
                            recovered_tmdb
                        )
                        xbmc.executeJSONRPC(jSonQuery)
                        logInfo("Update", "[P0.6] Recovered missing TMDB episode ID %s from IMDb ID %s" % (recovered_tmdb, IMDb))
                # ---------------------------------------------------
                # Step 3: Recovery movie TMDB ID from IMDb ID
                # ---------------------------------------------------
                if updateitem == "movie" and not TMDB and IMDb:
                    if DebugLog == "true":
                        logDebug("UPDATE", "[P0.6][S3] Recovering TMDB movie ID from IMDb=%s" % IMDb)
                    recovered_movie_tmdb = get_TMDB_movie_ID_from_IMDb(IMDb)
                    if DebugLog == "true":
                        logDebug("UPDATE", "[P0.6][S3] TMDB lookup result=%s" % recovered_movie_tmdb)
                    if recovered_movie_tmdb:
                        jSonQuery = (
                            '{"jsonrpc":"2.0",'
                            '"method":"VideoLibrary.SetMovieDetails",'
                            '"params":{"movieid":%d,'
                            '"uniqueid":{"tmdb":"%s"}},'
                            '"id":1}'
                        ) % (
                            updateitem_id,
                            recovered_movie_tmdb
                        )
                        xbmc.executeJSONRPC(jSonQuery)
                        logInfo("Update", "[P0.6] Recovered missing TMDB movie ID %s from IMDb ID %s" % (recovered_movie_tmdb, IMDb))
                # ---------------------------------------------------
                # Step 4: Recovery TV show TMDB ID from IMDb ID
                # ---------------------------------------------------
                if updateitem == "tvshow" and not TMDB and IMDb:
                    if DebugLog == "true":
                        logDebug("UPDATE", "[P0.6][S4] Recovering TMDB TV show ID from IMDb=%s" % IMDb)
                    recovered_tvshow_tmdb = get_TMDB_tvshow_ID_from_IMDb(IMDb)
                    if DebugLog == "true":
                        logDebug("UPDATE", "[P0.6][S4] TMDB lookup result=%s" % recovered_tvshow_tmdb)
                    if recovered_tvshow_tmdb:
                        jSonQuery = (
                            '{"jsonrpc":"2.0",'
                            '"method":"VideoLibrary.SetTVShowDetails",'
                            '"params":{"tvshowid":%d,'
                            '"uniqueid":{"tmdb":"%s"}},'
                            '"id":1}'
                        ) % (
                            updateitem_id,
                            recovered_tvshow_tmdb
                        )
                        xbmc.executeJSONRPC(jSonQuery)
                        logInfo("Update", "[P0.6] Recovered missing TMDB TV Show ID %s from IMDb ID %s" % (recovered_tvshow_tmdb, IMDb))
            except Exception as e:
                logError("Update", "[P0.6] Exception: %s" % str(e))



        # =========================================================
        # PRIORITY 1 - IMDb transport
        # =========================================================
        if IMDb and updatedRating is None and not LocalIMDbSQL:
            if DebugLog == "true":
                logDebug("UPDATE", "[P1] IMDb=%s updatedRating=%s LocalIMDbSQL=%s" % (IMDb, updatedRating, LocalIMDbSQL))
                logDebug("UPDATE", "[P1] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season))
            try:
                if DebugLog == "true":
                    logDebug("UPDATE", "[P1] Using transport source=%s" % source_override)
                if IMDbSource == 0:
                    (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDbAPI_page(IMDb)
                    if updatedRating is None:
                        statusInfo = "(failure fetching rating from imdbapi.dev)"
                else:
                    (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
                if DebugLog == "true":
                    logDebug("UPDATE", "[P1] Result: rating=%s votes=%s" % (updatedRating, updatedVotes))
                if updatedRating is not None:
                    provider = "imdb"
                    if updateitem == "movie":
                        updatedTop250 = get_top250_rank(IMDb)
                    else:
                        updatedTop250 = 0
            except Exception as e:
                logError("Update", "[P1] Exception: %s" % str(e))
                updatedRating = None
                statusInfo = "IMDb transport error: %s" % str(e)

        # =========================================================
        # PRIORITY 1.5 - broken IMDb
        # =========================================================
        if updateitem in ("movie", "tvshow") and IMDb and updatedRating is None and source_override is None:
            if DebugLog == "true":
                logDebug("UPDATE", "[P1.5] IMDb=%s updatedRating=%s" % (IMDb, updatedRating))
                logDebug("UPDATE", "[P1.5] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season))
            try:
                # Remove broken IMDb ID from Kodi DB
                if updateitem == "movie":
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                        '"params":{"movieid":%d,"uniqueid":{"imdb":""}},"id":1}'
                    ) % updateitem_id
                else:
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails",'
                        '"params":{"tvshowid":%d,"uniqueid":{"imdb":""}},"id":1}'
                    ) % updateitem_id
                xbmc.executeJSONRPC(jSonQuery)
                fallback_chain.append("Broken IMDb ID -> Resolver")
                IMDb = None
            except Exception as e:
                logError("Update", "[P1.5] Failed clearing broken IMDb ID: %s" % str(e))
            if DebugLog == "true":
                logDebug("Update", "[P1.5] Clearing broken IMDb ID")

        # =========================================================
        # PRIORITY 2: Episode derivation using TMDB (WAF-proof)
        # =========================================================
        if updateitem == "episode" and updatedRating is None and source_override is None:
            if DebugLog == "true":
                logDebug("Update", "[P2] ENTER episode derivation (TMDB mode)")
                logDebug("Update", "[P2] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season))
            try:
                # --------------------------------------------
                # Step 1: Get TV show details
                # --------------------------------------------
                if DebugLog == "true":
                    logDebug("Update", "[P2] Query TVShowDetails tvshowid=%s" % tvshowid)
                tvshowdetails = xbmc.executeJSONRPC(json.dumps({
                    "jsonrpc": "2.0",
                    "method": "VideoLibrary.GetTVShowDetails",
                    "params": {
                        "tvshowid": tvshowid,
                        "properties": ["uniqueid"]
                    },
                    "id": 1
                }))
                tvshowdetails = json.loads(tvshowdetails).get("result", {}).get("tvshowdetails", {})
                if DebugLog == "true":
                    logDebug("Update", "[P2] tvshowdetails=%s" % tvshowdetails)
                unique_ids = tvshowdetails.get("uniqueid", {})
                show_tmdb = unique_ids.get("tmdb")
                show_imdb = unique_ids.get("imdb")
                if DebugLog == "true":
                    logDebug("Update", "[P2] show_tmdb=%s show_imdb=%s" % (show_tmdb, show_imdb))
                # --------------------------------------------
                # Step 2: REQUIRE TMDB ID
                # --------------------------------------------
                if not show_tmdb:
                    if DebugLog == "true":
                        logDebug("Update", "[P2] Missing TMDB ID -> cannot resolve episode IMDb")
                else:
                    # --------------------------------------------
                    # Step 3: Get episode number (CRITICAL)
                    # --------------------------------------------
                    ep_details = xbmc.executeJSONRPC(json.dumps({
                        "jsonrpc": "2.0",
                        "method": "VideoLibrary.GetEpisodeDetails",
                        "params": {
                            "episodeid": updateitem_id,
                            "properties": ["season", "episode"]
                        },
                        "id": 1
                    }))
                    ep_details = json.loads(ep_details).get("result", {}).get("episodedetails", {})
                    ep_season = ep_details.get("season")
                    ep_number = ep_details.get("episode")
                    if DebugLog == "true":
                        logDebug("Update", "[P2] episode S%sE%s" % (ep_season, ep_number))
                    if ep_season is None or ep_number is None:
                        if DebugLog == "true":
                            logDebug("Update", "[P2] Missing episode/season info")
                    else:
                        # --------------------------------------------
                        # Step 4: Resolve IMDb ID via TMDB
                        # --------------------------------------------
                        (ep_imdb_id, status) = get_IMDb_ID_from_TMDb(
                            "episode",
                            show_tmdb,
                            ep_season,
                            ep_number
                        )
                        if DebugLog == "true":
                            logDebug("Update", "[P2] TMDB -> IMDb imdb_id=%s status=%s" % (ep_imdb_id, status))
                        # --------------------------------------------
                        # Step 5: VALIDATE + FETCH RATING
                        # --------------------------------------------
                        if ep_imdb_id:
                            testRating = None
                            testVotes = None
                            testTop250 = 0
                            testStatusInfo = ""
                            if LocalIMDbSQL:
                                if DebugLog == "true":
                                    logDebug("Update", "[P2] Resolved IMDb=%s -> querying dataset" % ep_imdb_id)
                                (testRating, testVotes) = get_local_rating(ep_imdb_id)
                                if testRating is not None:
                                    testTop250 = 0
                                    testStatusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (testRating, testVotes)
                            if testRating is None:
                                if DebugLog == "true":
                                    logDebug("Update", "[P2] No Rating found. Using fallback strategy")
                                if IMDbSource == 0:
                                    (testRating, testVotes, testTop250, testStatusInfo) = parse_IMDbAPI_page(ep_imdb_id)
                                    if testRating is None:
                                        testStatusInfo = "(failure fetching rating from imdbapi or localset)"
                                        if DebugLog == "true":
                                            logDebug("Update", "[P2] No Rating found in IMDbAPI")
                                else:
                                    (testRating, testVotes, testTop250, testStatusInfo) = parse_IMDb_page(ep_imdb_id)
                            if DebugLog == "true":
                                logDebug("Update", "[P2] Dataset result: rating=%s votes=%s" % (testRating, testVotes))
                            # -------------------------------------------------
                            # ONLY NOW WRITE IMDb ID BACK TO KODI
                            # -------------------------------------------------
                            if testRating is not None:
                                if DebugLog == "true":
                                    logDebug("Update", "[P2][WRITE] episodeid=%s imdb=%s rating=%s votes=%s" % (updateitem_id, ep_imdb_id, testRating, testVotes))
                                jSonQuery = (
                                    '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails",'
                                    '"params":{"episodeid":%d,"uniqueid":{"imdb":"%s"}},"id":1}'
                                ) % (updateitem_id, ep_imdb_id)
                                xbmc.executeJSONRPC(jSonQuery)
                                IMDb = ep_imdb_id
                                updatedRating = testRating
                                updatedVotes = testVotes
                                updatedTop250 = testTop250
                                statusInfo = testStatusInfo
                                provider = "imdb"
                                if "TMDB -> Episode IMDb" not in fallback_chain:
                                    fallback_chain.append("TMDB -> Episode IMDb")
                            else:
                                if DebugLog == "true":
                                    logDebug("Update", "[P2] No rating found for %s (%s)" % (ep_imdb_id, testStatusInfo))
                                statusInfo = testStatusInfo
                        else:
                            if DebugLog == "true":
                                logDebug("Update", "[P2] TMDB did not return IMDb ID (%s)" % status)
            except Exception as e:
                logError("Update", "[P2] Exception: %s" % str(e))

        # ===========================================
        # PRIORITY 2.5: Episode derivation using TVDB
        # ===========================================
        if updateitem == "episode" and updatedRating is None and source_override is None:
            if DebugLog == "true":
                logDebug("Update", "[P2.5] ENTER episode derivation (TVDB mode)")
            try:
                if not TVDB:
                    if DebugLog == "true":
                        logDebug("Update", "[P2.5] Missing TVDB episode ID")
                else:
                    if DebugLog == "true":
                        logDebug("Update", "[P2.5] Query TVDB episode id=%s" % TVDB)
                    ep_imdb_id = GetTVDBEpisodeIMDbID(TVDB)
                    if DebugLog == "true":
                        logDebug("Update", "[P2.5] TVDB -> IMDb imdb_id=%s" % ep_imdb_id)
                    if ep_imdb_id:
                        testRating = None
                        testVotes = None
                        testTop250 = 0
                        testStatusInfo = ""
                        if LocalIMDbSQL:
                            (testRating, testVotes) = get_local_rating(ep_imdb_id)
                            if testRating is not None:
                                testStatusInfo = ("Rating: %s, Votes: %s (Local IMDb dataset)" % (testRating, testVotes))
                        if testRating is None:
                            if IMDbSource == 0:
                                (testRating, testVotes, testTop250, testStatusInfo) = parse_IMDbAPI_page(ep_imdb_id)
                            else:
                                (testRating, testVotes, testTop250, testStatusInfo) = parse_IMDb_page(ep_imdb_id)
                        if testRating is not None:
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails",'
                                '"params":{"episodeid":%d,"uniqueid":{"imdb":"%s"}},"id":1}'
                            ) % (updateitem_id, ep_imdb_id)
                            xbmc.executeJSONRPC(jSonQuery)
                            IMDb = ep_imdb_id
                            updatedRating = testRating
                            updatedVotes = testVotes
                            updatedTop250 = testTop250
                            statusInfo = testStatusInfo
                            provider = "imdb"
                            if "TVDB -> Episode IMDb" not in fallback_chain:
                                fallback_chain.append("TVDB -> Episode IMDb")
                            if DebugLog == "true":
                                logDebug("Update", "[P2.5] SUCCESS IMDb=%s rating=%s votes=%s" % (ep_imdb_id, testRating, testVotes))
            except Exception as e:
                logError("Update", "[P2.5] Exception: %s" % str(e))

        # =========================================================
        # PRIORITY 3 - RECOVER IMDb FROM TMDB (MOVIE/TVSHOW)
        # =========================================================
        if updateitem in ("movie", "tvshow") and updatedRating is None and TMDB and TMDB != "0" and not IMDb and source_override is None:
            if DebugLog == "true":
                logDebug("Update", "[P3] ENTER movie/tvshow derivation (TMDB mode)")
                logDebug("Update", "[P3] INPUT updateitem=%s TMDB=%s IMDb=%s updatedRating=%s" % (updateitem, TMDB, IMDb, updatedRating))
            recovered_imdb, imdbStatus = get_IMDb_ID_from_TMDb(updateitem, TMDB)
            if DebugLog == "true":
                logDebug("Update", "[P3] TMDB -> IMDb result imdb=%s status=%s" % (recovered_imdb, imdbStatus))
            if recovered_imdb:
                IMDb = recovered_imdb
                fallback_chain.append("TMDB->IMDb")
                if DebugLog == "true":
                    logDebug("Update", "[P3] Writing IMDb=%s back to Kodi" % IMDb)
                # Write IMDb back to Kodi
                if updateitem == "movie":
                    jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":%d,"uniqueid":{"imdb":"%s"}},"id":1}' % (updateitem_id, IMDb)
                else:
                    jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":%d,"uniqueid":{"imdb":"%s"}},"id":1}' % (updateitem_id, IMDb)
                if DebugLog == "true":
                    logDebug("Update", "[P3] JSONRPC=%s" % jSonQuery)
                xbmc.executeJSONRPC(jSonQuery)
                try:
                    if DebugLog == "true":
                        logDebug("Update", "[P3] Fetch rating for IMDb=%s LocalIMDbSQL=%s" % (IMDb, LocalIMDbSQL))
                    # -------------------------------------------------
                    # LOCAL DATASET FIRST (if enabled)
                    # -------------------------------------------------
                    if LocalIMDbSQL:
                        (updatedRating, updatedVotes) = get_local_rating(IMDb)
                        if DebugLog == "true":
                            logDebug("Update", "[P3] Local dataset result rating=%s votes=%s" % (updatedRating, updatedVotes))
                        if updatedRating is not None:
                            provider = "imdb"
                            if updateitem == "movie":
                                updatedTop250 = get_top250_rank(IMDb)
                            else:
                                updatedTop250 = 0
                            statusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (updatedRating, updatedVotes)
                    # -------------------------------------------------
                    # FALLBACK TO IMDb TRANSPORT
                    # -------------------------------------------------
                    if updatedRating is None:
                        if DebugLog == "true":
                            logDebug("Update", "[P3] Falling back to IMDb transport =%s" % source_override)
                        if IMDbSource == 0:
                            (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDbAPI_page(IMDb)
                            if updatedRating is None:
                                statusInfo = "(failure fetching rating from imdbapi or localset)"
                        else:
                            (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
                        if DebugLog == "true":
                            logDebug("Update", "[P3] Transport result rating=%s votes=%s top250=%s" % (updatedRating, updatedVotes, updatedTop250))
                        if updatedRating is not None:
                            provider = "imdb"
                            if updateitem == "movie":
                                updatedTop250 = get_top250_rank(IMDb)
                            else:
                                updatedTop250 = 0
                except Exception as e:
                    logError("Update", "[P3] Exception during rating fetch: %s" % str(e))
                    updatedRating = None
            else:
                if DebugLog == "true":
                    logDebug("Update", "[P3] No IMDb recovered from TMDB")

        # =========================================================
        # PRIORITY 3.5 - TITLE + YEAR -> TMDB -> IMDb (NO IDs CASE)
        # =========================================================
        if updateitem == "movie" and updatedRating is None and not IMDb and not TMDB and source_override is None:
            if DebugLog == "true":
                logDebug("Update", "[P3.5] ENTER movie derivation from title + year")
                logDebug("Update", "[P3.5] INPUT title=%s id=%s" % (title, updateitem_id))
            try:
                # Get year from Kodi DB
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails",'
                    '"params":{"movieid":%d,"properties":["year"]},"id":1}'
                ) % updateitem_id
                if DebugLog == "true":
                    logDebug("Update", "[P3.5] JSONRPC year query=%s" % jSonQuery)
                jSonResponse = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
                moviedetails = jSonResponse.get("result", {}).get("moviedetails", {})
                movie_year = moviedetails.get("year")
                if DebugLog == "true":
                    logDebug("Update", "[P3.5] Extracted year=%s" % movie_year)
                resolved_tmdb, resolve_method = search_TMDB_by_title("movie", title, movie_year, updateitem_id)
                if DebugLog == "true":
                    logDebug("Update", "[P3.5] TMDB search result tmdb=%s method=%s" % (resolved_tmdb, resolve_method))
                if resolved_tmdb:
                    TMDB = str(resolved_tmdb)
                    if DebugLog == "true":
                        logDebug("Update", "[P3.5] Writing TMDB=%s to Kodi" % TMDB)
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                        '"params":{"movieid":%d,"uniqueid":{"tmdb":"%s"}},"id":1}'
                    ) % (updateitem_id, TMDB)
                    xbmc.executeJSONRPC(jSonQuery)
                    recovered_imdb, imdbStatus = get_IMDb_ID_from_TMDb("movie", TMDB)
                    if DebugLog == "true":
                        logDebug("Update", "[P3.5] TMDB -> IMDb imdb=%s status=%s" % (recovered_imdb, imdbStatus))
                    if recovered_imdb:
                        IMDb = recovered_imdb
                        if DebugLog == "true":
                            logDebug("Update", "[P3.5] Writing IMDb=%s to Kodi" % IMDb)
                        jSonQuery = (
                            '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                            '"params":{"movieid":%d,"uniqueid":{"imdb":"%s"}},"id":1}'
                        ) % (updateitem_id, IMDb)
                        xbmc.executeJSONRPC(jSonQuery)
                        if resolve_method == "Title+Year":
                            fallback_chain.append("Title + Year -> TMDB")
                        elif resolve_method == "Title+Year+Director":
                            fallback_chain.append("Title + Year + Director -> TMDB")
                        fallback_chain.append("TMDB -> IMDb")
                        if DebugLog == "true":
                            logDebug("Update", "[P3.5] Fetch rating for IMDb=%s" % IMDb)
                        # -------------------------------------------------
                        # LOCAL DATASET FIRST (if enabled)
                        # -------------------------------------------------
                        if LocalIMDbSQL:
                            (updatedRating, updatedVotes) = get_local_rating(IMDb)
                            if DebugLog == "true":
                                logDebug("Update", "[P3.5] Local dataset result rating=%s votes=%s" % (updatedRating, updatedVotes))
                            if updatedRating is not None:
                                provider = "imdb"
                                if updateitem == "movie":
                                    updatedTop250 = get_top250_rank(IMDb)
                                else:
                                    updatedTop250 = 0
                                statusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (updatedRating, updatedVotes)
                        # -------------------------------------------------
                        # FALLBACK TO IMDb TRANSPORT
                        # -------------------------------------------------
                        if updatedRating is None:
                            if DebugLog == "true":
                                logDebug("Update", "[P3.5] Falling back to IMDb transport =%s" % source_override)
                            if IMDbSource == 0:
                                (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDbAPI_page(IMDb)
                                if updatedRating is None:
                                    statusInfo = "(failure fetching rating from imdbapi or localset)"
                            else:
                                (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
                            if DebugLog == "true":
                                logDebug("Update", "[P3.5] Transport result rating=%s votes=%s" % (updatedRating, updatedVotes))
                            if updatedRating is not None:
                                provider = "imdb"
                                if updateitem == "movie":
                                    updatedTop250 = get_top250_rank(IMDb)
                                else:
                                    updatedTop250 = 0
            except Exception as e:
                logError("Update", "[P3.5] Exception: %s" % str(e))
                updatedRating = None

        # =========================================================
        # PRIORITY 4 - TMDB FALLBACK (ONLY IF IMDb IMPOSSIBLE)
        # =========================================================
        if updatedRating is None and not IMDb and source_override is None:
            if DebugLog == "true":
                logDebug("Update", "[P4] Get ratings from TMDB - IMDb not resolved)")
                logDebug("Update", "[P4] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season))
            try:
                # -------------------------------------------------
                # MOVIE / TVSHOW
                # -------------------------------------------------
                if updateitem in ("movie", "tvshow") and TMDB and TMDB != "0":
                    if DebugLog == "true":
                        logDebug("Update", "[P4] Fetch TMDB rating for %s id=%s" % (updateitem, TMDB))
                    (updatedRating, updatedVotes, statusInfo) = get_TMDB_rating(updateitem, TMDB)
                    if DebugLog == "true":
                        logDebug("Update", "[P4] TMDB result rating=%s votes=%s status=%s" % (updatedRating, updatedVotes, statusInfo))
                    # ---------------------------------------------------------------------------------------------------
                    # INVALID TMDB ID (404)
                    # ---------------------------------------------------------------------------------------------------
                    if updatedRating is None and statusInfo and "404" in statusInfo:
                        if DebugLog == "true":
                            logDebug("Update", "[P4] TMDB returned 404 - marking as neutral")
                        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
                        flock.acquire()
                        try:
                            statusLog(
                                title +
                                " (IMDb ID: " + sIMDb +
                                ", TVDB ID: " + sTVDB +
                                ", TMDB ID: " + sTMDB +
                                ")  --> (Invalid TMDB ID. Marking as neutral)"
                            )
                        finally:
                            flock.release()
                        if updateitem == "movie":
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                                '"params":{"movieid":%d,"uniqueid":{"tmdb":"0"}},"id":1}'
                            ) % updateitem_id
                        else:
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails",'
                                '"params":{"tvshowid":%d,"uniqueid":{"tmdb":"0"}},"id":1}'
                            ) % updateitem_id
                        xbmc.executeJSONRPC(jSonQuery)
                        TMDB = "0"
                        updatedRating = None
                        provider = None
                    # -------------------------------------------------
                    # VALID TMDB RATING
                    # -------------------------------------------------
                    elif updatedRating is not None:
                        if DebugLog == "true":
                            logDebug("Update", "[P4] Using TMDB rating")
                        provider = "tmdb"
                        updatedTop250 = 0
                        fallback_chain.append("TMDB rating")
                # -------------------------------------------------
                # EPISODE (use show TMDB)
                # -------------------------------------------------
                elif updateitem == "episode" and tvshowid:
                    if DebugLog == "true":
                        logDebug("Update", "[P4] Episode fallback using show TMDB")
                    show_tmdb = None
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                        '"params":{"tvshowid":%d,"properties":["uniqueid"]},"id":1}'
                    ) % tvshowid
                    jSonResponse = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
                    tvshowdetails = jSonResponse.get("result", {}).get("tvshowdetails", {})
                    unique_id = tvshowdetails.get("uniqueid")
                    if unique_id:
                        show_tmdb = unique_id.get("tmdb")
                    if DebugLog == "true":
                        logDebug("Update", "[P4] show_tmdb=%s" % show_tmdb)
                    if show_tmdb:
                        ep_number = int(title.split("x")[-1])
                        if DebugLog == "true":
                            logDebug("Update", "[P4] Fetch TMDB episode rating S%sE%s" % (season, ep_number))
                        (updatedRating, updatedVotes, statusInfo) = get_TMDB_rating(
                            "episode",
                            show_tmdb,
                            season,
                            ep_number
                        )
                        if DebugLog == "true":
                            logDebug("Update", "[P4] Episode TMDB result rating=%s votes=%s status=%s" % (updatedRating, updatedVotes, statusInfo))
                        if updatedRating is not None:
                            provider = "tmdb"
                            fallback_chain.append("Episode -> ShowTMDB")
            except Exception as e:
                logError("Update", "[P4] Exception: %s" % str(e))
                updatedRating = None
                statusInfo = "TMDB parse error: %s" % str(e)

        # =========================================================
        # LOGGING
        # =========================================================
        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
        if updatedRating is not None:
            statusInfo = "Rating: %s, Votes: %s" % (updatedRating, updatedVotes)
            if fallback_chain:
                statusInfo += " (fallback: " + " -> ".join(fallback_chain) + ")"
        flock.acquire()
        try:
            statusLog(
                title +
                " (IMDb ID: " + sIMDb +
                ", TVDB ID: " + sTVDB +
                ", TMDB ID: " + sTMDB +
                ")  --> " + (statusInfo if statusInfo else "(no rating resolved - possible outdated or incorrect IDs in Kodi database or no rating for this item)")
            )
        finally:
            flock.release()

        # =========================================================
        # WRITE RATING TO KODI
        # =========================================================
        if updatedRating is not None and provider:
            rating_block = (
                '"ratings":{"' + provider + '":{"rating":' +
                str(updatedRating) +
                ',"votes":' +
                str(updatedVotes).replace(",", "") +
                ',"default":true}}'
            )
            if updateitem == "movie":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":%d,%s,"top250":%d},"id":1}' % (updateitem_id, rating_block, updatedTop250)
            elif updateitem == "tvshow":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":%d,%s},"id":1}' % (updateitem_id, rating_block)
            elif updateitem == "episode":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":%d,%s},"id":1}' % (updateitem_id, rating_block)
            xbmc.executeJSONRPC(jSonQuery)
    elif updateitem == "season":
        doUpdateEpisodesBySeason(updateitem_id, IMDb, season, progress, percentage, flock, source_override)

    lock.acquire()
    num_threads -= 1
    lock.release()


class Movies:
    def __init__(self):
        self.lock = allocate_lock()
        self.flock = allocate_lock()

    def doUpdate(self):
        self.AllMovies = []
        self.getDBMovies()
        if len( self.AllMovies ) == 0:
            xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32840) )
            return
        if ShowNotifications == "true":
            doNotify( addonLanguage(32255), 5000 )
            xbmc.sleep(5000)
        statusLog("---------------------------------------------------")
        statusLog("---> Scheduled/autostart ratings update for movies started")
        if addonSettings.getSetting("FullRefreshMode") == "true":
            statusLog("---> Monthly Full Refresh for movies started")
        statusLog("---------------------------------------------------")
        self.doUpdateTop250Movies()
        self.doUpdateMovies()
        statusLog("---> Scheduled/autostart ratings update for movies finished")
        if ShowNotifications == "true":
            doNotify( addonLanguage(32258), 5000 )
            xbmc.sleep(8000)
        return


    def doUpdateTop250Movies(self):
        global num_threads
        if addonSettings.getSetting("Top250Support") != "true":
            return
        logInfo("Update","Top250 synchronization started")
        Top250LogLevel = int(addonSettings.getSetting("Top250LogLevel"))
        changed_positions = 0
        # -------------------------------------------------
        # LOAD TOP250 FILE
        # -------------------------------------------------
        Top250Map = {}
        top250_path = get_local_top250_path(addonSettings)
        if not xbmcvfs.exists(top250_path):
            logInfo("Update","Top250 synchronization skipped: Top250.txt not found")
            return
        try:
            with open(top250_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        pos, imdb_id = line.split("|", 1)
                        pos = int(pos.strip())
                        imdb_id = imdb_id.strip()
                        if imdb_id:
                            Top250Map[imdb_id] = pos
                    except:
                        continue
            logInfo("Update","Top250 entries loaded (have to be 250): %d" % len(Top250Map))
        except Exception as e:
            logError("Update", "Failed to parse Top250.txt: %s" % str(e))
            return
        # -------------------------------------------------
        # LOAD ALL MOVIES FROM KODI DB
        # -------------------------------------------------
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"params":{"properties":["uniqueid","title","top250"]},'
            '"id":1}'
        )
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        try:
            movies = jSonResponse.get('result', {}).get('movies', [])
            # -------------------------------------------------
            # COUNT UNIQUE MOVIES FROM USER LIBRARY PRESENT IN TOP250
            # -------------------------------------------------
            top250_imdb_ids = set()
            for item in movies:
                IMDb = TVDB = TMDB = None
                unique_id = item.get('uniqueid')
                if unique_id:
                    IMDb = unique_id.get('imdb')
                    TVDB = unique_id.get('tvdb')
                    TMDB = unique_id.get('tmdb')
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                if IMDb and IMDb in Top250Map:
                    top250_imdb_ids.add(IMDb)
            top250_movies_count = len(top250_imdb_ids)
            logInfo("Update","Movies from library found in Top250: %d" % top250_movies_count)
            counter = 0
            processed_top250 = 0
            progress = None
            if ShowProgress == "true":
                progress = xbmcgui.DialogProgressBG()
                progress.create("%s (0 of %d)" % (addonLanguage(32261), top250_movies_count))
            for item in movies:
                counter += 1
                IMDb = TVDB = TMDB = None
                unique_id = item.get('uniqueid')
                if unique_id:
                    IMDb = unique_id.get('imdb')
                    TVDB = unique_id.get('tvdb')
                    TMDB = unique_id.get('tmdb')
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                if not IMDb:
                    continue
                movieid = item.get('movieid')
                title = item.get('title')
                currentTop250 = item.get('top250', 0)
                # -------------------------------------------------
                # MOVIE IS CURRENTLY IN TOP250
                # -------------------------------------------------
                if IMDb in Top250Map:
                    processed_top250 += 1
                    if ShowProgress == "true" and top250_movies_count > 0:
                        progress.update(int((processed_top250 * 100) / top250_movies_count), "%s (%d of %d)" % (addonLanguage(32261), processed_top250, top250_movies_count), title)
                    newTop250 = Top250Map[IMDb]
                    if currentTop250 != newTop250:
                        changed_positions += 1
                        if Top250LogLevel >= 1:
                            if currentTop250 > 0:
                                logInfo("Update", "Top250 update: %s -> #%d (#%d)" % (title, newTop250, currentTop250))
                            else:
                                logInfo("Update", "Top250 update: %s -> #%d" % (title, newTop250))
                    elif Top250LogLevel == 2:
                        logInfo("Update", "Top250 update: %s -> #%d" % (title, newTop250))
                    while num_threads > max_threads * 2:
                        xbmc.sleep(500)
                    start_new_thread(
                        thread_parse_IMDb_page,
                        (
                            "movie",
                            movieid,
                            IMDb,
                            TVDB,
                            TMDB,
                            title,
                            -1,
                            None,
                            None,
                            Top250Map[IMDb],
                            self.lock,
                            self.flock
                        )
                    )
                    self.lock.acquire()
                    num_threads += 1
                    self.lock.release()
                # -------------------------------------------------
                # MOVIE LEFT TOP250
                # -------------------------------------------------
                elif currentTop250 > 0:
                    if Top250LogLevel == 2:
                        logInfo("Update", "Removing stale Top250 position for: %s (#%d)" % (title, currentTop250))
                    query = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                        '"params":{"movieid":%d,"top250":0},'
                        '"id":1}'
                    ) % movieid
                    xbmc.executeJSONRPC(query)
            # -------------------------------------------------
            # WAIT FOR THREADS
            # -------------------------------------------------
            while num_threads > 0:
                xbmc.sleep(500)
            if ShowProgress == "true":
                xbmc.sleep(1000)
                progress.close()
            logInfo("Update", "Top250 synchronization finished. Number of movies changed position in Top250: %d" % changed_positions)
        except Exception as e:
            if ShowProgress == "true" and progress:
                try:
                    progress.close()
                except:
                    pass
            logError("Update", "Exception: %s" % str(e))


    def getDBMovies(self):
        self.AllMovies = []
        dateAfter = None
        if addonSettings.getSetting("FullRefreshMode") != "true" and UpdateMovieTime > 0:
            dateAfter = (datetime.now() - timedelta(days=365 * UpdateMovieTime)).date()
            logInfo("Update","Movie premiered filter enabled: date >= %s" % dateAfter)
        else:
            logInfo("Update","Movie premiered filter disabled: updating ALL movies")
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"params":{"properties":["uniqueid","title","year","premiered"],'
            '"sort":{"method":"year","order":"descending"}},'
            '"id":1}'
        )
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        try:
            movies = jSonResponse.get('result', {}).get('movies', [])
            logInfo("Update","Movies returned by Kodi DB (before filter): %d" % len(movies))
            for item in movies:
                premiered = item.get('premiered')
                # Apply premiered date filter
                if dateAfter:
                    try:
                        if not premiered:
                            continue
                        if datetime.strptime(premiered, "%Y-%m-%d").date() < dateAfter:
                            continue
                    except:
                        continue
                IMDb = TVDB = TMDB = None
                unique_id = item.get('uniqueid')
                if unique_id:
                    IMDb = unique_id.get('imdb')
                    TVDB = unique_id.get('tvdb')
                    TMDB = unique_id.get('tmdb')
                    IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                movieid = item.get('movieid')
                title = item.get('title')
                self.AllMovies.append((movieid, IMDb, TVDB, TMDB, title))
            logInfo("Update","Movies selected for update (after filter): %d" % len(self.AllMovies))
        except Exception as e:
            logError("Update", "getDBMovies exception: %s" % str(e))
        return



    def doUpdateMovies(self):
        global num_threads
        AllMovies = len(self.AllMovies)
        Counter = 0
        progress = None
        if ShowProgress == "true":
            progress = xbmcgui.DialogProgressBG()
            progress.create(get_progress_title())
        for Movie in self.AllMovies:
            while num_threads > max_threads * 2:
                xbmc.sleep(500)
            if ShowProgress == "true":
                Counter += 1
                progress.update(int((Counter * 100) / AllMovies), get_progress_title(), Movie[4])
            IMDb = Movie[1]
            TVDB = Movie[2]
            TMDB = Movie[3]
            # TRY TO OBTAIN IMDb ID (only if TMDB exists)
            if IMDb is None and TMDB:
                (IMDb, statusInfo) = get_IMDb_ID_from_TMDb("movie", TMDB)
                # DO NOT skip if both IMDb and TMDB are None. Title+Year+(Director if needed) fallback will be handled in thread_parse_IMDb_page().
            # ALWAYS START THREAD (even if IMDb and TMDB are None)
            start_new_thread(
                thread_parse_IMDb_page,
                (
                    "movie",
                    Movie[0],
                    IMDb,
                    TVDB,
                    TMDB,
                    Movie[4],
                    -1,
                    None,
                    progress,
                    0,
                    self.lock,
                    self.flock
                )
            )
            self.lock.acquire()
            num_threads += 1
            self.lock.release()
        # -------------------------------------------------
        # WAIT FOR THREADS TO FINISH
        # -------------------------------------------------
        while num_threads > 0:
            xbmc.sleep(500)
        if ShowProgress == "true":
            xbmc.sleep(1000)
            progress.close()
        return



class TVShows:
    def __init__(self):
        self.lock = allocate_lock()
        self.flock = allocate_lock()
        self.episodes_total_before = 0
        self.episodes_total_after = 0
        self._episode_filter_logged = False

    def doUpdate(self):
        self.AllTVShows = []
        self.getDBTVShows()
        if len( self.AllTVShows ) == 0:
            xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32841) )
            return
        if ShowNotifications == "true":
            doNotify( addonLanguage(32256), 5000 )
            xbmc.sleep(5000)
        statusLog("-----------------------------------------------------")
        statusLog("---> Scheduled/autostart ratings update for TV shows started")
        if addonSettings.getSetting("FullRefreshMode") == "true":
            statusLog("---> Monthly Full Refresh for TV shows started")
        statusLog("-----------------------------------------------------")
        self.doUpdateTVShows()
        statusLog("---> Scheduled/autostart ratings update for TV shows finished")
        if ShowNotifications == "true":
            doNotify( addonLanguage(32259), 5000 )
            xbmc.sleep(5000)
        return

    def getDBTVShows(self):
        if addonSettings.getSetting("FullRefreshMode") != "true" and UpdateTime > 0:
            dateAfter = (datetime.now() - timedelta(days=UpdateTime)).strftime('%Y-%m-%d')
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["uniqueid","title"], "filter": {"field": "dateadded", "operator": "greaterthan", "value": "' + str( dateAfter ) + '"}, "sort":{"method": "dateadded","order":"descending"}},"id":1}'
        else:
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["uniqueid","title"], "sort":{"method": "dateadded","order":"descending"}},"id":1}'
        jSonResponse = xbmc.executeJSONRPC( jSonQuery )
        jSonResponse = jSon.loads( jSonResponse )
        try:
            if 'tvshows' in jSonResponse['result']:
                for item in jSonResponse['result']['tvshows']:
                    IMDb = None; TVDB = None; TMDB = None
                    unique_id = item.get('uniqueid')
                    if unique_id != None:
                        IMDb = unique_id.get('imdb')
                        TVDB = unique_id.get('tvdb')
                        TMDB = unique_id.get('tmdb')
                        IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                    tvshowid = item.get('tvshowid')
                    title = item.get('title')
                    self.AllTVShows.append((tvshowid, IMDb, TVDB, TMDB, title))
        except: pass
        return


    def doUpdateTVShows(self):
        global num_threads
        AllTVShows = len(self.AllTVShows)
        Counter = 0
        percentage = 0
        progress = None
        if ShowProgress == "true":
            progress = xbmcgui.DialogProgressBG()
            progress.create(get_progress_title())
        for TVShow in self.AllTVShows:
            while num_threads > max_threads:
                xbmc.sleep(500)
            if ShowProgress == "true":
                Counter += 1
                percentage = (Counter * 100) / AllTVShows
                progress.update(int(percentage), get_progress_title(), TVShow[4])
            IMDb = TVShow[1]
            TVDB = TVShow[2]
            TMDB = TVShow[3]
            # Try to resolve IMDb only if missing
            if IMDb is None:
                IMDb, statusInfo = get_tvshow_IMDb_ID("tvshow", TVShow[0], TVDB, TMDB, TVShow[4])
            # DO NOT EXIT if IMDb is None. Let thread handle TMDB fallback / TVDB->TMDB mapping
            start_new_thread(thread_parse_IMDb_page, ("tvshow", TVShow[0], IMDb, TVDB, TMDB, TVShow[4], -1, None, progress, 0, self.lock, self.flock))
            self.lock.acquire()
            num_threads += 1
            self.lock.release()
            # ALWAYS update episodes
            self.doUpdateEpisodes(TVShow[0], TMDB, -1, progress, percentage)
        while num_threads > 0:
            xbmc.sleep(500)
        # GLOBAL EPISODE COUNT (always executed now)
        try:
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
                '"params":{"limits":{"start":0,"end":1}},'
                '"id":1}'
            )
            response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
            total_episodes = response.get("result", {}).get("limits", {}).get("total", 0)
        except:
            total_episodes = 0
        logInfo("Update","All episodes returned by Kodi DB (before filter): %d" % total_episodes)
        logInfo("Update","All episodes selected for update (after filter): %d" % self.episodes_total_after)
        if ShowProgress == "true":
            xbmc.sleep(1000)
            progress.close()
        return


    def doUpdateEpisodes(self, tvshowid, tvshowTMDB, season, progress, percentage, datefilter=False):
        global num_threads
        dateAfter = None
        if addonSettings.getSetting("FullRefreshMode") != "true" and UpdateTime > 0:
            dateAfter = (datetime.now() - timedelta(days=UpdateTime)).date()
            if not self._episode_filter_logged:
                logInfo("Update","Episode firstaired filter enabled: date >= %s" % dateAfter)
                self._episode_filter_logged = True
        else:
            if not self._episode_filter_logged:
                logInfo("Update","Episode firstaired filter disabled: updating ALL episodes")
                self._episode_filter_logged = True
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{'
            '"tvshowid":%d,'
            '"properties":["uniqueid","episode","season","showtitle","firstaired"],'
            '"sort":{"method":"episode"}'
            '},"id":1}'
        ) % tvshowid
        response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        try:
            episodes = response.get('result', {}).get('episodes', [])
            self.episodes_total_before += len(episodes)
            selected = 0
            for item in episodes:
                firstaired = item.get('firstaired')
                if not firstaired:
                    continue
                if dateAfter:
                    try:
                        if datetime.strptime(firstaired, "%Y-%m-%d").date() < dateAfter:
                            continue
                    except:
                        continue
                selected += 1
                while num_threads > max_threads:
                    xbmc.sleep(500)
                episodeid = item.get('episodeid')
                season = item.get('season')
                episode = "%02d" % item.get('episode')
                title = item.get('showtitle') + " " + str(season) + "x" + episode
                unique_id = item.get('uniqueid', {})
                IMDb = unique_id.get('imdb')
                TVDB = unique_id.get('tvdb')
                TMDB = unique_id.get('tmdb')
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                start_new_thread(
                    thread_parse_IMDb_page,
                    (
                        "episode",
                        episodeid,
                        IMDb,
                        TVDB,
                        TMDB,
                        title,
                        season,
                        tvshowid,
                        progress,
                        percentage,
                        self.lock,
                        self.flock
                    )
                )
                self.lock.acquire()
                num_threads += 1
                self.lock.release()
            self.episodes_total_after += selected
        except Exception as e:
            logError("Update", "doUpdateEpisodes exception: %s" % str(e))
        return


def perform_update():
    if not wait_for_internet(wait=2, retry=1):
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32257))
        return
    if addonSettings.getSetting("PerformingUpdate") == "true":
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32251))
        return
    if onMovies == "false" and onTVShows == "false":
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32842))
        return
    # -------------------------------------------------
    # LOCAL SQLITE DATASET VALIDATION
    # -------------------------------------------------
    if addonSettings.getSetting("LocalIMDbSQL") == "true":
        imdb_db_path = addonProfile + "/db/imdb_ratings.db"
        if not xbmcvfs.exists(imdb_db_path):
            logInfo("Update","Update aborted: local IMDb dataset DB missing")
            xbmcgui.Dialog().ok("%s" % (addonName), "Local IMDb dataset was not found.\n\nPlease update the dataset first.\nYou can do this by enabling scheduled updates or using the context menu.")
            return
        # -------------------------------------------------
        # TOP250 VALIDATION
        # -------------------------------------------------
        if addonSettings.getSetting("Top250Support") == "true":
            top250_path = addonProfile + "/db/Top250.txt"
            top250_source = addonSettings.getSetting("Top250SelectLocation")
            if not xbmcvfs.exists(top250_path):
                # -------------------------------------------------
                # WEBSITE SOURCE
                # -------------------------------------------------
                if top250_source == "2":
                    logInfo("Update","Top250.txt missing - attempting download from top250.info")
                    if not update_from_html():
                        logInfo("Update","Update aborted: failed downloading Top250 from top250.info")
                        xbmcgui.Dialog().ok(addonName, "Unable to download Top250 data from top250.info.")
                        return
                # -------------------------------------------------
                # LOCAL / NETWORK SOURCE
                # -------------------------------------------------
                else:
                    logInfo("Update","Update aborted: Top250.txt missing")
                    xbmcgui.Dialog().ok(
                        addonName,
                        "\n"
                        "Top250.txt was not found.\n\n"
                        "Disable Top250 support in add-on settings\n"
                        "or place Top250.txt in the add-on's /db folder\n"
                        "or specify a network share where the file is located.\n"
                        "or select a website as a source for downloading Top250.\n\n"
                        "Required format:\n"
                        "1|tt0111161\n"
                        "2|tt0068646\n"
                        "3|tt0468569\n"
                        "[...]\n"
                        "250|tt1954470"
                    )
                    return
    addonSettings.setSetting("PerformingUpdate", "true")
    # -------------------------------------------------
    # RUN LIBRARY UPDATE
    # -------------------------------------------------
    if addonSettings.getSetting("Top250Support") == "true":
        top250_path = addonProfile + "/db/Top250.txt"
        if not xbmcvfs.exists(top250_path):
            logInfo("Update","Top250 support enabled but Top250.txt missing")
            xbmcgui.Dialog().notification(addonName, "Top250.txt not found - Top250 synchronization disabled but movies ratings update continue", xbmcgui.NOTIFICATION_WARNING, 7000)
    if onMovies == "true":
        Movies().doUpdate()
        logInfo("Update","Ratings update on Movies finished")
    if onTVShows == "true":
        TVShows().doUpdate()
        logInfo("Update","Ratings update on TV Shows finished")
    addonSettings.setSetting("PerformingUpdate", "false")
    if ShowLogMessage == "true" and addonSettings.getSetting("LogDialog") == "true":
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32824))
        addonSettings.setSetting("LogDialog", "false")
    addonSettings.setSetting("LastRatingsUpdateDate", datetime.now().strftime("%Y-%m-%d"))
    if addonSettings.getSetting("FullRefreshMode") == "true":
        addonSettings.setSetting("LastFullRefreshDate", datetime.now().strftime("%Y-%m-%d"))
        logInfo("Update","Monthly Full Refresh completed. LastFullRefreshDate updated")
        addonSettings.setSetting("FullRefreshMode","false")
    if addonSettings.getSetting("MonthlyFullRefresh") == "true":
        last_refresh = datetime.strptime(addonSettings.getSetting("LastFullRefreshDate"), "%Y-%m-%d")
        next_full_refresh = (last_refresh + timedelta(days=30)).strftime("%Y-%m-%d")
        logInfo("Update", "Approximate next Full Refresh date: %s" % next_full_refresh)
    logInfo("Update","LastRatingsUpdateDate updated to %s" % datetime.now().strftime("%Y-%m-%d"))
    return


