# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc
from core import update_main

def StartUpdate():
    update_main.perform_update()

if (__name__ == "__main__"):
    StartUpdate()