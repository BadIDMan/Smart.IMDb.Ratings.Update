# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import json as jSon
import time, _strptime
from datetime import date, datetime, timedelta
from support.common import *
from main import StartUpdate
from core.update_common import normalize_IDs

#Enable below two lines for seeing what is coming from settings.xml
#from support.common import show_settings_debug
#show_settings_debug()

if not xbmcvfs.exists( addonProfile ): xbmcvfs.mkdir( addonProfile )

WeekDay = addonSettings.getSetting( "WeekDay" )
DayTime = addonSettings.getSetting( "DayTime" )
LAST_SCHEDULE_RUN = 0
LAST_SCAN_EVENT = 0

def log(msg):
    xbmc.log("[IMDbRatings] %s" % msg, xbmc.LOGINFO)


def UpdateSchedule():
    enabled_days = getEnabledWeekdays()
    run_time = addonSettings.getSetting("DayTime")
    today = datetime.now()
    today_weekday = today.weekday()
    next_run = None
    for offset in range(0, 8):  # look max 1 week ahead
        day_index = (today_weekday + offset) % 7
        if not enabled_days[day_index]:
            continue
        candidate_date = today.date() + timedelta(days=offset)
        # If today, check time
        if offset == 0 and time.strftime("%H:%M:%S") >= run_time:
            continue
        next_run = candidate_date
        break
    if next_run:
        addonSettings.setSetting("ScheduledRunDate", next_run.strftime("%Y-%m-%d"))
        statusLog(addonLanguage(32655) % (next_run.strftime("%Y-%m-%d"), run_time))
    xbmc.sleep(2000)
    log("Scheduler active days: %s @ %s" % (", ".join(d for d, v in zip(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], getEnabledWeekdays()) if v), addonSettings.getSetting("DayTime")))


def UpdateNewLibraryItems():
    # Duplicate scan protection
    now = time.time()
    if hasattr(UpdateNewLibraryItems, "_last_run"):
        if now - UpdateNewLibraryItems._last_run < 30:
            log("Ignoring duplicate library scan event")
            return
    UpdateNewLibraryItems._last_run = now
    log("Library scan finished – checking for newly added items")
    # Wait until Kodi scanner fully stops + hard delay 2 seconds
    while xbmc.getCondVisibility("Library.IsScanningVideo"):
        xbmc.sleep(1000)
    xbmc.sleep(2000)
    last_update = addonSettings.getSetting("LastLibraryAutoUpdate")
    try:
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetRecentlyAddedMovies",'
            '"params":{"properties":["uniqueid","title","dateadded"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        result = response.get("result", {})
        movies = result.get("movies", [])
        filtered_movies = []
        for m in movies:
            da = m.get("dateadded")
            if not da:
                continue
            # Early break optimization
            if da <= last_update:
                break
            filtered_movies.append(m)
        movies = filtered_movies
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetRecentlyAddedEpisodes",'
            '"params":{"properties":["showtitle","season","episode","uniqueid","tvshowid","dateadded"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        result = response.get("result", {})
        episodes = result.get("episodes", [])
        filtered_episodes = []
        for e in episodes:
            da = e.get("dateadded")
            if not da:
                continue
            # Early break optimization
            if da <= last_update:
                break
            filtered_episodes.append(e)
        episodes = filtered_episodes
        if not movies and not episodes:
            log("No new items added today")
            return
        log("Found %d new movies and %d new episodes – updating ratings" % (len(movies), len(episodes)))
        from core.update_main import thread_parse_IMDb_page
        from _thread import allocate_lock
        lock = allocate_lock()
        flock = allocate_lock()
        progress = xbmcgui.DialogProgressBG()
        progress.create("IMDb Ratings", "Updating newly added items")
        total = len(movies) + len(episodes)
        count = 0
        # MOVIES
        for item in movies:
            count += 1
            percentage = int((count / float(total)) * 100)
            movieid = item.get("movieid")
            title = item.get("title")
            unique = item.get("uniqueid", {})
            IMDb = unique.get("imdb")
            TVDB = unique.get("tvdb")
            TMDB = unique.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
            progress.update(percentage, title)
            thread_parse_IMDb_page(
                "movie",
                movieid,
                IMDb,
                TVDB,
                TMDB,
                title,
                -1,
                None,
                progress,
                percentage,
                lock,
                flock
            )
        # EPISODES
        for item in episodes:
            count += 1
            percentage = int((count / float(total)) * 100)
            episodeid = item.get("episodeid")
            season = item.get("season")
            episode = "%02d" % item.get("episode")
            tvshowid = item.get("tvshowid")
            title = item.get("showtitle") + " " + str(season) + "x" + episode
            unique = item.get("uniqueid", {})
            IMDb = unique.get("imdb")
            TVDB = unique.get("tvdb")
            TMDB = unique.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
            progress.update(percentage, title)
            thread_parse_IMDb_page(
                "episode",
                episodeid,
                IMDb,
                TVDB,
                TMDB,
                title,
                season,
                tvshowid,
                progress,
                percentage,
                lock,
                flock
            )
        progress.close()
        log("Finished updating ratings for newly added items")
        addonSettings.setSetting(
            "LastLibraryAutoUpdate",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
    except Exception as e:
        xbmc.log("[IMDbRatings] Auto-update failed: %s" % str(e), xbmc.LOGERROR)




class LibraryMonitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        global LAST_SCAN_EVENT
        if method == "VideoLibrary.OnScanFinished":
            now = time.time()
            # Ignore duplicate events - kodi sometimes fires twice
            if now - LAST_SCAN_EVENT < 60:
                log("Duplicate scan finished event ignored")
                return
            LAST_SCAN_EVENT = now
            log("Kodi library scan finished")
            if addonSettings.getSetting("PerformingUpdate") == "true":
                log("Update already running – skipping auto-update")
                return
            xbmc.sleep(30000)
            UpdateNewLibraryItems()


def AutoStart():
    global LAST_SCHEDULE_RUN

    if addonSettings.getSetting("PerformingUpdate") == "true":
        log("Detected unfinished update from previous session – resetting state")
    addonSettings.setSetting("PerformingUpdate", "false")
    addonSettings.setSetting("LogDialog", "false")
    start_StatusLog()
    monitor = LibraryMonitor()
    # initial settings
    if addonSettings.getSetting("LastLibraryAutoUpdate") == "":
        addonSettings.setSetting("LastLibraryAutoUpdate", "2000-01-01 00:00:00")
    last_daytime = addonSettings.getSetting("DayTime")
    # ALWAYS recalc schedule on startup
    if addonSettings.getSetting("ScheduleEnabled") == "true":
        UpdateSchedule()
    # MAIN SERVICE LOOP
    while not monitor.abortRequested():
        now = datetime.now()
        sleep_seconds = 60 - now.second
        monitor.waitForAbort(sleep_seconds)
        if monitor.abortRequested():
            break
        # DO NOT RUN SCHEDULER WHILE UPDATE IS ACTIVE
        if addonSettings.getSetting("PerformingUpdate") == "true":
            continue
        if addonSettings.getSetting("ScheduleEnabled") != "true":
            continue
        # DETECT SETTINGS CHANGE (DayTime)
        current_daytime = addonSettings.getSetting("DayTime")
        if current_daytime != last_daytime:
            log("Schedule time changed – recalculating scheduler")
            UpdateSchedule()
            last_daytime = current_daytime
        # RE-CALCULATE IF NEVER SCHEDULED
        if addonSettings.getSetting("ScheduledRunDate") == "2000-01-01":
            UpdateSchedule()
        # CHECK IF UPDATE SHOULD RUN
        try:
            scheduled_day = datetime.strptime(
                addonSettings.getSetting("ScheduledRunDate"),
                "%Y-%m-%d"
            )
        except TypeError:
            scheduled_day = datetime(*(time.strptime(
                addonSettings.getSetting("ScheduledRunDate"),
                "%Y-%m-%d"
            )[0:6]))
        if datetime.now() >= scheduled_day:
            if time.strftime("%H:%M:%S") >= addonSettings.getSetting("DayTime"):
                now = time.time()
                # PREVENT DOUBLE SCHEDULE EXECUTION
                if now - LAST_SCHEDULE_RUN < 60:
                    continue
                LAST_SCHEDULE_RUN = now
                StartUpdate()
                UpdateSchedule()

if (__name__ == "__main__"):
    AutoStart()
