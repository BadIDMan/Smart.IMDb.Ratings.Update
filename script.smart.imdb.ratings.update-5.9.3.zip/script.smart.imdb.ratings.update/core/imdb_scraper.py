# -*- coding: utf-8 -*-

##############################
# Smart IMDb Ratings Update  #
# by rafikW                  #
############################ #

import re
import xbmc
import time
import random
from _thread import allocate_lock
from support.common import *
from support.httptools import get_page

base_url = "https://www.imdb.com/title/"

api_lock = allocate_lock()
next_request_time = 0

IMDB_SEASON_CACHE = {}


def imdbapi_rate_limit():
    global next_request_time
    api_lock.acquire()
    try:
        now = time.time()
        if now < next_request_time:
            sleep_time = next_request_time - now
            xbmc.sleep(int(sleep_time * 1000))
        next_request_time = max(now, next_request_time) + RateLimitThreshold
        # small jitter prevents thread sync
        xbmc.sleep(int(random.uniform(10, 40)))
    finally:
        api_lock.release()


def parse_IMDb_page(imdb_id):
    # Should not be used since IMDb is WAF protected for API calls but I'm keeping this for reference, maybe one day it will be possible scrap data from IMDb again
    url = base_url + imdb_id + "/"
    do_loop = 1
    while do_loop > 0:
        (html, status, statusInfo) = get_page(url)
        if status == "socket":
            xbmc.sleep(1000 * do_loop)
            do_loop += 1
            if do_loop == 4:
                return (None, None, 0, statusInfo)
        elif status == "HTTP":
            return (None, None, 0, statusInfo)
        else:
            do_loop = 0
    htmlline = html.replace('\n', ' ').replace('\r', '')
    matchVotes = re.findall(
        r'title=\"(\d\.\d) based on (\d*,?\d*,?\d+) user ratings\"',
        htmlline
    )
    if matchVotes:
        rating = matchVotes[0][0]
        votes = matchVotes[0][1]
    else:
        matchVotes = re.findall(
            r'"ratingCount":(\d*,?\d*,?\d+),"bestRating":\"?\d+\.?\d?\"?,"worstRating":\"?\d+\.?\d?\"?,"ratingValue":\"?(\d+\.?\d?)\"?',
            htmlline.replace(' ', '')
        )
        if matchVotes:
            rating = matchVotes[0][1]
            votes = matchVotes[0][0]
        else:
            rating = None
            votes = None
            statusInfo = "No rating found on IMDb (wrong ID or IMDb web page BLOCKED by AMZN WAF 'Web Application Firewall')"
    matchTop250 = re.findall(
        r'href="/chart/top\?ref_=tt_awd" > Top Rated Movies #(\d+) </a>',
        htmlline
    )
    if matchTop250:
        top250 = matchTop250[0]
    else:
        top250 = 0
    return (rating, votes, top250, statusInfo)


# ------------------------------------------------------------------------------
# NEW DATA PROVIDER: imdbapi.dev - LETS USE IT WHEN IMDb IS "DOWN" FOR API CALLS
# ------------------------------------------------------------------------------
def parse_IMDbAPI_page(imdb_id):
    try:
        import json
        from six.moves.urllib.request import Request, urlopen
        from six.moves.urllib.error import HTTPError, URLError
        url = "https://api.imdbapi.dev/titles/%s" % imdb_id
        # rate limiting protection
        imdbapi_rate_limit()
        req = Request(url)
        req.add_header('User-Agent', "Mozilla/5.0")
        response = urlopen(req, timeout=15)
        raw = response.read().decode("utf-8")
        response.close()
        data = json.loads(raw)
        rating_block = data.get("rating")
        if not rating_block:
            return (None, None, 0, "IMDbAPI.dev: rating block missing")
        rating = rating_block.get("aggregateRating")
        votes = rating_block.get("voteCount")
        if rating is None or votes is None:
            return (None, None, 0, "IMDbAPI.dev: rating missing")
        # normalize rating to float with 1 decimal place
        try:
            rating = float(rating)
            rating = round(rating, 1)
        except:
            return (None, None, 0, "IMDbAPI.dev: invalid rating format")
        if rating is None or votes is None:
            return (None, None, 0, "IMDbAPI.dev: rating missing")
        return (rating, votes, 0, "OK")
    except Exception as e:
        xbmc.log("IMDbAPI.dev ERROR for %s: %s" % (imdb_id, str(e)), xbmc.LOGERROR)
        return (None, None, 0, "IMDbAPI.dev error")




def parse_IMDb_episodes_page(imdb_show_id, season):
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][EP] === START parse_IMDb_episodes_page === show=%s season=%s" % (imdb_show_id, season), xbmc.LOGINFO)
    cache_key = "%s_%s" % (imdb_show_id, season)
    # -----------------------------------------------------
    # CACHE CHECK
    # -----------------------------------------------------
    if cache_key in IMDB_SEASON_CACHE:
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][CACHE] HIT key=%s value=%s" % (cache_key, "EMPTY" if not IMDB_SEASON_CACHE[cache_key] else "FILLED"), xbmc.LOGINFO)
        return IMDB_SEASON_CACHE[cache_key], "CACHE"
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][EP][CACHE] MISS key=%s" % cache_key, xbmc.LOGINFO)
    url = base_url + imdb_show_id + "/episodes/?season=" + str(season)
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][EP] URL=%s" % url, xbmc.LOGINFO)
    # -----------------------------------------------------
    # FETCH PAGE
    # -----------------------------------------------------
    do_loop = 1
    while do_loop > 0:
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][HTTP] Attempt #%d" % do_loop, xbmc.LOGINFO)
        (html, status, statusInfo) = get_page(url)
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][HTTP] status=%s info=%s html_len=%s" % (status, statusInfo, len(html) if html else "None"), xbmc.LOGINFO)
        if status == "socket":
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][EP][HTTP] SOCKET retry..." % (), xbmc.LOGINFO)
            xbmc.sleep(1000 * do_loop)
            do_loop += 1
            if do_loop == 4:
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][EP] SOCKET FAILED after retries", xbmc.LOGERROR)
                return (None, statusInfo)
        elif status == "HTTP":
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][EP] HTTP ERROR: %s" % statusInfo, xbmc.LOGERROR)
            return (None, statusInfo)
        else:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][EP][HTTP] SUCCESS", xbmc.LOGINFO)
            do_loop = 0
    # -----------------------------------------------------
    # BASIC HTML CHECK
    # -----------------------------------------------------
    if not html:
        xbmc.log("[IMDbRatings][ERROR][EP] parse_IMDb_episodes_page - EMPTY HTML!", xbmc.LOGERROR)
        IMDB_SEASON_CACHE[cache_key] = None
        return (None, "Empty HTML")
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][EP] HTML sample (first 500 chars): %s" % html[:500], xbmc.LOGINFO)
    # -----------------------------------------------------
    # CRITICAL GUARD
    # -----------------------------------------------------
    if "tab-seasons" not in html:
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP] NO 'tab-seasons' FOUND -> invalid page structure!", xbmc.LOGERROR)
        IMDB_SEASON_CACHE[cache_key] = None
        return (None, "IMDb show has no episode list")
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][EP] 'tab-seasons' FOUND", xbmc.LOGINFO)
    # -----------------------------------------------------
    # NORMALIZE HTML
    # -----------------------------------------------------
    episode_map = {}
    try:
        htmlline = html.replace("\n", " ").replace("\r", "")
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP] Normalized HTML length=%d" % len(htmlline), xbmc.LOGINFO)
        # -------------------------------------------------
        # PATTERN 1
        # -------------------------------------------------
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][P1] Searching pattern1...", xbmc.LOGINFO)
        pattern1 = re.findall(
            r'episodeNumber[^>]*>\s*(\d+)\s*<.*?/title/(tt\d+)/',
            htmlline,
            re.IGNORECASE
        )
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][P1] matches=%d" % len(pattern1), xbmc.LOGINFO)
        for ep_num, imdb_id in pattern1:
            ep_num = int(ep_num)
            if ep_num not in episode_map:
                episode_map[ep_num] = imdb_id
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][EP][P1] ADD ep=%s imdb=%s" % (ep_num, imdb_id), xbmc.LOGINFO)
        # -------------------------------------------------
        # PATTERN 2
        # -------------------------------------------------
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][P2] Searching pattern2 blocks...", xbmc.LOGINFO)
        pattern2_blocks = re.findall(
            r'(<article.*?</article>)',
            htmlline,
            re.IGNORECASE
        )
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][P2] blocks=%d" % len(pattern2_blocks), xbmc.LOGINFO)
        for block in pattern2_blocks:
            id_match = re.search(r'/title/(tt\d+)/', block, re.IGNORECASE)
            ep_match = re.search(r'episodeNumber[^>]*>\s*(\d+)\s*<', block, re.IGNORECASE)
            if id_match and ep_match:
                ep_num = int(ep_match.group(1))
                imdb_id = id_match.group(1)
                if ep_num not in episode_map:
                    episode_map[ep_num] = imdb_id
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][EP][P2] ADD ep=%s imdb=%s" % (ep_num, imdb_id), xbmc.LOGINFO)
        # -------------------------------------------------
        # PATTERN 3
        # -------------------------------------------------
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][P3] Searching pattern3 blocks...", xbmc.LOGINFO)
        pattern3_blocks = re.findall(
            r'(<[^>]+data-testid="titleEpisode[^"]*".*?</[^>]+>)',
            htmlline,
            re.IGNORECASE
        )
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][EP][P3] blocks=%d" % len(pattern3_blocks), xbmc.LOGINFO)
        for block in pattern3_blocks:
            id_match = re.search(r'/title/(tt\d+)/', block, re.IGNORECASE)
            ep_match = re.search(r'episodeNumber[^>]*>\s*(\d+)\s*<', block, re.IGNORECASE)
            if id_match and ep_match:
                ep_num = int(ep_match.group(1))
                imdb_id = id_match.group(1)
                if ep_num not in episode_map:
                    episode_map[ep_num] = imdb_id
                    xbmc.log("[IMDbRatings][DEBUG][EP][P3] ADD ep=%s imdb=%s" % (ep_num, imdb_id), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("[IMDbRatings][ERROR][EP] parse_IMDb_episodes_page - PARSE EXCEPTION: %s" % str(e), xbmc.LOGERROR)
        return (None, "IMDb season page parse error")
    # -----------------------------------------------------
    # FINAL RESULT
    # -----------------------------------------------------
    if not episode_map:
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][ERROR][EP] FINAL episode_map EMPTY!", xbmc.LOGERROR)
        IMDB_SEASON_CACHE[cache_key] = None
        return (None, "IMDb season page parsed but no episode IDs found")
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][EP] FINAL episode_map size=%d keys=%s" % (len(episode_map), sorted(list(episode_map.keys()))), xbmc.LOGINFO)
    IMDB_SEASON_CACHE[cache_key] = episode_map
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][EP] === END parse_IMDb_episodes_page === OK", xbmc.LOGINFO)
    return (episode_map, "OK")
