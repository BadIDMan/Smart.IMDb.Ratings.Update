# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################


import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import json as jSon
import time, _strptime
from datetime import date, datetime, timedelta
from support.common import *
from main import StartUpdate
from core.update_common import normalize_IDs
from core.imdb_dataset import check_dataset_update

#Enable below two lines for seeing what is coming from settings.xml
#from support.common import show_settings_debug
#show_settings_debug()


if not xbmcvfs.exists(addonProfile): xbmcvfs.mkdir(addonProfile)

WeekDay = addonSettings.getSetting("WeekDay")
DayTime = addonSettings.getSetting("DayTime")
LAST_SCHEDULE_RUN = 0
LAST_SCAN_EVENT = 0

# NEW: dataset monitor state
DATASET_MONITOR_ACTIVE = False
DATASET_MONITOR_START = 0
DATASET_FIRST_CHECK = True

def log(msg):
    xbmc.log("[IMDbRatings][Monitor] %s" % msg, xbmc.LOGINFO)


def UpdateSchedule():
    enabled_days = getEnabledWeekdays()
    run_time = addonSettings.getSetting("DayTime")
    today = datetime.now()
    today_weekday = today.weekday()
    next_run = None
    for offset in range(0, 8):
        day_index = (today_weekday + offset) % 7
        if not enabled_days[day_index]:
            continue
        candidate_date = today.date() + timedelta(days=offset)
        if offset == 0 and time.strftime("%H:%M:%S") >= run_time:
            continue
        next_run = candidate_date
        break
    if next_run:
        addonSettings.setSetting("ScheduledRunDate", next_run.strftime("%Y-%m-%d"))
        statusLog(addonLanguage(32655) % (next_run.strftime("%Y-%m-%d"), run_time))
    xbmc.sleep(2000)
    log("Scheduler active days: %s @ %s" % (
        ", ".join(d for d, v in zip(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], getEnabledWeekdays()) if v),
        addonSettings.getSetting("DayTime")
    ))


def UpdateNewLibraryItems():
    now = time.time()
    if hasattr(UpdateNewLibraryItems, "_last_run"):
        if now - UpdateNewLibraryItems._last_run < 30:
            log("Ignoring duplicate library scan event")
            return
    UpdateNewLibraryItems._last_run = now
    log("Library scan finished – checking for newly added items")
    while xbmc.getCondVisibility("Library.IsScanningVideo"):
        xbmc.sleep(1000)
    xbmc.sleep(2000)
    last_update = addonSettings.getSetting("LastLibraryAutoUpdate")
    try:
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetRecentlyAddedMovies",'
            '"params":{"properties":["uniqueid","title","dateadded"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        movies = response.get("result", {}).get("movies", [])
        filtered_movies = []
        for m in movies:
            da = m.get("dateadded")
            if not da:
                continue
            if da <= last_update:
                break
            filtered_movies.append(m)
        movies = filtered_movies
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetRecentlyAddedEpisodes",'
            '"params":{"properties":["showtitle","season","episode","uniqueid","tvshowid","dateadded"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        episodes = response.get("result", {}).get("episodes", [])
        filtered_episodes = []
        for e in episodes:
            da = e.get("dateadded")
            if not da:
                continue
            if da <= last_update:
                break
            filtered_episodes.append(e)
        episodes = filtered_episodes
        if not movies and not episodes:
            log("No new items added today")
            return
        log("Found %d new movies and %d new episodes – updating ratings" % (len(movies), len(episodes)))
        from core.update_main import thread_parse_IMDb_page
        from _thread import allocate_lock
        lock = allocate_lock()
        flock = allocate_lock()
        progress = xbmcgui.DialogProgressBG()
        progress.create("IMDb Ratings", "Updating newly added items")
        total = len(movies) + len(episodes)
        count = 0
        for item in movies:
            count += 1
            percentage = int((count / float(total)) * 100)
            movieid = item.get("movieid")
            title = item.get("title")
            unique = item.get("uniqueid", {})
            IMDb = unique.get("imdb")
            TVDB = unique.get("tvdb")
            TMDB = unique.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
            progress.update(percentage, title)
            thread_parse_IMDb_page(
                "movie", movieid, IMDb, TVDB, TMDB,
                title, -1, None, progress, percentage, lock, flock
            )
        for item in episodes:
            count += 1
            percentage = int((count / float(total)) * 100)
            episodeid = item.get("episodeid")
            season = item.get("season")
            episode = "%02d" % item.get("episode")
            tvshowid = item.get("tvshowid")
            title = item.get("showtitle") + " " + str(season) + "x" + episode
            unique = item.get("uniqueid", {})
            IMDb = unique.get("imdb")
            TVDB = unique.get("tvdb")
            TMDB = unique.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
            progress.update(percentage, title)
            thread_parse_IMDb_page(
                "episode", episodeid, IMDb, TVDB, TMDB,
                title, season, tvshowid, progress, percentage, lock, flock
            )
        progress.close()
        log("Finished updating ratings for newly added items")
        addonSettings.setSetting(
            "LastLibraryAutoUpdate",
            datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        )
    except Exception as e:
        xbmc.log("[IMDbRatings] Auto-update failed: %s" % str(e), xbmc.LOGERROR)


class LibraryMonitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        global LAST_SCAN_EVENT
        if method == "VideoLibrary.OnScanFinished":
            now = time.time()
            if now - LAST_SCAN_EVENT < 60:
                log("Duplicate scan finished event ignored")
                return
            LAST_SCAN_EVENT = now
            log("Kodi library scan finished")
            if addonSettings.getSetting("PerformingUpdate") == "true":
                log("Update already running – skipping auto-update")
                return
            xbmc.sleep(30000)
            UpdateNewLibraryItems()


def AutoStart():
    global LAST_SCHEDULE_RUN
    global DATASET_MONITOR_ACTIVE
    global DATASET_MONITOR_START
    global DATASET_FIRST_CHECK

    if addonSettings.getSetting("PerformingUpdate") == "true":
        log("Detected unfinished update from previous session – resetting state")
    addonSettings.setSetting("PerformingUpdate", "false")
    addonSettings.setSetting("LogDialog", "false")
    start_StatusLog()
    monitor = LibraryMonitor()
    if addonSettings.getSetting("LastLibraryAutoUpdate") == "":
        addonSettings.setSetting("LastLibraryAutoUpdate", "2000-01-01 00:00:00")
    last_daytime = addonSettings.getSetting("DayTime")
    if addonSettings.getSetting("ScheduleEnabled") == "true":
        UpdateSchedule()
    while not monitor.abortRequested():
        now = datetime.now()
        sleep_seconds = 60 - now.second
        monitor.waitForAbort(sleep_seconds)
        if monitor.abortRequested():
            break
        if addonSettings.getSetting("PerformingUpdate") == "true":
            continue
        if addonSettings.getSetting("ScheduleEnabled") != "true":
            continue
        current_daytime = addonSettings.getSetting("DayTime")
        if current_daytime != last_daytime:
            log("Schedule time changed – recalculating scheduler")
            UpdateSchedule()
            last_daytime = current_daytime
        if addonSettings.getSetting("ScheduledRunDate") == "2000-01-01":
            UpdateSchedule()
        try:
            scheduled_day = datetime.strptime(
                addonSettings.getSetting("ScheduledRunDate"),
                "%Y-%m-%d"
            )
        except TypeError:
            scheduled_day = datetime(*(time.strptime(
                addonSettings.getSetting("ScheduledRunDate"),
                "%Y-%m-%d"
            )[0:6]))
        # =========================
        # START MONITOR WINDOW
        # =========================
        if datetime.now() >= scheduled_day:
            if time.strftime("%H:%M:%S") >= addonSettings.getSetting("DayTime"):
                now_ts = time.time()
                if now_ts - LAST_SCHEDULE_RUN >= 60:
                    LAST_SCHEDULE_RUN = now_ts
                    log("Starting dataset monitoring window")
                    DATASET_MONITOR_ACTIVE = True
                    DATASET_MONITOR_START = now_ts
                    DATASET_FIRST_CHECK = True
                    retry_interval = int(addonSettings.getSetting("RetryInterval") or 15)
                    AutoStart._last_dataset_check = now_ts - retry_interval * 60
                    AutoStart._last_remaining_log = -1
                    UpdateSchedule()
        # =========================
        # DATASET MONITOR LOOP
        # =========================
        if DATASET_MONITOR_ACTIVE:
            retry_interval = int(addonSettings.getSetting("RetryInterval") or 15)
            max_window = int(addonSettings.getSetting("RetryWindow") or 180)
            now_ts = time.time()
            elapsed = (now_ts - DATASET_MONITOR_START) / 60.0
            # ---------------------------------
            # WINDOW EXPIRED
            # ---------------------------------
            if elapsed > max_window:
                log("Dataset monitoring window expired")
                DATASET_MONITOR_ACTIVE = False
                if DATASET_FIRST_CHECK:
                    log("Dataset never appeared -> running update with latest available data")
                    DATASET_FIRST_CHECK = False
                    StartUpdate()
            else:
                if not hasattr(AutoStart, "_last_dataset_check"):
                    AutoStart._last_dataset_check = 0
                # ---------------------------------
                # NON-SPAM LOGGING (HALF INTERVAL)
                # ---------------------------------
                time_since_last = now_ts - AutoStart._last_dataset_check
                # midpoint threshold (e.g. 15min -> log at ~7–8min)
                half_interval = (retry_interval * 60) / 2
                if not hasattr(AutoStart, "_half_logged"):
                    AutoStart._half_logged = False
                # reset flag after each real check
                if time_since_last >= retry_interval * 60:
                    AutoStart._half_logged = False
                # log only once per interval (at half point)
                if not AutoStart._half_logged and time_since_last >= half_interval:
                    remaining = max(1, int((retry_interval * 60 - time_since_last) / 60))
                    if remaining < 0:
                        remaining = 0
                    log("Next dataset check in %d minutes" % remaining)
                    AutoStart._half_logged = True
                # ---------------------------------
                # EXECUTE CHECK
                # ---------------------------------
                if time_since_last >= retry_interval * 60:
                    AutoStart._last_dataset_check = now_ts
                    log("Checking dataset...")
                    try:
                        status = check_dataset_update()
                    except Exception as e:
                        xbmc.log("[IMDbRatings][Dataset] Check failed: %s" % str(e), xbmc.LOGERROR)
                        status = None
                    # ---------------------------------
                    # STATE HANDLING (FIXED)
                    # ---------------------------------
                    if status == "updated":
                        log("New dataset detected -> starting ratings update")
                        DATASET_MONITOR_ACTIVE = False
                        DATASET_FIRST_CHECK = False
                        StartUpdate()
                    elif status == "up_to_date":
                        if DATASET_FIRST_CHECK:
                            log("Dataset already up to date -> running ratings update")
                            DATASET_MONITOR_ACTIVE = False
                            DATASET_FIRST_CHECK = False
                            StartUpdate()
                    elif status == "not_available":
                        log("Dataset not yet available -> waiting")


if (__name__ == "__main__"):
    AutoStart()
