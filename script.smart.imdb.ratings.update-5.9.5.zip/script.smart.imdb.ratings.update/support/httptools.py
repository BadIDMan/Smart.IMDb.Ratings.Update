# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import socket, six
import xbmc
from six.moves.urllib.request import Request, urlopen
from six.moves.urllib.error import HTTPError, URLError
from support.common import *
import io, gzip

User_Agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
Accept_Encoding = "gzip"



def get_page(url):
    # It doesn't work anymore since IMDb implemented WAF anti-bot protection but I'm keeping this for reference and maybe for restart to use it
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][get_page] === START === url=%s" % url, xbmc.LOGINFO)
    req = Request(url)
    req.add_header('User-Agent', User_Agent)
    req.add_header('Accept-encoding', Accept_Encoding)
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG][get_page] headers UA=%s AE=%s" % (User_Agent, Accept_Encoding), xbmc.LOGINFO)
    socket.setdefaulttimeout(30)
    html = ""
    try:
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][get_page] Opening URL...", xbmc.LOGINFO)
        response = urlopen(req)
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][get_page] Response object=%s" % str(response), xbmc.LOGINFO)
        try:
            headers = response.info()
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][get_page] Response headers=%s" % str(headers), xbmc.LOGINFO)
        except Exception as e:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][ERROR][get_page] Failed reading headers: %s" % str(e), xbmc.LOGERROR)
        encoding = None
        try:
            encoding = response.info().get('Content-Encoding')
        except Exception:
            pass
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][get_page] Content-Encoding=%s" % str(encoding), xbmc.LOGINFO)
        # -------------------------------------------------
        # READ RAW DATA
        # -------------------------------------------------
        try:
            raw = response.read()
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][get_page] RAW type=%s len=%s" % (type(raw), len(raw) if raw else "None/0"), xbmc.LOGINFO)
        except Exception as e:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][ERROR][get_page] Failed reading raw response: %s" % str(e), xbmc.LOGERROR)
            raw = None
        # -------------------------------------------------
        # DECODE
        # -------------------------------------------------
        try:
            if encoding == 'gzip':
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][get_page] Decoding gzip...", xbmc.LOGINFO)
                buf = io.BytesIO(raw)
                f = gzip.GzipFile(fileobj=buf)
                decoded = f.read()
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][get_page] GZIP decoded len=%s" % (len(decoded) if decoded else "None/0"), xbmc.LOGINFO)
                html = decoded.decode("utf-8")
            else:
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][get_page] Decoding plain utf-8...", xbmc.LOGINFO)
                html = raw.decode("utf-8") if raw else ""
        except Exception as e:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][ERROR][get_page] Decode error: %s" % str(e), xbmc.LOGERROR)
            html = None
        # -------------------------------------------------
        # FINAL HTML CHECK
        # -------------------------------------------------
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][get_page] FINAL html type=%s len=%s" % (type(html), len(html) if html else "None/0"), xbmc.LOGINFO)
        # Optional: detect non-HTML responses
        if html:
            snippet = html[:200].replace("\n", " ").replace("\r", "")
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][get_page] HTML snippet=%s" % snippet, xbmc.LOGINFO)
        else:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][ERROR][get_page] EMPTY HTML after decode!", xbmc.LOGERROR)
        response.close()
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG][get_page] === END OK ===", xbmc.LOGINFO)
        return (html, "OK", "OK")
    except HTTPError as err:
        error = str(err.code) + " " + err.reason
        statusInfo = "Method get_page - " + url + " -> Error accessing IMDb site (" + error + ")"
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][ERROR][get_page] HTTPError: %s" % statusInfo, xbmc.LOGERROR)
        return (html, "HTTP", statusInfo)
    except socket.error as err:
        statusInfo = "Method get_page - " + url + " -> Error accessing IMDb site (" + str(err) + ")"
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][ERROR][get_page] Socket error: %s" % statusInfo, xbmc.LOGERROR)
        return (html, "socket", statusInfo)
    except URLError as err:
        if not isinstance(err, six.string_types):
            error = err.reason
        else:
            error = str(err)
        statusInfo = "Method get_page - " + url + " -> Error accessing IMDb site (" + error + ")"
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][ERROR][get_page] URLError: %s" % statusInfo, xbmc.LOGERROR)
        return (html, "socket", statusInfo)
    except Exception as e:
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][CRITICAL][get_page] UNEXPECTED ERROR: %s" % str(e), xbmc.LOGERROR)
        return (html, "HTTP", "Unexpected error")


def internet():
    try:
        import requests
        headers = {'User-Agent': User_Agent}
        response = requests.get('https://www.google.com', headers=headers, timeout=3)
        return True
    except: 
        return False

def wait_for_internet(wait=30, retry=5):
    monitor = xbmc.Monitor()
    count = 0
    while True:
        if internet():
            return True
        count += 1
        if count >= retry or monitor.abortRequested():
            return False
        monitor.waitForAbort(wait)