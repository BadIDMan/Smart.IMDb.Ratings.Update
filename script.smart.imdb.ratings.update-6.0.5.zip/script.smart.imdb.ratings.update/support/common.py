# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import json, sys

import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import os, unicodedata
from datetime import datetime

try:
    xbmc.translatePath = xbmcvfs.translatePath
except AttributeError:
    pass

addonSettings     = xbmcaddon.Addon( "script.smart.imdb.ratings.update" )
addonName         = addonSettings.getAddonInfo( "name" )
addonVersion      = addonSettings.getAddonInfo( "version" )
addonIcon         = os.path.join( addonSettings.getAddonInfo( "path" ), "icon.png" )
addonProfile      = xbmc.translatePath( addonSettings.getAddonInfo( "profile" ) )
addonLanguage     = addonSettings.getLocalizedString
IMDbSource        = int(addonSettings.getSetting( "IMDbSource" )) #0 - IMDb JSON (imdbapi.dev) 1 - Direct IMDb HTML
LocalIMDbSQL      = addonSettings.getSettingBool( "LocalIMDbSQL" )
Max_requests      = int(addonSettings.getSetting("MAXRequests") or 25)
Time_slot         = int(addonSettings.getSetting("TimeSlot") or 10)
RateLimitThreshold = Time_slot / Max_requests
onMovies          = addonSettings.getSetting( "Movies" )
onTVShows         = addonSettings.getSetting( "TVShows" )
ShowNotifications = addonSettings.getSetting( "ShowNotifications" )
ShowProgress      = addonSettings.getSetting( "ShowProgress" )
ShowLogMessage    = addonSettings.getSetting( "ShowLogMessage" )
DebugLog          = addonSettings.getSetting( "DebugLog" )
Sound             = addonSettings.getSetting( "NotificationsSound" )
ScheduleEnabled   = addonSettings.getSetting( "ScheduleEnabled" )
if (int(addonSettings.getSetting( "UpdateTime" )) == 1):
    UpdateTime = 32
elif (int(addonSettings.getSetting( "UpdateTime" )) == 2):
    UpdateTime = 93
elif (int(addonSettings.getSetting( "UpdateTime" )) == 3):
    UpdateTime = 183
elif (int(addonSettings.getSetting( "UpdateTime" )) == 4):
    UpdateTime = 366
else:
    UpdateTime = 0
UpdateMovieTime   = int(addonSettings.getSetting( "UpdateMovieTime" ))
IMDbDefault       = addonSettings.getSetting( "IMDbRatingDefault" )
DayTime           = addonSettings.getSetting( "DayTime" )
def_threads = [1, 2, 4, 8, 16]
NumberOfThreads = def_threads[int(addonSettings.getSetting( "NumberOfThreads" ))]
TOP250_CACHE = None


def getRateLimitThreshold():
    return (
        int(addonSettings.getSetting("TimeSlot") or 10) /
        float(int(addonSettings.getSetting("MAXRequests") or 25))
    )


def getEnabledWeekdays():
    mode = addonSettings.getSetting("ScheduleMode")
    if mode == "0":  # every day
        return [True, True, True, True, True, True, True]
    elif mode == "1":  # single day
        selected = int(addonSettings.getSetting("SingleDay"))
        return [i == selected for i in range(7)]
    else:  # custom
        return [
            addonSettings.getSetting("ScheduleMon") == "true",
            addonSettings.getSetting("ScheduleTue") == "true",
            addonSettings.getSetting("ScheduleWed") == "true",
            addonSettings.getSetting("ScheduleThu") == "true",
            addonSettings.getSetting("ScheduleFri") == "true",
            addonSettings.getSetting("ScheduleSat") == "true",
            addonSettings.getSetting("ScheduleSun") == "true",
        ]


#temporary for diagnose purpose
def show_settings_debug():
    lines = []
    lines.append(f"IMDbDefault: {IMDbDefault}")
    lines.append(f"IMDbSource: {IMDbSource}")
    lines.append(f"LocalIMDbSQL: {LocalIMDbSQL}")
    lines.append(f"MAXRequests: {Max_requests}")
    lines.append(f"TimeSlot: {Time_slot}")
    lines.append(f"RateLimitThreshold: {RateLimitThreshold}")
    lines.append(f"Movies: {onMovies}")
    lines.append(f"TVShows: {onTVShows}")
    lines.append(f"UpdateTime (days): {UpdateTime}")
    lines.append(f"UpdateMovieTime: {UpdateMovieTime}")
    lines.append(f"ShowNotifications: {ShowNotifications}")
    lines.append(f"NotificationsSound: {Sound}")
    lines.append(f"ShowProgress: {ShowProgress}")
    lines.append(f"DebugLog: {DebugLog}")
    lines.append(f"ShowLogMessage: {ShowLogMessage}")
    lines.append(f"ScheduleEnabled: {ScheduleEnabled}")
    lines.append(f"DayTime: {DayTime}")
    lines.append(f"NumberOfThreads index: {addonSettings.getSetting('NumberOfThreads')}")
    lines.append(f"NumberOfThreads value: {NumberOfThreads}")
    lines.append(f"Enabled weekdays: {getEnabledWeekdays()}")
    xbmcgui.Dialog().textviewer(
        "Addon Settings Debug",
        "\n".join(lines)
    )
#temporary


def defaultLog(textMessage):
    xbmc.log("[%s] - %s" % (addonName, textMessage))


def debugLog(textMessage):
    xbmc.log("[%s] - %s" % (addonName, textMessage), level=xbmc.LOGDEBUG)


def doNotify( textMessage, millSec ):
    dialog = xbmcgui.Dialog()
    if Sound == "true":
        playSound = True
    else:
        playSound = False
    dialog.notification(addonName, textMessage, addonIcon, millSec, playSound)


def start_StatusLog():
    log_path = addonProfile + "/update.log"
    old_log_path = addonProfile + "/update.old.log"
    if xbmcvfs.exists(old_log_path):
        try:
            os.remove(old_log_path)
        except:
            pass
    if xbmcvfs.exists(log_path):
        try:
            os.rename(log_path, old_log_path)
        except:
            pass
    try:
        if IMDbSource == 1:
             UpdateSource = "IMDb HTTP"
        else:
             UpdateSource = "IMDbAPI (https://imdbapi.dev)"
        if LocalIMDbSQL:
           UpdateSource = "IMDb dataset copy from https://developer.imdb.com/non-commercial-datasets/"
        with open(log_path, "w", encoding="utf-8") as f:
            f.write("--------------------------------------------------------------------------------------------------------------------\n")
            f.write("Starting %s (%s)\n" % (addonName, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            f.write("Add-on version: %s | Kodi version: %s\n" % (addonVersion, get_kodi_version()))
            f.write("onMovies: %s | onTVShows: %s\n" % (onMovies, onTVShows))
            f.write("ScheduleEnabled: %s \n" % ScheduleEnabled)
            f.write("Source of update: %s\n" % UpdateSource)
            f.write("--------------------------------------------------------------------------------------------------------------------\n")
    except:
        pass


def statusLog(textMessage):
    try:
        with open(addonProfile + "/update.log", "a", encoding="utf-8") as f:
            f.write(textMessage + "\n")
    except:
        pass


def get_kodi_version():
    query = {
        "jsonrpc": "2.0",
        "method": "Application.GetProperties",
        "params": {
            "properties": ["version", "name"]
        },
        "id": 1
    }
    json_query = xbmc.executeJSONRPC(json.dumps(query))
    if sys.version_info[0] >= 3:
        json_query = str(json_query)
    else:
        json_query = unicode(json_query, 'utf-8', errors='ignore')
    json_query = json.loads(json_query)
    version_installed = []
    if 'result' in json_query and 'version' in json_query['result']:
        version_installed = json_query['result']['version']
        return str(version_installed['major']) + "." + str(version_installed['minor'])
    else:
        return ""



def load_top250():
    global TOP250_CACHE
    if TOP250_CACHE is not None:
        return TOP250_CACHE
    TOP250_CACHE = {}
    try:
        import xbmcvfs
        path = xbmc.translatePath(addonSettings.getAddonInfo("profile")) + "/db/Top250.txt"
        if not xbmcvfs.exists(path):
            return TOP250_CACHE
        f = xbmcvfs.File(path)
        content = f.read()
        f.close()
        for line in content.splitlines():
            line = line.strip()
            if not line or "|" not in line:
                continue
            rank, imdb = line.split("|", 1)
            try:
                TOP250_CACHE[imdb.strip()] = int(rank.strip())
            except:
                pass
    except Exception as e:
        xbmc.log("[IMDbRatings][Top250] Failed loading Top250.txt: %s" % str(e), xbmc.LOGERROR)
    return TOP250_CACHE


def get_top250_rank(imdb_id):
    if not imdb_id:
        return 0
    top250 = load_top250()
    return top250.get(imdb_id, 0)
