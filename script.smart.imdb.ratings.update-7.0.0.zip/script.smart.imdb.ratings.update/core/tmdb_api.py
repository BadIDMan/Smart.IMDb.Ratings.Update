# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################


import re
import json as jSon
from urllib.parse import quote

from support.common import *
import socket
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

user_agent = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (Kresp, like Gecko) Chrome/28.0.1468.0 Safari/537.36"
base_url = "https://api.themoviedb.org/3/"
API_KEY = "5a1a77e2eba8984804586122754f969f"


# --------------------------------------------------------------
# Helpers
# --------------------------------------------------------------
def _normalize_title(t):
    if not t:
        return ""
    t = t.lower()
    t = re.sub(r'[^a-z0-9]', '', t)
    return t


def _normalize_name(n):
    if not n:
        return ""
    n = n.lower()
    n = re.sub(r'[^a-z0-9]', '', n)
    return n


def get_TVDB_episode_ID_from_TMDB(tvshow_tmdb, season, episode):
    try:
        request = ("tv/%s/season/%s/episode/%s/external_ids?api_key=%s" % (tvshow_tmdb, season, episode, API_KEY))
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        data = jSon.loads(response)
        tvdb_id = data.get("tvdb_id")
        if tvdb_id:
            return str(tvdb_id)
    except Exception as e:
        logError("TMDBAPI", "Episode TVDB recovery failed: %s" % str(e))
    return None


# --------------------------------------------------------------
# SEND TMDB REQUEST
# --------------------------------------------------------------
def send_API_request(request):
    req = Request(request)
    req.add_header('User-Agent', user_agent)
    socket.setdefaulttimeout(30)
    resp = ""
    try:
        response = urlopen(req)
        resp = response.read().decode("utf-8")
        response.close()
        return (resp, "OK", "OK")
    except HTTPError as err:
        error = str(err.code) + " " + err.reason
        statusInfo = "TMDB API request error (" + error + ")"
        return (resp, "HTTP", statusInfo)
    except socket.error as err:
        statusInfo = "TMDB API request error (" + str(err) + ")"
        return (resp, "socket", statusInfo)
    except URLError as err:
        error = err.reason if not isinstance(err, str) else err
        statusInfo = "TMDB API request error (" + str(error) + ")"
        return (resp, "socket", statusInfo)


# --------------------------------------------------------------
# IMDb ID FROM TMDB
# --------------------------------------------------------------
def get_IMDb_ID_from_TMDb(updateitem, tmdb_id, season=0, episode=0):
    if not tmdb_id:
        return (None, "Method get_IMDb_ID_from_TMDb - Missing TMDB ID")
    if updateitem == "movie":
        request = "movie/%s/external_ids?api_key=%s" % (tmdb_id, API_KEY)
    elif updateitem == "tvshow":
        request = "tv/%s/external_ids?api_key=%s" % (tmdb_id, API_KEY)
    elif updateitem == "episode":
        request = "tv/%s/season/%s/episode/%s/external_ids?api_key=%s" % (
            tmdb_id, season, episode, API_KEY)
    else:
        return (None, "Unsupported media type")
    if DebugLog == "true":
        logDebug("TMDB", "Request=%s" % (base_url + request))
    (response, status, statusInfo) = send_API_request(base_url + request)
    if DebugLog == "true":
        logDebug("TMDB", "Status=%s statusInfo=%s" % (status, statusInfo))
        logDebug("TMDB", "Response=%s" % response)
    if statusInfo != "OK":
        return (None, statusInfo)
    try:
        data = jSon.loads(response)
        if DebugLog == "true":
            logDebug("TMDB", "Parsed=%s" % data)
        imdb_id = data.get("imdb_id")
    except Exception as e:
        logError("TMDB", "Json exception=%s" % str(e))
        imdb_id = None
    if DebugLog == "true":
        logDebug("TMDB", "imdb_id=%s" % imdb_id)
    if not imdb_id:
        return (None, "Method get_IMDb_ID_from_TMDb - missing IMDb ID")
    return (imdb_id, "OK")


# --------------------------------------------------------------
# GET TMDB RATING
# --------------------------------------------------------------
def get_TMDB_rating(updateitem, tmdb_id, season=0, episode=0):
    if not tmdb_id:
        return (None, None, "Missing TMDB ID")
    if updateitem == "movie":
        request = "movie/%s?api_key=%s" % (tmdb_id, API_KEY)
    elif updateitem == "tvshow":
        request = "tv/%s?api_key=%s" % (tmdb_id, API_KEY)
    elif updateitem == "episode":
        request = "tv/%s/season/%s/episode/%s?api_key=%s" % (tmdb_id, season, episode, API_KEY)
    else:
        return (None, None, "Unsupported media type")
    (response, status, statusInfo) = send_API_request(base_url + request)
    if statusInfo != "OK":
        return (None, None, statusInfo)
    try:
        data = jSon.loads(response)
        rating = data.get("vote_average")
        votes = data.get("vote_count")
    except Exception as e:
        logError("TMDB", "JSON parse error: %s" % str(e))
        return (None, None, "TMDB JSON parse error: %s" % str(e))
    if rating is None:
        return (None, None, "TMDB rating missing")
    return (rating, votes, "TMDB rating used")


def get_TMDB_episode_ID_from_IMDb(imdb_id):
    try:
        request = "find/%s?external_source=imdb_id&api_key=%s" % (imdb_id, API_KEY)
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        results = data.get("tv_episode_results", [])
        if results:
            return str(results[0].get("id"))
    except Exception as e:
        logError("TMDBAPI", "TMDB episode recovery failed: %s" % str(e))
    return None


def get_TMDB_movie_ID_from_IMDb(imdb_id):
    try:
        request = "find/%s?external_source=imdb_id&api_key=%s" % (imdb_id, API_KEY)
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        results = data.get("movie_results", [])
        if results:
            return str(results[0].get("id"))
    except Exception as e:
        logError("TMDBAPI", "TMDB movie recovery failed: %s" % str(e))
    return None


def get_TMDB_tvshow_ID_from_IMDb(imdb_id):
    try:
        request = "find/%s?external_source=imdb_id&api_key=%s" % (imdb_id, API_KEY)
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        results = data.get("tv_results", [])
        if results:
            return str(results[0].get("id"))
    except Exception as e:
        logError("TMDBAPI", "TMDB TV show recovery failed: %s" % str(e))
    return None


# --------------------------------------------------------------
# TVDB -> TMDB
# --------------------------------------------------------------
def get_TMDB_ID_from_TVDB(tvdb_id, media_type):
    if not tvdb_id:
        return (None, "Missing TVDB ID")
    request = "find/%s?api_key=%s&external_source=tvdb_id" % (tvdb_id, API_KEY)
    (response, status, statusInfo) = send_API_request(base_url + request)
    if statusInfo != "OK":
        return (None, statusInfo)
    try:
        data = jSon.loads(response)
        if media_type == "movie" and data.get("movie_results"):
            return (data["movie_results"][0]["id"], "OK")
        if media_type in ("tvshow", "episode") and data.get("tv_results"):
            return (data["tv_results"][0]["id"], "OK")
    except Exception as e:
        logError("TMDB", "TMDB TVDB mapping parse error: %s" % str(e))
        return (None, "TMDB TVDB mapping parse error: %s" % str(e))
    return (None, "No TMDB match found for TVDB ID")


# --------------------------------------------------------------
# STRICT TITLE + YEAR + DIRECTOR SEARCH
# --------------------------------------------------------------
def search_TMDB_by_title(updateitem, title, year=None, movieid=None):
    if updateitem != "movie" or not title or not year:
        return (None, None)
    query = quote(title)
    request = "search/movie?api_key=%s&query=%s&year=%s" % (API_KEY, query, year)
    (response, status, statusInfo) = send_API_request(base_url + request)
    if statusInfo != "OK":
        return (None, None)
    try:
        data = jSon.loads(response)
        results = data.get("results", [])
    except:
        return (None, None)
    if not results:
        return (None, None)
    input_title_norm = _normalize_title(title)
    input_year = str(year)
    strict_matches = []
    for r in results:
        result_title = r.get("title")
        release_date = r.get("release_date")
        if not result_title or not release_date:
            continue
        if _normalize_title(result_title) != input_title_norm:
            continue
        # sometimes Year on TMDB differ from this on IMDb therefore no match, so lets check +/- 1 year
        try:
            result_year = int(release_date[:4])
            if abs(result_year - int(input_year)) > 1:
                continue
        except:
            continue
        strict_matches.append(r)
    if not strict_matches:
        return (None, None)
    # Exact match
    if len(strict_matches) == 1:
        return (strict_matches[0].get("id"), "Title+Year")
    # Director verification
    if not movieid:
        return (None, None)
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails",'
            '"params":{"movieid":%d,"properties":["director"]},"id":1}'
        ) % movieid
        jSonResponse = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        moviedetails = jSonResponse.get("result", {}).get("moviedetails", {})
        kodi_directors = moviedetails.get("director", [])
        if not kodi_directors:
            return (None, None)
        kodi_directors_norm = [_normalize_name(d) for d in kodi_directors]
        for match in strict_matches:
            movie_tmdb_id = match.get("id")
            credits_request = "movie/%s/credits?api_key=%s" % (movie_tmdb_id, API_KEY)
            (resp, st, stInfo) = send_API_request(base_url + credits_request)
            if stInfo != "OK":
                continue
            credits = jSon.loads(resp)
            crew = credits.get("crew", [])
            for person in crew:
                if person.get("job") == "Director":
                    if _normalize_name(person.get("name")) in kodi_directors_norm:
                        return (movie_tmdb_id, "Title+Year+Director")
    except:
        return (None, None)
    return (None, None)


# ------------------
# GET TV SHOW STATUS
# ------------------
def get_TMDB_tvshow_status(tmdb_id):
    if not tmdb_id:
        return (None, "Missing TMDB ID")
    request = "tv/%s?api_key=%s" % (tmdb_id, API_KEY)
    (response, status, statusInfo) = send_API_request(base_url + request)
    if statusInfo != "OK":
        return (None, statusInfo)
    try:
        data = jSon.loads(response)
        tvshow_status = data.get("status")
    except Exception as e:
        logError("TMDB", "JSON parse error: %s" % str(e))
        return (None, "TMDB JSON parse error: %s" % str(e))
    if not tvshow_status:
        return (None, "TMDB TV show status missing")
    return (tvshow_status, "TMDB TV show status used")