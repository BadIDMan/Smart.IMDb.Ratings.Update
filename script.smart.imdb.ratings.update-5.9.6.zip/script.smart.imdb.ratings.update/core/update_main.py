# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc, xbmcgui
import sys
if sys.version_info[0] >= 3:
    import json as jSon
    from _thread import start_new_thread, allocate_lock
else:
    import simplejson as jSon
    from thread import start_new_thread, allocate_lock
from datetime import datetime, timedelta
from support.common import *
from support.httptools import wait_for_internet
from core.update_common import *
from core.imdb_scraper import parse_IMDb_page, parse_IMDbAPI_page
from core.tmdb_api import get_TMDB_rating
from core.tmdb_api import get_TMDB_ID_from_TVDB
from core.tmdb_api import get_IMDb_ID_from_TMDb
from core.tmdb_api import search_TMDB_by_title
from core.imdb_dataset import get_local_rating

def log(msg):
    xbmc.log("[IMDbRatings][Update] %s" % msg, xbmc.LOGINFO)



def _episode_passes_firstaired_filter(item):
    if UpdateTime <= 0:
        return True
    firstaired = item.get("firstaired")
    if not firstaired:
        return False
    try:
        aired = datetime.strptime(firstaired, "%Y-%m-%d")
    except:
        return False
    return aired >= (datetime.now() - timedelta(days=UpdateTime))


max_threads = int(NumberOfThreads) - 1    #0 - 1 thread, 1 - 2 threads ...
num_threads = 0


def thread_parse_IMDb_page(updateitem, updateitem_id, IMDb, TVDB, TMDB, title, season, tvshowid, progress, percentage, lock, flock, source_override=None):
    global LocalIMDbSQL
    global IMDbSource

    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG] === START thread === %s | ID=%s | IMDb=%s | TVDB=%s | TMDB=%s | season=%s | tvshowid=%s" % (updateitem, updateitem_id, IMDb, TVDB, TMDB, season, tvshowid), xbmc.LOGINFO)
    # -------------------------------------------------
    # CONTEXT SOURCE OVERRIDE
    # -------------------------------------------------
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG] Source override BEFORE: LocalIMDbSQL=%s IMDbSource=%s" % (LocalIMDbSQL, IMDbSource), xbmc.LOGINFO)
    if source_override == "api":
        LocalIMDbSQL = False
        IMDbSource = 0
    elif source_override == "dataset":
        LocalIMDbSQL = True
        IMDbSource = 0
    elif source_override == "html":
        LocalIMDbSQL = False
        IMDbSource = 1
    if DebugLog == "true":
        xbmc.log("[IMDbRatings][DEBUG] Source override AFTER: LocalIMDbSQL=%s IMDbSource=%s" % (LocalIMDbSQL, IMDbSource), xbmc.LOGINFO)
    fallback_chain = []
    global num_threads
    provider = None
    updatedRating = None
    updatedVotes = None
    updatedTop250 = 0
    statusInfo = ""
    if updateitem in ("movie", "tvshow", "episode"):
        if DebugLog == "true":
            xbmc.log("[IMDbRatings][DEBUG] Enter main processing block", xbmc.LOGINFO)

        # =========================================================
        # PRIORITY 0.5 - LOCAL IMDb DATASET first
        # =========================================================
        if IMDb and LocalIMDbSQL:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P0.5] IMDb=%s LocalIMDbSQL=%s" % (IMDb, LocalIMDbSQL), xbmc.LOGINFO)
                xbmc.log("[IMDbRatings][DEBUG][P0.5] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season), xbmc.LOGINFO)
            try:
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P0.5] Query dataset for IMDb=%s" % IMDb, xbmc.LOGINFO)
                (updatedRating, updatedVotes) = get_local_rating(IMDb)
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P0.5] Dataset result: rating=%s votes=%s" % (updatedRating, updatedVotes), xbmc.LOGINFO)
                if updatedRating is not None:
                    provider = "imdb"
                    statusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (updatedRating, updatedVotes)
                    updatedTop250 = 0
            except Exception as e:
                xbmc.log("[IMDbRatings][ERROR][P0.5] %s" % str(e), xbmc.LOGERROR)
                updatedRating = None
                statusInfo = "Local IMDb lookup error: %s" % str(e)

        # =========================================================
        # PRIORITY 1 - IMDb transport
        # =========================================================
        if IMDb and updatedRating is None and not LocalIMDbSQL:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P1] IMDb=%s updatedRating=%s LocalIMDbSQL=%s" % (IMDb, updatedRating, LocalIMDbSQL), xbmc.LOGINFO)
                xbmc.log("[IMDbRatings][DEBUG][P1] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season), xbmc.LOGINFO)
            try:
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P1] Using transport source=%s" % source_override, xbmc.LOGINFO)
                if IMDbSource == 0:
                    (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDbAPI_page(IMDb)
                    if updatedRating is None:
                        statusInfo = "(failure fetching rating from imdbapi.dev)"
                else:
                    (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P1] Result: rating=%s votes=%s" % (updatedRating, updatedVotes), xbmc.LOGINFO)
                if updatedRating is not None:
                    provider = "imdb"
            except Exception as e:
                xbmc.log("[IMDbRatings][ERROR][P1] %s" % str(e), xbmc.LOGERROR)
                updatedRating = None
                statusInfo = "IMDb transport error: %s" % str(e)

        # =========================================================
        # PRIORITY 1.5 - broken IMDb
        # =========================================================
        if updateitem in ("movie", "tvshow") and IMDb and updatedRating is None:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P1.5] IMDb=%s updatedRating=%s" % (IMDb, updatedRating), xbmc.LOGINFO)
                xbmc.log("[IMDbRatings][DEBUG][P1.5] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season), xbmc.LOGINFO)
            try:
                # Remove broken IMDb ID from Kodi DB
                if updateitem == "movie":
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                        '"params":{"movieid":%d,"uniqueid":{"imdb":""}},"id":1}'
                    ) % updateitem_id
                else:
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails",'
                        '"params":{"tvshowid":%d,"uniqueid":{"imdb":""}},"id":1}'
                    ) % updateitem_id
                xbmc.executeJSONRPC(jSonQuery)
                fallback_chain.append("BrokenIMDbID->Resolver")
                IMDb = None
            except Exception as e:
                xbmc.log("[IMDbRatings][Resolver] Failed clearing broken IMDb ID: %s" % str(e), xbmc.LOGERROR)
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P1.5] Clearing broken IMDb ID", xbmc.LOGINFO)

        # =========================================================
        # PRIORITY 2: Episode derivation using TMDB (WAF-proof)
        # =========================================================
        if updateitem == "episode" and updatedRating is None:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P2] ENTER episode derivation (TMDB mode)", xbmc.LOGINFO)
                xbmc.log("[IMDbRatings][DEBUG][P2] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season), xbmc.LOGINFO)
            try:
                # --------------------------------------------
                # Step 1: Get TV show details (already works)
                # --------------------------------------------
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P2] Query TVShowDetails tvshowid=%s" % tvshowid, xbmc.LOGINFO)
                tvshowdetails = xbmc.executeJSONRPC(json.dumps({
                    "jsonrpc": "2.0",
                    "method": "VideoLibrary.GetTVShowDetails",
                    "params": {
                        "tvshowid": tvshowid,
                        "properties": ["uniqueid"]
                    },
                    "id": 1
                }))
                tvshowdetails = json.loads(tvshowdetails).get("result", {}).get("tvshowdetails", {})
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P2] tvshowdetails=%s" % tvshowdetails, xbmc.LOGINFO)
                unique_ids = tvshowdetails.get("uniqueid", {})
                show_tmdb = unique_ids.get("tmdb")
                show_imdb = unique_ids.get("imdb")
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P2] show_tmdb=%s show_imdb=%s" % (show_tmdb, show_imdb), xbmc.LOGINFO)
                # --------------------------------------------
                # Step 2: REQUIRE TMDB ID
                # --------------------------------------------
                if not show_tmdb:
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P2] Missing TMDB ID -> cannot resolve episode IMDb", xbmc.LOGERROR)
                else:
                    # --------------------------------------------
                    # Step 3: Get episode number (CRITICAL)
                    # --------------------------------------------
                    ep_details = xbmc.executeJSONRPC(json.dumps({
                        "jsonrpc": "2.0",
                        "method": "VideoLibrary.GetEpisodeDetails",
                        "params": {
                            "episodeid": updateitem_id,
                            "properties": ["season", "episode"]
                        },
                        "id": 1
                    }))
                    ep_details = json.loads(ep_details).get("result", {}).get("episodedetails", {})
                    ep_season = ep_details.get("season")
                    ep_number = ep_details.get("episode")
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P2] episode S%sE%s" % (ep_season, ep_number), xbmc.LOGINFO)
                    if ep_season is None or ep_number is None:
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P2] Missing episode/season info", xbmc.LOGERROR)
                    else:
                        # --------------------------------------------
                        # Step 4: Resolve IMDb ID via TMDB
                        # --------------------------------------------
                        (ep_imdb_id, status) = get_IMDb_ID_from_TMDb(
                            "episode",
                            show_tmdb,
                            ep_season,
                            ep_number
                        )
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P2] TMDB->IMDb imdb_id=%s status=%s" % (ep_imdb_id, status), xbmc.LOGINFO)
                        # --------------------------------------------
                        # Step 5: VALIDATE + FETCH RATING
                        # --------------------------------------------
                        if ep_imdb_id:
                            testRating = None
                            testVotes = None
                            testTop250 = 0
                            testStatusInfo = ""
                            if DebugLog == "true":
                                xbmc.log("[IMDbRatings][DEBUG][P2] Resolved IMDb=%s -> querying dataset" % ep_imdb_id, xbmc.LOGINFO)
                            if LocalIMDbSQL:
                                (testRating, testVotes) = get_local_rating(ep_imdb_id)
                                if testRating is not None:
                                    testTop250 = 0
                                    testStatusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (testRating, testVotes)
                            if testRating is None:
                                if DebugLog == "true":
                                    xbmc.log("[IMDbRatings][DEBUG][P2] No Rating found in Local IMDb dataset. Fallback to IMDbAPI", xbmc.LOGINFO)
                                if IMDbSource == 0:
                                    (testRating, testVotes, testTop250, testStatusInfo) = parse_IMDbAPI_page(ep_imdb_id)
                                    if testRating is None:
                                        testStatusInfo = "(failure fetching rating from imdbapi or localset)"
                                        if DebugLog == "true":
                                            xbmc.log("[IMDbRatings][DEBUG][P2] No Rating found in IMDbAPI", xbmc.LOGINFO)
                                else:
                                    (testRating, testVotes, testTop250, testStatusInfo) = parse_IMDb_page(ep_imdb_id)
                            if DebugLog == "true":
                                xbmc.log("[IMDbRatings][DEBUG][P2] Dataset result: rating=%s votes=%s" % (testRating, testVotes), xbmc.LOGINFO)
                            # -------------------------------------------------
                            # ONLY NOW WRITE IMDb ID BACK TO KODI
                            # -------------------------------------------------
                            if testRating is not None:
                                if DebugLog == "true":
                                    xbmc.log("[IMDbRatings][DEBUG][P2][WRITE] episodeid=%s imdb=%s rating=%s votes=%s" % (updateitem_id, ep_imdb_id, testRating, testVotes), xbmc.LOGINFO)
                                jSonQuery = (
                                    '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails",'
                                    '"params":{"episodeid":%d,"uniqueid":{"imdb":"%s"}},"id":1}'
                                ) % (updateitem_id, ep_imdb_id)
                                xbmc.executeJSONRPC(jSonQuery)
                                IMDb = ep_imdb_id
                                updatedRating = testRating
                                updatedVotes = testVotes
                                updatedTop250 = testTop250
                                statusInfo = testStatusInfo
                                provider = "imdb"
                                if "TMDB->EpisodeIMDb" not in fallback_chain:
                                    fallback_chain.append("TMDB->EpisodeIMDb")
                            else:
                                if DebugLog == "true":
                                    xbmc.log("[IMDbRatings][DEBUG][P2] No rating found for %s (%s)" % (ep_imdb_id, testStatusInfo), xbmc.LOGERROR)
                                statusInfo = testStatusInfo
                        else:
                            if DebugLog == "true":
                                xbmc.log("[IMDbRatings][DEBUG][P2] TMDB did not return IMDb ID (%s)" % status, xbmc.LOGERROR)
            except Exception as e:
                xbmc.log("[IMDbRatings][ERROR][P2] Exception: %s" % str(e), xbmc.LOGERROR)

        # =========================================================
        # PRIORITY 3 - RECOVER IMDb FROM TMDB (MOVIE/TVSHOW)
        # =========================================================
        if updateitem in ("movie", "tvshow") and updatedRating is None and TMDB and TMDB != "0" and not IMDb:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P3] ENTER movie/tvshow derivation (TMDB mode)", xbmc.LOGINFO)
                xbmc.log("[IMDbRatings][DEBUG][P3] INPUT updateitem=%s TMDB=%s IMDb=%s updatedRating=%s" % (updateitem, TMDB, IMDb, updatedRating), xbmc.LOGINFO)
            recovered_imdb, imdbStatus = get_IMDb_ID_from_TMDb(updateitem, TMDB)
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P3] TMDB->IMDb result imdb=%s status=%s" % (recovered_imdb, imdbStatus), xbmc.LOGINFO)
            if recovered_imdb:
                IMDb = recovered_imdb
                fallback_chain.append("TMDB->IMDb")
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P3] Writing IMDb=%s back to Kodi" % IMDb, xbmc.LOGINFO)
                # Write IMDb back to Kodi
                if updateitem == "movie":
                    jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":%d,"uniqueid":{"imdb":"%s"}},"id":1}' % (updateitem_id, IMDb)
                else:
                    jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":%d,"uniqueid":{"imdb":"%s"}},"id":1}' % (updateitem_id, IMDb)
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P3] JSONRPC=%s" % jSonQuery, xbmc.LOGINFO)
                xbmc.executeJSONRPC(jSonQuery)
                try:
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P3] Fetch rating for IMDb=%s LocalIMDbSQL=%s" % (IMDb, LocalIMDbSQL), xbmc.LOGINFO)
                    # -------------------------------------------------
                    # LOCAL DATASET FIRST (if enabled)
                    # -------------------------------------------------
                    if LocalIMDbSQL:
                        (updatedRating, updatedVotes) = get_local_rating(IMDb)
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P3] Local dataset result rating=%s votes=%s" % (updatedRating, updatedVotes), xbmc.LOGINFO)
                        if updatedRating is not None:
                            provider = "imdb"
                            updatedTop250 = 0
                            statusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (updatedRating, updatedVotes)
                    # -------------------------------------------------
                    # FALLBACK TO IMDb TRANSPORT
                    # -------------------------------------------------
                    if updatedRating is None:
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P3] Falling back to IMDb transport =%s" % source_override, xbmc.LOGINFO)
                        if IMDbSource == 0:
                            (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDbAPI_page(IMDb)
                            if updatedRating is None:
                                statusInfo = "(failure fetching rating from imdbapi or localset)"
                        else:
                            (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P3] Transport result rating=%s votes=%s top250=%s" % (updatedRating, updatedVotes, updatedTop250), xbmc.LOGINFO)
                        if updatedRating is not None:
                            provider = "imdb"
                except Exception as e:
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][ERROR][P3] Exception during rating fetch: %s" % str(e), xbmc.LOGERROR)
                    updatedRating = None
            else:
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P3] No IMDb recovered from TMDB", xbmc.LOGINFO)
        # =========================================================
        # PRIORITY 3.5 - TITLE + YEAR -> TMDB -> IMDb (NO IDs CASE)
        # =========================================================
        if updateitem == "movie" and updatedRating is None and not IMDb and not TMDB:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P3.5] ENTER movie derivation from title + year", xbmc.LOGINFO)
                xbmc.log("[IMDbRatings][DEBUG][P3.5] INPUT title=%s id=%s" % (title, updateitem_id), xbmc.LOGINFO)
            try:
                # Get year from Kodi DB
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails",'
                    '"params":{"movieid":%d,"properties":["year"]},"id":1}'
                ) % updateitem_id
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P3.5] JSONRPC year query=%s" % jSonQuery, xbmc.LOGINFO)
                jSonResponse = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
                moviedetails = jSonResponse.get("result", {}).get("moviedetails", {})
                movie_year = moviedetails.get("year")
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P3.5] Extracted year=%s" % movie_year, xbmc.LOGINFO)
                resolved_tmdb, resolve_method = search_TMDB_by_title("movie", title, movie_year, updateitem_id)
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][DEBUG][P3.5] TMDB search result tmdb=%s method=%s" % (resolved_tmdb, resolve_method), xbmc.LOGINFO)
                if resolved_tmdb:
                    TMDB = str(resolved_tmdb)
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P3.5] Writing TMDB=%s to Kodi" % TMDB, xbmc.LOGINFO)
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                        '"params":{"movieid":%d,"uniqueid":{"tmdb":"%s"}},"id":1}'
                    ) % (updateitem_id, TMDB)
                    xbmc.executeJSONRPC(jSonQuery)
                    recovered_imdb, imdbStatus = get_IMDb_ID_from_TMDb("movie", TMDB)
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P3.5] TMDB->IMDb imdb=%s status=%s" % (recovered_imdb, imdbStatus), xbmc.LOGINFO)
                    if recovered_imdb:
                        IMDb = recovered_imdb
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P3.5] Writing IMDb=%s to Kodi" % IMDb, xbmc.LOGINFO)
                        jSonQuery = (
                            '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                            '"params":{"movieid":%d,"uniqueid":{"imdb":"%s"}},"id":1}'
                        ) % (updateitem_id, IMDb)
                        xbmc.executeJSONRPC(jSonQuery)
                        if resolve_method == "Title+Year":
                            fallback_chain.append("Title+Year->TMDB")
                        elif resolve_method == "Title+Year+Director":
                            fallback_chain.append("Title+Year+Director->TMDB")
                        fallback_chain.append("TMDB->IMDb")
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P3.5] Fetch rating for IMDb=%s" % IMDb, xbmc.LOGINFO)
                        # -------------------------------------------------
                        # LOCAL DATASET FIRST (if enabled)
                        # -------------------------------------------------
                        if LocalIMDbSQL:
                            (updatedRating, updatedVotes) = get_local_rating(IMDb)
                            if DebugLog == "true":
                                xbmc.log("[IMDbRatings][DEBUG][P3.5] Local dataset result rating=%s votes=%s" % (updatedRating, updatedVotes), xbmc.LOGINFO)
                            if updatedRating is not None:
                                provider = "imdb"
                                updatedTop250 = 0
                                statusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (updatedRating, updatedVotes)
                        # -------------------------------------------------
                        # FALLBACK TO IMDb TRANSPORT
                        # -------------------------------------------------
                        if updatedRating is None:
                            if DebugLog == "true":
                                xbmc.log("[IMDbRatings][DEBUG][P3.5] Falling back to IMDb transport =%s" % source_override, xbmc.LOGINFO)
                            if IMDbSource == 0:
                                (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDbAPI_page(IMDb)
                                if updatedRating is None:
                                    statusInfo = "(failure fetching rating from imdbapi or localset)"
                            else:
                                (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
                            if DebugLog == "true":
                                xbmc.log("[IMDbRatings][DEBUG][P3.5] Transport result rating=%s votes=%s" % (updatedRating, updatedVotes), xbmc.LOGINFO)
                            if updatedRating is not None:
                                provider = "imdb"
            except Exception as e:
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][ERROR][P3.5] Exception: %s" % str(e), xbmc.LOGERROR)
                updatedRating = None

        # =========================================================
        # PRIORITY 4 - TMDB FALLBACK (ONLY IF IMDb IMPOSSIBLE)
        # =========================================================
        if updatedRating is None and not IMDb:
            if DebugLog == "true":
                xbmc.log("[IMDbRatings][DEBUG][P4] Get ratings from TMDB - IMDb not resolved)", xbmc.LOGINFO)
                xbmc.log("[IMDbRatings][DEBUG][P4] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season), xbmc.LOGINFO)
            try:
                # -------------------------------------------------
                # MOVIE / TVSHOW
                # -------------------------------------------------
                if updateitem in ("movie", "tvshow") and TMDB and TMDB != "0":
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P4] Fetch TMDB rating for %s id=%s" % (updateitem, TMDB), xbmc.LOGINFO)
                    (updatedRating, updatedVotes, statusInfo) = get_TMDB_rating(updateitem, TMDB)
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P4] TMDB result rating=%s votes=%s status=%s" % (updatedRating, updatedVotes, statusInfo), xbmc.LOGINFO)
                    # ---------------------------------------------------------------------------------------------------
                    # INVALID TMDB ID (404)
                    # ---------------------------------------------------------------------------------------------------
                    if updatedRating is None and statusInfo and "404" in statusInfo:
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P4] TMDB returned 404 - marking as neutral", xbmc.LOGINFO)
                        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
                        flock.acquire()
                        try:
                            statusLog(
                                title +
                                " (IMDb ID: " + sIMDb +
                                ", TVDB ID: " + sTVDB +
                                ", TMDB ID: " + sTMDB +
                                ")  --> (Invalid TMDB ID. Marking as neutral)"
                            )
                        finally:
                            flock.release()
                        if updateitem == "movie":
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                                '"params":{"movieid":%d,"uniqueid":{"tmdb":"0"}},"id":1}'
                            ) % updateitem_id
                        else:
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails",'
                                '"params":{"tvshowid":%d,"uniqueid":{"tmdb":"0"}},"id":1}'
                            ) % updateitem_id
                        xbmc.executeJSONRPC(jSonQuery)
                        TMDB = "0"
                        updatedRating = None
                        provider = None
                    # -------------------------------------------------
                    # VALID TMDB RATING
                    # -------------------------------------------------
                    elif updatedRating is not None:
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P4] Using TMDB rating", xbmc.LOGINFO)
                        provider = "tmdb"
                        updatedTop250 = 0
                        fallback_chain.append("TMDB rating")
                # -------------------------------------------------
                # EPISODE (use show TMDB)
                # -------------------------------------------------
                elif updateitem == "episode" and tvshowid:
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P4] Episode fallback using show TMDB", xbmc.LOGINFO)
                    show_tmdb = None
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                        '"params":{"tvshowid":%d,"properties":["uniqueid"]},"id":1}'
                    ) % tvshowid
                    jSonResponse = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
                    tvshowdetails = jSonResponse.get("result", {}).get("tvshowdetails", {})
                    unique_id = tvshowdetails.get("uniqueid")
                    if unique_id:
                        show_tmdb = unique_id.get("tmdb")
                    if DebugLog == "true":
                        xbmc.log("[IMDbRatings][DEBUG][P4] show_tmdb=%s" % show_tmdb, xbmc.LOGINFO)
                    if show_tmdb:
                        ep_number = int(title.split("x")[-1])
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P4] Fetch TMDB episode rating S%sE%s" % (season, ep_number), xbmc.LOGINFO)
                        (updatedRating, updatedVotes, statusInfo) = get_TMDB_rating(
                            "episode",
                            show_tmdb,
                            season,
                            ep_number
                        )
                        if DebugLog == "true":
                            xbmc.log("[IMDbRatings][DEBUG][P4] Episode TMDB result rating=%s votes=%s status=%s" % (updatedRating, updatedVotes, statusInfo), xbmc.LOGINFO)
                        if updatedRating is not None:
                            provider = "tmdb"
                            fallback_chain.append("Episode->ShowTMDB")
            except Exception as e:
                if DebugLog == "true":
                    xbmc.log("[IMDbRatings][ERROR][P4] Exception: %s" % str(e), xbmc.LOGERROR)
                updatedRating = None
                statusInfo = "TMDB parse error: %s" % str(e)

        # =========================================================
        # LOGGING
        # =========================================================
        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
        if updatedRating is not None:
            statusInfo = "Rating: %s, Votes: %s" % (updatedRating, updatedVotes)
            if fallback_chain:
                statusInfo += " (fallback: " + " -> ".join(fallback_chain) + ")"
        flock.acquire()
        try:
            statusLog(
                title +
                " (IMDb ID: " + sIMDb +
                ", TVDB ID: " + sTVDB +
                ", TMDB ID: " + sTMDB +
                ")  --> " + (statusInfo if statusInfo else "(no rating resolved - possible outdated or incorrect IDs in Kodi database)")
            )
        finally:
            flock.release()

        # =========================================================
        # WRITE RATING TO KODI
        # =========================================================
        if updatedRating is not None and provider:
            rating_block = (
                '"ratings":{"' + provider + '":{"rating":' +
                str(updatedRating) +
                ',"votes":' +
                str(updatedVotes).replace(",", "") +
                ',"default":' +
                IMDbDefault +
                '}}'
            )
            if updateitem == "movie":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":%d,%s},"id":1}' % (updateitem_id, rating_block)
            elif updateitem == "tvshow":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":%d,%s},"id":1}' % (updateitem_id, rating_block)
            elif updateitem == "episode":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":%d,%s},"id":1}' % (updateitem_id, rating_block)
            xbmc.executeJSONRPC(jSonQuery)
    elif updateitem == "season":
        doUpdateEpisodesBySeason(updateitem_id, IMDb, season, progress, percentage, flock)
    lock.acquire()
    num_threads -= 1
    lock.release()



class Movies:
    def __init__(self):
        self.lock = allocate_lock()
        self.flock = allocate_lock()

    def doUpdate(self):
        self.AllMovies = []
        self.getDBMovies()
        if len( self.AllMovies ) == 0:
            xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32840) )
            return
        if ShowNotifications == "true":
            doNotify( addonLanguage(32255), 5000 )
            xbmc.sleep(5000)
        statusLog( "----------------------------------------------------------------------------------------------------------------" )
        statusLog( datetime.now().strftime("%H:%M:%S") + " - " + "Scheduled/manual ratings update for movies started" )
        self.doUpdateMovies()
        statusLog( datetime.now().strftime("%H:%M:%S") + " - " + "Scheduled/manual ratings update for movies finished" )
        if ShowNotifications == "true":
            doNotify( addonLanguage(32258), 5000 )
            xbmc.sleep(8000)
        return


    def getDBMovies(self):
        self.AllMovies = []
        dateAfter = None
        if UpdateMovieTime > 0:
            dateAfter = (datetime.now() - timedelta(days=365 * UpdateMovieTime)).date()
            log("Movie premiered filter enabled: date >= %s" % dateAfter)
        else:
            log("Movie premiered filter disabled: updating ALL movies")
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"params":{"properties":["uniqueid","title","year","premiered"],'
            '"sort":{"method":"year","order":"descending"}},'
            '"id":1}'
        )
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        try:
            movies = jSonResponse.get('result', {}).get('movies', [])
            log("Movies returned by Kodi DB (before filter): %d" % len(movies))
            for item in movies:
                premiered = item.get('premiered')
                # Apply premiered date filter
                if dateAfter:
                    try:
                        if not premiered:
                            continue
                        if datetime.strptime(premiered, "%Y-%m-%d").date() < dateAfter:
                            continue
                    except:
                        continue
                IMDb = TVDB = TMDB = None
                unique_id = item.get('uniqueid')
                if unique_id:
                    IMDb = unique_id.get('imdb')
                    TVDB = unique_id.get('tvdb')
                    TMDB = unique_id.get('tmdb')
                    IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                movieid = item.get('movieid')
                title = item.get('title')
                self.AllMovies.append((movieid, IMDb, TVDB, TMDB, title))
            log("Movies selected for update (after filter): %d" % len(self.AllMovies))
        except Exception as e:
            log("getDBMovies exception: %s" % repr(e))
        return



    def doUpdateMovies(self):
        global num_threads
        AllMovies = len(self.AllMovies)
        Counter = 0
        progress = None
        if ShowProgress == "true":
            progress = xbmcgui.DialogProgressBG()
            progress.create(addonLanguage(32260))
        for Movie in self.AllMovies:
            while num_threads > max_threads * 2:
                xbmc.sleep(500)
            if ShowProgress == "true":
                Counter += 1
                progress.update(
                    int((Counter * 100) / AllMovies),
                    addonLanguage(32260),
                    Movie[4]
                )
            IMDb = Movie[1]
            TVDB = Movie[2]
            TMDB = Movie[3]
            # TRY TO OBTAIN IMDb ID (only if TMDB exists)
            if IMDb is None and TMDB:
                (IMDb, statusInfo) = get_IMDb_ID_from_TMDb("movie", TMDB)
                # DO NOT skip if both IMDb and TMDB are None. Title+Year+(Director if needed) fallback will be handled in thread_parse_IMDb_page().
            # ALWAYS START THREAD (even if IMDb and TMDB are None)
            start_new_thread(
                thread_parse_IMDb_page,
                (
                    "movie",
                    Movie[0],
                    IMDb,
                    TVDB,
                    TMDB,
                    Movie[4],
                    -1,
                    None,
                    progress,
                    0,
                    self.lock,
                    self.flock
                )
            )
            self.lock.acquire()
            num_threads += 1
            self.lock.release()
        # -------------------------------------------------
        # WAIT FOR THREADS TO FINISH
        # -------------------------------------------------
        while num_threads > 0:
            xbmc.sleep(500)
        if ShowProgress == "true":
            xbmc.sleep(1000)
            progress.close()
        return



class TVShows:
    def __init__(self):
        self.lock = allocate_lock()
        self.flock = allocate_lock()
        self.episodes_total_before = 0
        self.episodes_total_after = 0
        self._episode_filter_logged = False

    def doUpdate(self):
        self.AllTVShows = []
        self.getDBTVShows()
        if len( self.AllTVShows ) == 0:
            xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32841) )
            return
        if ShowNotifications == "true":
            doNotify( addonLanguage(32256), 5000 )
            xbmc.sleep(5000)
        statusLog( "----------------------------------------------------------------------------------------------------------------" )
        statusLog( datetime.now().strftime("%H:%M:%S") + " - " + "Scheduled/manual ratings update for TV shows started" )
        self.doUpdateTVShows()
        statusLog( datetime.now().strftime("%H:%M:%S") + " - " + "Scheduled/manual ratings update for TV shows finished" )
        if ShowNotifications == "true":
            doNotify( addonLanguage(32259), 5000 )
            xbmc.sleep(5000)
        return

    def getDBTVShows(self):
        if UpdateTime > 0:
            dateAfter = (datetime.now() - timedelta(days=UpdateTime)).strftime('%Y-%m-%d')
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["uniqueid","title"], "filter": {"field": "dateadded", "operator": "greaterthan", "value": "' + str( dateAfter ) + '"}, "sort":{"method": "dateadded","order":"descending"}},"id":1}'
        else:
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["uniqueid","title"], "sort":{"method": "dateadded","order":"descending"}},"id":1}'
        jSonResponse = xbmc.executeJSONRPC( jSonQuery )
        jSonResponse = jSon.loads( jSonResponse )
        try:
            if 'tvshows' in jSonResponse['result']:
                for item in jSonResponse['result']['tvshows']:
                    IMDb = None; TVDB = None; TMDB = None
                    unique_id = item.get('uniqueid')
                    if unique_id != None:
                        IMDb = unique_id.get('imdb')
                        TVDB = unique_id.get('tvdb')
                        TMDB = unique_id.get('tmdb')
                        IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                    tvshowid = item.get('tvshowid')
                    title = item.get('title')
                    self.AllTVShows.append((tvshowid, IMDb, TVDB, TMDB, title))
        except: pass
        return


    def doUpdateTVShows(self):
        global num_threads
        AllTVShows = len(self.AllTVShows)
        Counter = 0
        percentage = 0
        progress = None
        if ShowProgress == "true":
            progress = xbmcgui.DialogProgressBG()
            progress.create(addonLanguage(32260))
        for TVShow in self.AllTVShows:
            while num_threads > max_threads:
                xbmc.sleep(500)
            if ShowProgress == "true":
                Counter += 1
                percentage = (Counter * 100) / AllTVShows
                progress.update(int(percentage), addonLanguage(32260), TVShow[4])
            IMDb = TVShow[1]
            TVDB = TVShow[2]
            TMDB = TVShow[3]
            # Try to resolve IMDb only if missing
            if IMDb is None:
                IMDb, statusInfo = get_tvshow_IMDb_ID("tvshow", TVShow[0], TVDB, TMDB, TVShow[4])
            # DO NOT EXIT if IMDb is None. Let thread handle TMDB fallback / TVDB->TMDB mapping
            start_new_thread(
                thread_parse_IMDb_page,
                ("tvshow", TVShow[0], IMDb, TVDB, TMDB, TVShow[4], -1, None, progress, 0, self.lock, self.flock)
            )
            self.lock.acquire()
            num_threads += 1
            self.lock.release()
            # ALWAYS update episodes
            self.doUpdateEpisodes(TVShow[0], TMDB, -1, progress, percentage)
        while num_threads > 0:
            xbmc.sleep(500)
        # GLOBAL EPISODE COUNT (always executed now)
        try:
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
                '"params":{"limits":{"start":0,"end":1}},'
                '"id":1}'
            )
            response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
            total_episodes = response.get("result", {}).get("limits", {}).get("total", 0)
        except:
            total_episodes = 0
        log("All episodes returned by Kodi DB (before filter): %d" % total_episodes)
        log("All episodes selected for update (after filter): %d" % self.episodes_total_after)
        if ShowProgress == "true":
            xbmc.sleep(1000)
            progress.close()
        return


    def doUpdateEpisodes(self, tvshowid, tvshowTMDB, season, progress, percentage, datefilter=False):
        global num_threads
        dateAfter = None
        if UpdateTime > 0:
            dateAfter = (datetime.now() - timedelta(days=UpdateTime)).date()
            if not self._episode_filter_logged:
                log("Episode firstaired filter enabled: date >= %s" % dateAfter)
                self._episode_filter_logged = True
        else:
            if not self._episode_filter_logged:
                log("Episode firstaired filter disabled: updating ALL episodes")
                self._episode_filter_logged = True
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{'
            '"tvshowid":%d,'
            '"properties":["uniqueid","episode","season","showtitle","firstaired"],'
            '"sort":{"method":"episode"}'
            '},"id":1}'
        ) % tvshowid
        response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        try:
            episodes = response.get('result', {}).get('episodes', [])
            self.episodes_total_before += len(episodes)
            selected = 0
            for item in episodes:
                firstaired = item.get('firstaired')
                if not firstaired:
                    continue
                if dateAfter:
                    try:
                        if datetime.strptime(firstaired, "%Y-%m-%d").date() < dateAfter:
                            continue
                    except:
                        continue
                selected += 1
                while num_threads > max_threads:
                    xbmc.sleep(500)
                episodeid = item.get('episodeid')
                season = item.get('season')
                episode = "%02d" % item.get('episode')
                title = item.get('showtitle') + " " + str(season) + "x" + episode
                unique_id = item.get('uniqueid', {})
                IMDb = unique_id.get('imdb')
                TVDB = unique_id.get('tvdb')
                TMDB = unique_id.get('tmdb')
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                start_new_thread(
                    thread_parse_IMDb_page,
                    (
                        "episode",
                        episodeid,
                        IMDb,
                        TVDB,
                        TMDB,
                        title,
                        season,
                        tvshowid,
                        progress,
                        percentage,
                        self.lock,
                        self.flock
                    )
                )
                self.lock.acquire()
                num_threads += 1
                self.lock.release()
            self.episodes_total_after += selected
        except Exception as e:
            xbmc.log("[IMDbRatings][ERROR] Exception: %s" % str(e), xbmc.LOGERROR)
        return


def perform_update():
    if not wait_for_internet(wait=3, retry=1):
        xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32257) )
        return
    if addonSettings.getSetting( "PerformingUpdate" ) == "true":
        xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32251) )
        return
    if onMovies == "false" and onTVShows == "false":
        xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32842) )
        return
    addonSettings.setSetting( "PerformingUpdate", "true" )
    # run library update
    if onMovies == "true":
        Movies().doUpdate()
    if onTVShows == "true":
        TVShows().doUpdate()
    addonSettings.setSetting( "PerformingUpdate", "false" )
    if ShowLogMessage == "true" and addonSettings.getSetting( "LogDialog") == "true":
        xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32824) )
        addonSettings.setSetting( "LogDialog", "false" )
    return