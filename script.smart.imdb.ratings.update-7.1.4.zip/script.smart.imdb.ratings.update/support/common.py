# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import json as jSon
import sys
import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import os, re, unicodedata
from datetime import datetime, timedelta
addon = xbmcaddon.Addon()
ADDON_DATA_PATH = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
DB_FOLDER = os.path.join(ADDON_DATA_PATH, "db")
LOGS_FOLDER = os.path.join(ADDON_DATA_PATH, "logs")


addonSettings           = xbmcaddon.Addon("script.smart.imdb.ratings.update")
addonName               = addonSettings.getAddonInfo("name")
addonVersion            = addonSettings.getAddonInfo("version")
addonIcon               = os.path.join(addonSettings.getAddonInfo("path"), "icon.png")
addonProfile            = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile"))
addonLanguage           = addonSettings.getLocalizedString
IMDbSource              = int(addonSettings.getSetting("IMDbSource")) #0 - IMDb JSON (api.tiffara.com), 1 - Direct IMDb HTML
LocalIMDbSQL            = addonSettings.getSettingBool("LocalIMDbSQL")
DatasetFallbackToOnline = addonSettings.getSettingBool("DatasetFallbackToOnline")
Max_requests            = int(addonSettings.getSetting("MAXRequests") or 25)
Time_slot               = int(addonSettings.getSetting("TimeSlot") or 10)
WhereLogs               = int(addonSettings.getSetting("WhereLogs") or 0) #0 - add-one's activity log, 1 - kodi.log
RateLimitThreshold      = Time_slot / Max_requests
onMovies                = addonSettings.getSetting("Movies")
onTVShows               = addonSettings.getSetting("TVShows")
MonthlyFullRefresh      = addonSettings.getSetting("MonthlyFullRefresh")
Top250Support           = addonSettings.getSetting("Top250Support")
Top250Source            = addonSettings.getSetting("Top250SelectLocation")
ShowNotifications       = addonSettings.getSetting("ShowNotifications")
ShowProgress            = addonSettings.getSetting("ShowProgress")
ShowLogMessage          = addonSettings.getSetting("ShowLogMessage")
DebugLog                = addonSettings.getSetting("DebugLog")
Sound                   = addonSettings.getSetting("NotificationsSound")
ScheduleEnabled         = addonSettings.getSetting("ScheduleEnabled")
UpdateRatingsAtStart    = addonSettings.getSetting("UpdateRatingsAtStart")
if (int(addonSettings.getSetting("UpdateTime" )) == 1):
    UpdateTime = 32
elif (int(addonSettings.getSetting("UpdateTime" )) == 2):
    UpdateTime = 93
elif (int(addonSettings.getSetting("UpdateTime" )) == 3):
    UpdateTime = 183
elif (int(addonSettings.getSetting("UpdateTime" )) == 4):
    UpdateTime = 366
else:
    UpdateTime = 0
UpdateMovieTime   = int(addonSettings.getSetting("UpdateMovieTime"))
DayTime           = addonSettings.getSetting("DayTime")
def_threads = [1, 2, 4, 8, 16]
NumberOfThreads = def_threads[int(addonSettings.getSetting("NumberOfThreads"))]


def printable_IDs(imdb, tvdb, tmdb):
    if imdb == None: imdb = addonLanguage(32531)
    if tvdb == None: tvdb = addonLanguage(32531)
    if tmdb == None: tmdb = addonLanguage(32531)
    return imdb, tvdb, tmdb


def normalize_IDs(imdb, tvdb, tmdb):
    if imdb == "": imdb = None
    if tvdb == "": tvdb = None
    if tmdb == "": tmdb = None
    return imdb, tvdb, tmdb


# ----------------------------------------------------------
# ENSURE DIRECTORIES
# ----------------------------------------------------------
def ensure_logs_folder():
    if not xbmcvfs.exists(LOGS_FOLDER):
        xbmcvfs.mkdirs(LOGS_FOLDER)


def ensure_db_folder():
    if not xbmcvfs.exists(DB_FOLDER):
        xbmcvfs.mkdirs(DB_FOLDER)


def getRateLimitThreshold():
    return (
        int(addonSettings.getSetting("TimeSlot") or 10) /
        float(int(addonSettings.getSetting("MAXRequests") or 25))
    )


def getEnabledWeekdays():
    mode = addonSettings.getSetting("ScheduleMode")
    if mode == "0":  # every day
        return [True, True, True, True, True, True, True]
    elif mode == "1":  # single day
        selected = int(addonSettings.getSetting("SingleDay"))
        return [i == selected for i in range(7)]
    else:  # custom
        return [
            addonSettings.getSetting("ScheduleMon") == "true",
            addonSettings.getSetting("ScheduleTue") == "true",
            addonSettings.getSetting("ScheduleWed") == "true",
            addonSettings.getSetting("ScheduleThu") == "true",
            addonSettings.getSetting("ScheduleFri") == "true",
            addonSettings.getSetting("ScheduleSat") == "true",
            addonSettings.getSetting("ScheduleSun") == "true",
        ]


def detectTVShowStatusSupport(tvshowid):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0",'
            '"method":"VideoLibrary.GetTVShowDetails",'
            '"params":{"tvshowid":%d,"properties":["status"]},'
            '"id":1}'
        ) % tvshowid
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        return ("result" in jSonResponse and "tvshowdetails" in jSonResponse["result"] and "status" in jSonResponse["result"]["tvshowdetails"])
    except Exception:
        return False


def UpdateTVShowStatusFromTMDB(tvshowid, TMDB, Title):
    from core.tmdb_api import get_TMDB_tvshow_status
    (tvshow_status, statusInfo) = get_TMDB_tvshow_status(TMDB)
    if tvshow_status is None:
        return (None, statusInfo)
    jSonQuery = (
        '{"jsonrpc":"2.0",'
        '"method":"VideoLibrary.SetTVShowDetails",'
        '"params":{"tvshowid":' + str(tvshowid) +
        ',"status":"' + tvshow_status + '"},'
        '"id":1}'
    )
    response = xbmc.executeJSONRPC(jSonQuery)
    return (tvshow_status, "OK")


#temporary for diagnose purpose
def show_settings_debug():
    lines = []
    lines.append(f"IMDbSource: {IMDbSource}")
    lines.append(f"LocalIMDbSQL: {LocalIMDbSQL}")
    lines.append(f"MAXRequests: {Max_requests}")
    lines.append(f"TimeSlot: {Time_slot}")
    lines.append(f"RateLimitThreshold: {RateLimitThreshold}")
    lines.append(f"Movies: {onMovies}")
    lines.append(f"TVShows: {onTVShows}")
    lines.append(f"UpdateTime (days): {UpdateTime}")
    lines.append(f"UpdateMovieTime: {UpdateMovieTime}")
    lines.append(f"ShowNotifications: {ShowNotifications}")
    lines.append(f"NotificationsSound: {Sound}")
    lines.append(f"ShowProgress: {ShowProgress}")
    lines.append(f"DebugLog: {DebugLog}")
    lines.append(f"ShowLogMessage: {ShowLogMessage}")
    lines.append(f"ScheduleEnabled: {ScheduleEnabled}")
    lines.append(f"DayTime: {DayTime}")
    lines.append(f"NumberOfThreads index: {addonSettings.getSetting('NumberOfThreads')}")
    lines.append(f"NumberOfThreads value: {NumberOfThreads}")
    lines.append(f"Enabled weekdays: {getEnabledWeekdays()}")
    xbmcgui.Dialog().textviewer("Addon Settings Debug", "\n".join(lines))
#temporary



def cleanup_libraryHealth_log():
    try:
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_libraryHealth.log"
        with open(log_path, "w") as f:
            f.write("--------------------------------------------------------------------------------\n")
            f.write("Smart IMDb Ratings Update - Library Health Report\n")
            f.write("Generated: %s\n" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            f.write("Add-on version: %s | Kodi version: %s\n" % (addonVersion, get_kodi_version()))
            f.write("--------------------------------------------------------------------------------\n")
    except Exception as e:
        logError("LibraryHealth", "Unable to initialize library health log: %s" % str(e))


def cleanup_activity_log():
    try:
        retention_map = {
            0: 3,
            1: 7,
            2: 14,
            3: 31,
            4: 90,
            5: 182
        }
        setting_value = int(addonSettings.getSetting("ActivityLogDays") or 3)
        days = retention_map.get(setting_value, 31)
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_activity.log"
        cutoff = datetime.now() - timedelta(days=days)
        logInfo("ActivityLog", "Keeping activity log entries from last %d days" % days)
        with open(log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        filtered = []
        for line in lines:
            try:
                line_date = datetime.strptime(line[:19], "%Y-%m-%d %H:%M:%S")
                if line_date >= cutoff:
                    filtered.append(line)
            except:
                filtered.append(line)
        with open(log_path, "w", encoding="utf-8") as f:
            f.writelines(filtered)
    except Exception as e:
        xbmc.log("[IMDbRatings][ActivityLog] Failed: %s" % str(e), xbmc.LOGERROR)


def activityLog(textMessage):
    try:
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_activity.log"
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("%s - %s\n" % (timestamp, textMessage))
    except Exception as e:
        xbmc.log("[IMDbRatings][ActivityLog] Failed: %s" % str(e), xbmc.LOGERROR)


def statusLog(textMessage):
    try:
        log_path = get_current_log_path()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("%s - %s\n" % (timestamp, textMessage))
    except Exception as e:
        xbmc.log("[IMDbRatings][Log] statusLog failed: %s" % str(e), xbmc.LOGERROR)


def libraryHealthLog(textMessage):
    try:
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_libraryHealth.log"
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("%s\n" % (textMessage))
    except Exception as e:
        xbmc.log("[IMDbRatings][HealthLog] Failed: %s" % str(e), xbmc.LOGERROR)


def logInfo(component, textMessage):
    message = "[IMDbRatings][%s] %s" % (component, textMessage)
    if WhereLogs == 1:
        xbmc.log(message, xbmc.LOGINFO)
    else:
        try:
            activityLog(message)
        except:
            pass


def logDebug(component, textMessage):
    message = "[IMDbRatings][DEBUG][%s] %s" % (component, textMessage)
    if WhereLogs == 1:
        xbmc.log(message, xbmc.LOGINFO)
    else:
        try:
            activityLog(message)
        except:
            pass


def logError(component, textMessage):
    message = "[IMDbRatings][ERROR][%s] %s" % (component, textMessage)
    if WhereLogs == 1:
        xbmc.log(message, xbmc.LOGERROR)
    else:
        try:
            activityLog(message)
        except:
            pass


def doNotify(textMessage, millSec):
    dialog = xbmcgui.Dialog()
    if Sound == "true":
        playSound = True
    else:
        playSound = False
    dialog.notification(addonName, textMessage, addonIcon, millSec, playSound)




LOG_INITIALIZED_DATE = False

def get_logs_dir():
    logs_dir = addonProfile + "/logs"
    if not xbmcvfs.exists(logs_dir):
        xbmcvfs.mkdirs(logs_dir)
    return logs_dir


def get_current_log_path():
    logs_dir = get_logs_dir()
    filename = "SmartIMDb_%s.log" % datetime.now().strftime("%Y%m%d")
    return logs_dir + "/" + filename


def cleanup_old_logs():
    try:
        logs_dir = get_logs_dir()
        keep_logs = int(addonSettings.getSetting("LogRotate") or 14)
        files = xbmcvfs.listdir(logs_dir)[1]
        log_files = []
        for f in files:
            if re.match(r"SmartIMDb_\d{8}\.log$", f):
                log_files.append(f)
        log_files.sort(reverse=True)
        old_logs = log_files[keep_logs:]
        for old_log in old_logs:
            try:
                xbmcvfs.delete(logs_dir + "/" + old_log)
            except:
                pass
    except Exception as e:
        xbmc.log("[IMDbRatings][Log] cleanup_old_logs failed: %s" % str(e), xbmc.LOGERROR)


def ensure_log_initialized(trigger="Service startup"):
    global LOG_INITIALIZED_DATE
    today = datetime.now().strftime("%Y-%m-%d")
    if LOG_INITIALIZED_DATE == today:
        return
    log_path = get_current_log_path()
    try:
        if IMDbSource == 1:
            UpdateSource = "IMDb HTTP"
        else:
            UpdateSource = "IMDbAPI (https://api.tiffara.com)"
        if addonSettings.getSetting("LocalIMDbSQL") == "true":
            UpdateSource = "IMDb dataset from  https://developer.imdb.com/non-commercial-datasets/"
        if Top250Support == "true":
            if Top250Source == "0":
                Top250S = "Top250.txt in add-on data /db folder"
            if Top250Source == "1":
                Top250S = "Top250.txt on local network share or folder"
            if Top250Source == "2":
                Top250S = "Top250 download from http://top250.info/charts/"
        with open(log_path, "a", encoding="utf-8") as f:
            if xbmcvfs.exists(log_path):
                f.write("\n")
            f.write("--------------------------------------------------------------------------------\n")
            f.write("Starting %s (%s)\n" % (addonName, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            f.write("Add-on version: %s | Kodi version: %s\n" % (addonVersion, get_kodi_version()))
            f.write("onMovies: %s | onTVShows: %s | Monthly Full Refresh: %s\n" % (onMovies, onTVShows, MonthlyFullRefresh))
            f.write("Schedule Enabled: %s | Update Ratings At Start: %s\n" % (ScheduleEnabled, UpdateRatingsAtStart))
            f.write("Source of update: %s\n" % UpdateSource)
            if Top250Support == "true":
                f.write("Source of Top250: %s\n" % Top250S)
            f.write("Trigger: %s\n" % trigger)
            f.write("--------------------------------------------------------------------------------\n")
        LOG_INITIALIZED_DATE = True
        cleanup_old_logs()
    except Exception as e:
        xbmc.log("[IMDbRatings][Log] ensure_log_initialized failed: %s" % str(e), xbmc.LOGERROR)


def get_kodi_version():
    query = {
        "jsonrpc": "2.0",
        "method": "Application.GetProperties",
        "params": {
            "properties": ["version", "name"]
        },
        "id": 1
    }
    json_query = xbmc.executeJSONRPC(jSon.dumps(query))
    if sys.version_info[0] >= 3:
        json_query = str(json_query)
    else:
        json_query = unicode(json_query, 'utf-8', errors='ignore')
    json_query = jSon.loads(json_query)
    version_installed = []
    if 'result' in json_query and 'version' in json_query['result']:
        version_installed = json_query['result']['version']
        return str(version_installed['major']) + "." + str(version_installed['minor'])
    else:
        return ""


def load_top250():
    top250 = {}
    try:
        path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/db/Top250.txt"
        if not xbmcvfs.exists(path):
            return top250
        f = xbmcvfs.File(path)
        content = f.read()
        f.close()
        for line in content.splitlines():
            line = line.strip()
            if not line or "|" not in line:
                continue
            rank, imdb = line.split("|", 1)
            try:
                top250[imdb.strip()] = int(rank.strip())
            except:
                pass
    except Exception as e:
        xbmc.log("[IMDbRatings][Top250] Failed loading Top250.txt: %s" % str(e), xbmc.LOGERROR)
    return top250


def get_top250_rank(imdb_id):
    if not imdb_id:
        return 0
    top250 = load_top250()
    return top250.get(imdb_id, 0)


def get_progress_title(source_override=None):
    if source_override == "api":
        source = "api"
    elif source_override == "dataset":
        source = "dataset"
    elif source_override == "html":
        source = "IMDb HTML"
    else:
        if addonSettings.getSetting("LocalIMDbSQL") == "true":
            source = "dataset"
        elif IMDbSource == 1:
            source = "IMDb HTML"
        else:
            source = "api"
        if addonSettings.getSetting("FullRefreshMode") == "true":
            return "%s - Monthly Full Refresh (source: %s)..." % (addonLanguage(32260).replace("...", ""), source)
    return "%s (source: %s)" % (addonLanguage(32260), source)