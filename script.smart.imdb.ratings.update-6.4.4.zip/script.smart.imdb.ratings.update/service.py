# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################


import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import json as jSon
import time, _strptime
from datetime import date, datetime, timedelta
from support.common import *
from main import StartUpdate
from core.update_main import Movies
from core.tvdb_api import UpdateMissingBanner
from core.imdb_dataset import *

if not xbmcvfs.exists(addonProfile): xbmcvfs.mkdir(addonProfile)

WeekDay = addonSettings.getSetting("WeekDay")
DayTime = addonSettings.getSetting("DayTime")
LAST_SCHEDULE_RUN = 0
LAST_SCAN_EVENT = 0

# NEW: dataset monitor state
DATASET_MONITOR_ACTIVE = False
DATASET_MONITOR_START = 0
DATASET_FIRST_CHECK = True
PRE_SCAN_MOVIE_IDS = set()
PRE_SCAN_TVSHOW_IDS = set()
PRE_SCAN_EPISODE_IDS = set()


def ensure_activity_log():
    try:
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_activity.log"
        log_dir = os.path.dirname(log_path)
        if not xbmcvfs.exists(log_dir):
            xbmcvfs.mkdirs(log_dir)
        if not xbmcvfs.exists(log_path):
            with open(log_path, "w", encoding="utf-8"):
                pass
    except Exception as e:
        xbmc.log("[IMDbRatings][ActivityLog] Failed: %s" % str(e), xbmc.LOGERROR)

def UpdateSchedule():
    enabled_days = getEnabledWeekdays()
    run_time = addonSettings.getSetting("DayTime")
    today = datetime.now()
    today_weekday = today.weekday()
    next_run = None
    for offset in range(0, 8):
        day_index = (today_weekday + offset) % 7
        if not enabled_days[day_index]:
            continue
        candidate_date = today.date() + timedelta(days=offset)
        if offset == 0 and time.strftime("%H:%M:%S") >= run_time:
            continue
        next_run = candidate_date
        break
    if next_run:
        addonSettings.setSetting("ScheduledRunDate", next_run.strftime("%Y-%m-%d"))
        statusLog(addonLanguage(32655) % (next_run.strftime("%Y-%m-%d"), run_time))
    xbmc.sleep(2000)
    logInfo("Monitor","Scheduler active days: %s @ %s" % (", ".join(d for d, v in zip(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], getEnabledWeekdays()) if v), addonSettings.getSetting("DayTime")))

def TakeLibrarySnapshot():
    global PRE_SCAN_MOVIE_IDS
    global PRE_SCAN_TVSHOW_IDS
    PRE_SCAN_MOVIE_IDS = set()
    PRE_SCAN_TVSHOW_IDS = set()
    try:
        # MOVIES
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        movies = response.get("result", {}).get("movies", [])
        for movie in movies:
            movieid = movie.get("movieid")
            PRE_SCAN_MOVIE_IDS.add(movieid)
        # TV SHOWS
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows",'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        tvshows = response.get("result", {}).get("tvshows", [])
        for show in tvshows:
            tvshowid = show.get("tvshowid")
            PRE_SCAN_TVSHOW_IDS.add(tvshowid)
        # EPISODES
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        episodes = response.get("result", {}).get("episodes", [])
        for episode in episodes:
            episodeid = episode.get("episodeid")
            PRE_SCAN_EPISODE_IDS.add(episodeid)
        logInfo("Monitor","Library snapshot saved (%d movies, %d TV shows, %d episodes)" % (len(PRE_SCAN_MOVIE_IDS), len(PRE_SCAN_TVSHOW_IDS), len(PRE_SCAN_EPISODE_IDS)))
    except Exception as e:
        logError("Monitor","Snapshot failed: %s" % str(e))

def UpdateNewLibraryItems():
    global PRE_SCAN_MOVIE_IDS
    global PRE_SCAN_TVSHOW_IDS
    global PRE_SCAN_EPISODE_IDS
    now = time.time()
    if hasattr(UpdateNewLibraryItems, "_last_run"):
        if now - UpdateNewLibraryItems._last_run < 30:
            logInfo("Monitor","Ignoring duplicate library scan event")
            return
    if not ensure_dataset_available():
        logError("UPDATE", "Dataset source selected but dataset unavailable")
        return
    UpdateNewLibraryItems._last_run = now
    logInfo("Monitor","Library scan finished – checking for newly added items")
    while xbmc.getCondVisibility("Library.IsScanningVideo"):
        xbmc.sleep(1000)
    xbmc.sleep(2000)
    try:
        # =========================================================
        # GET CURRENT MOVIES
        # =========================================================
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"params":{"properties":["title","uniqueid"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        current_movies = response.get("result", {}).get("movies", [])
        # =========================================================
        # GET CURRENT TV SHOWS
        # =========================================================
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows",'
            '"params":{"properties":["title","uniqueid"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        current_tvshows = response.get("result", {}).get("tvshows", [])
        # =========================================================
        # GET CURRENT EPISODES
        # =========================================================
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
            '"params":{"properties":["showtitle","season","episode","tvshowid","uniqueid"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        current_episodes = response.get("result", {}).get("episodes", [])
        # =========================================================
        # DETECT NEW MOVIES
        # =========================================================
        movies_to_update = []
        current_movie_ids = set()
        for movie in current_movies:
            movieid = movie.get("movieid")
            current_movie_ids.add(movieid)
            if movieid not in PRE_SCAN_MOVIE_IDS:
                movies_to_update.append(movie)
                logInfo("Monitor","Detected new movie: %s" % movie.get("title"))
        # =========================================================
        # DETECT NEW TV SHOWS
        # =========================================================
        tvshows_to_update = {}
        current_tvshow_ids = set()
        for show in current_tvshows:
            tvshowid = show.get("tvshowid")
            current_tvshow_ids.add(tvshowid)
            if tvshowid not in PRE_SCAN_TVSHOW_IDS:
                tvshows_to_update[tvshowid] = {"show": show, "episodes": []}
                logInfo("Monitor","Detected new TV show: %s" % show.get("title"))
        # =========================================================
        # DETECT NEW EPISODES
        # =========================================================
        current_episode_ids = set()
        for episode in current_episodes:
            episodeid = episode.get("episodeid")
            current_episode_ids.add(episodeid)
            if episodeid not in PRE_SCAN_EPISODE_IDS:
                tvshowid = episode.get("tvshowid")
                # -------------------------------------------------
                # EXISTING SHOW WITH NEW EPISODES
                # -------------------------------------------------
                if tvshowid not in tvshows_to_update:
                    # fetch TV show details once
                    query = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                        '"params":{'
                        '"tvshowid":%d,'
                        '"properties":["title","uniqueid"]'
                        '},'
                        '"id":1}'
                    ) % tvshowid
                    response = xbmc.executeJSONRPC(query)
                    response = jSon.loads(response)
                    show = response.get("result",{}).get("tvshowdetails",{})
                    tvshows_to_update[tvshowid] = {"show": show, "episodes": []}
                    logInfo("Monitor","Detected new episodes for existing TV show: %s" % show.get("title"))
                tvshows_to_update[tvshowid]["episodes"].append(episode)
        # =========================================================
        # SAVE CURRENT SNAPSHOTS
        # =========================================================
        PRE_SCAN_MOVIE_IDS = current_movie_ids
        PRE_SCAN_TVSHOW_IDS = current_tvshow_ids
        PRE_SCAN_EPISODE_IDS = current_episode_ids
        # =========================================================
        # NOTHING NEW
        # =========================================================
        if not movies_to_update and not tvshows_to_update:
            logInfo("Monitor","No new items added today")
            return
        logInfo("Monitor","Found %d new movies and %d TV shows requiring updates" % (len(movies_to_update), len(tvshows_to_update)))
        from core.update_main import thread_parse_IMDb_page
        from _thread import allocate_lock
        lock = allocate_lock()
        flock = allocate_lock()
        progress = xbmcgui.DialogProgressBG()
        progress.create("IMDb Ratings", "Updating newly added items")
        # =========================================================
        # COUNT TOTAL ITEMS
        # =========================================================
        total = len(movies_to_update)
        for tvshowid in tvshows_to_update:
            total += 1
            total += len(
                tvshows_to_update[tvshowid]["episodes"]
            )
        count = 0
        # =========================================================
        # LOGGING
        # =========================================================
        statusLog("Auto-update ratings for newly added items started")
        # =========================================================
        # UPDATE MOVIES
        # =========================================================
        for movie in movies_to_update:
            count += 1
            percentage = int((count / float(total)) * 100)
            movieid = movie.get("movieid")
            title = movie.get("title")
            unique = movie.get("uniqueid", {})
            IMDb = unique.get("imdb")
            TVDB = unique.get("tvdb")
            TMDB = unique.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(
                IMDb,
                TVDB,
                TMDB
            )
            progress.update(percentage, title)
            thread_parse_IMDb_page(
                "movie",
                movieid,
                IMDb,
                TVDB,
                TMDB,
                title,
                -1,
                None,
                progress,
                percentage,
                lock,
                flock
            )
        # =========================================================
        # UPDATE TV SHOWS + EPISODES
        # =========================================================
        for tvshowid in tvshows_to_update:
            entry = tvshows_to_update[tvshowid]
            show = entry["show"]
            episodes = entry["episodes"]
            title = show.get("title")
            unique = show.get("uniqueid", {})
            IMDb = unique.get("imdb")
            TVDB = unique.get("tvdb")
            TMDB = unique.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(
                IMDb,
                TVDB,
                TMDB
            )
            # -----------------------------------------------------
            # UPDATE TV SHOW
            # -----------------------------------------------------
            count += 1
            percentage = int((count / float(total)) * 100)
            progress.update(percentage, title)
            thread_parse_IMDb_page(
                "tvshow",
                tvshowid,
                IMDb,
                TVDB,
                TMDB,
                title,
                -1,
                tvshowid,
                progress,
                percentage,
                lock,
                flock
            )
            if addonSettings.getSetting("FetchBanner") == "true":
                UpdateMissingBanner(tvshowid, TVDB, title)
            # -----------------------------------------------------
            # UPDATE EPISODES
            # -----------------------------------------------------
            for item in episodes:
                count += 1
                percentage = int((count / float(total)) * 100)
                episodeid = item.get("episodeid")
                season = item.get("season")
                episode = "%02d" % item.get("episode")
                episode_title = (
                    item.get("showtitle")
                    + " "
                    + str(season)
                    + "x"
                    + episode
                )
                unique = item.get("uniqueid", {})
                IMDb = unique.get("imdb")
                TVDB = unique.get("tvdb")
                TMDB = unique.get("tmdb")
                IMDb, TVDB, TMDB = normalize_IDs(
                    IMDb,
                    TVDB,
                    TMDB
                )
                progress.update(percentage, episode_title)
                thread_parse_IMDb_page(
                    "episode",
                    episodeid,
                    IMDb,
                    TVDB,
                    TMDB,
                    episode_title,
                    season,
                    tvshowid,
                    progress,
                    percentage,
                    lock,
                    flock
                )
        progress.close()
        logInfo("Monitor","Finished updating ratings for newly added items")
    except Exception as e:
        logError("Monitor","Auto-update failed: %s" % str(e))
    finally:
        addonSettings.setSetting("PerformingUpdate", "false")


class LibraryMonitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        global LAST_SCAN_EVENT
        if method == "VideoLibrary.OnScanStarted":
            logInfo("Monitor","Kodi library scan started")
            TakeLibrarySnapshot()
        if method == "VideoLibrary.OnScanFinished":
            now = time.time()
            if now - LAST_SCAN_EVENT < 60:
                logInfo("Monitor","Duplicate scan finished event ignored")
                return
            LAST_SCAN_EVENT = now
            logInfo("Monitor","Kodi library scan finished")
            if addonSettings.getSetting("PerformingUpdate") == "true":
                logInfo("Monitor","Update already running – skipping auto-update")
                return
            addonSettings.setSetting("PerformingUpdate", "true")
            xbmc.sleep(8000)
            UpdateNewLibraryItems()


def AutoStart():

    global LAST_SCHEDULE_RUN
    global DATASET_MONITOR_ACTIVE
    global DATASET_MONITOR_START
    global DATASET_FIRST_CHECK

    doNotify("Service started...", 6000)
    if addonSettings.getSetting("PerformingUpdate") == "true":
        logInfo("Monitor","Detected unfinished update from previous session – resetting state")
    addonSettings.setSetting("PerformingUpdate", "false")
    addonSettings.setSetting("LogDialog", "false")

    WhereLogs = int(addonSettings.getSetting("WhereLogs") or 0)
    if WhereLogs == 0:
        ensure_activity_log()
        cleanup_activity_log()
        activityLog("[IMDbRatings][ActivityLog] Service startup")
    else:
        xbmc.log("[IMDbRatings][ActivityLog] Service startup", xbmc.LOGINFO)
    ensure_log_initialized("Service startup")

    addonSettings.setSetting("FullRefreshMode", "false")
    if addonSettings.getSetting("MonthlyFullRefresh") == "true":
        try:
            last_refresh = addonSettings.getSetting("LastFullRefreshDate")
            if last_refresh:
                days_since = (datetime.now() - datetime.strptime(last_refresh, "%Y-%m-%d")).days
                if days_since >= 30:
                    addonSettings.setSetting("FullRefreshMode", "true")
                    logInfo("Monitor","Monthly Full Refresh activated (last refresh %d days ago)" % days_since)
            else:
                addonSettings.setSetting("FullRefreshMode", "true")
                logInfo("Monitor","Monthly Full Refresh activated (no previous refresh date found)")
        except Exception as e:
            logError("Monitor","Failed to evaluate Monthly Full Refresh: %s" % str(e))
    # =========================
    # STARTUP UPDATE
    # =========================
    if addonSettings.getSetting("UpdateRatingsAtStart") == "true":
        logInfo("Monitor","Startup ratings update check")
        last_update = addonSettings.getSetting("LastRatingsUpdateDate")
        today = datetime.now().strftime("%Y-%m-%d")
        # ---------------------------------
        # DATASET SOURCE
        # ---------------------------------
        if addonSettings.getSetting("LocalIMDbSQL") == "true":
            imdb_db_path = addonProfile + "/db/imdb_ratings.db"
            # DB missing
            if not xbmcvfs.exists(imdb_db_path):
                logInfo("Monitor","Local dataset DB missing -> downloading dataset and starting ratings update")
                try:
                    status = check_dataset_update()
                    if status in ("updated", "up_to_date"):
                        StartUpdate()
                except Exception as e:
                    logError("Monitor","Startup dataset download failed: %s" % str(e))
            # DB exists
            else:
                try:
                    up_to_date, msg = is_dataset_up_to_date()
                    # DB outdated
                    if not up_to_date:
                        logInfo("Monitor","Newer dataset available -> downloading dataset and starting ratings update")
                        status = check_dataset_update()
                        if status in ("updated", "up_to_date"):
                            StartUpdate()
                    # DB current
                    else:
                        logInfo("Monitor","Local dataset already up to date -> startup update skipped")
                        doNotify("Ratings update not needed. Today's dataset was already processed earlier", 20000)
                except Exception as e:
                    logError("Monitor","Startup dataset check failed: %s" % str(e))
        # ---------------------------------
        # API / HTML SOURCE
        # ---------------------------------
        else:
            if last_update != today:
                logInfo("Monitor","No ratings update performed today -> starting startup ratings update")
                StartUpdate()
            else:
                logInfo("Monitor","Ratings already updated today -> startup update skipped")
                doNotify("Ratings update not needed. Ratings were already updated today", 15000)
    # =========================
    # SCHEDULER MONITORING
    # =========================
    monitor = LibraryMonitor()
    last_daytime = addonSettings.getSetting("DayTime")
    if addonSettings.getSetting("ScheduleEnabled") == "true":
        UpdateSchedule()
    while not monitor.abortRequested():
        now = datetime.now()
        sleep_seconds = 60 - now.second
        monitor.waitForAbort(sleep_seconds)
        if monitor.abortRequested():
            break
        if addonSettings.getSetting("PerformingUpdate") == "true":
            continue
        if addonSettings.getSetting("ScheduleEnabled") != "true":
            continue
        current_daytime = addonSettings.getSetting("DayTime")
        if current_daytime != last_daytime:
            logInfo("Monitor","Schedule time changed – recalculating scheduler")
            UpdateSchedule()
            last_daytime = current_daytime
        if addonSettings.getSetting("ScheduledRunDate") == "2000-01-01":
            UpdateSchedule()
        try:
            scheduled_day = datetime.strptime(addonSettings.getSetting("ScheduledRunDate"), "%Y-%m-%d")
        except TypeError:
            scheduled_day = datetime(*(time.strptime(addonSettings.getSetting("ScheduledRunDate"), "%Y-%m-%d")[0:6]))
        # =========================
        # START MONITOR WINDOW
        # =========================
        if datetime.now() >= scheduled_day:
            if time.strftime("%H:%M:%S") >= addonSettings.getSetting("DayTime"):
                now_ts = time.time()
                if now_ts - LAST_SCHEDULE_RUN >= 60:
                    LAST_SCHEDULE_RUN = now_ts
                    # ---------------------------------
                    # DATASET MODE
                    # ---------------------------------
                    if addonSettings.getSetting("LocalIMDbSQL") == "true":
                        logInfo("Monitor","Starting dataset monitoring window")
                        DATASET_MONITOR_ACTIVE = True
                        DATASET_MONITOR_START = now_ts
                        DATASET_FIRST_CHECK = True
                        retry_interval = int(addonSettings.getSetting("RetryInterval") or 15)
                        # force immediate first check
                        AutoStart._last_dataset_check = now_ts - retry_interval * 60
                        AutoStart._half_logged = False
                        AutoStart._retry_wait_active = False
                    # ---------------------------------
                    # API MODE
                    # ---------------------------------
                    else:
                        ensure_log_initialized("Scheduled update start")
                        logInfo("Monitor","Scheduled update time reached -> starting ratings update")
                        StartUpdate()
                    UpdateSchedule()
        # =========================
        # DATASET MONITOR LOOP
        # =========================
        if DATASET_MONITOR_ACTIVE:
            retry_interval = int(addonSettings.getSetting("RetryInterval") or 15)
            max_window = int(addonSettings.getSetting("RetryWindow") or 180)
            now_ts = time.time()
            elapsed = (now_ts - DATASET_MONITOR_START) / 60.0
            # ---------------------------------
            # WINDOW EXPIRED
            # ---------------------------------
            if elapsed > max_window:
                logInfo("Monitor","Dataset monitoring window expired")
                DATASET_MONITOR_ACTIVE = False
                if DATASET_FIRST_CHECK:
                    logInfo("Monitor","No new IMDb dataset detected within monitoring window - ratings update skipped")
                    append_dataset_missing_history()
                    statusLog("No new IMDb dataset detected within monitoring window - ratings update skipped (but Top250 update is still performed)")
                    if addonSettings.getSetting("Top250Support") == "true":
                        try:
                            logInfo("Monitor","Running standalone Top250 synchronization")
                            Movies().doUpdateTop250Movies()
                        except Exception as e:
                            logError("Monitor","Standalone Top250 synchronization failed: %s" % str(e))
                    DATASET_FIRST_CHECK = False
                    xbmcgui.Dialog().ok(
                        addonName,
                        "A new IMDb dataset was not detected today "
                        "within the configured monitoring window.\n\n"
                        "This may indicate that IMDb released the dataset "
                        "later than your configured monitoring period.\n\n"
                        "You may consider:\n"
                        "- increasing \"Retry window\"\n"
                        "or\n"
                        "- changing \"Start checking for updates at\"\n\n"
                        "to better match IMDb dataset release times.\n\n"
                        "You may also do nothing, as IMDb occasionally "
                        "skips daily dataset releases.\n"
                        "You may also consider switching to the imdbapi.dev source"
                        "if you prefer ratings updates that do not depend on IMDb dataset publication times"
                    )
            else:
                if not hasattr(AutoStart, "_last_dataset_check"):
                    AutoStart._last_dataset_check = 0
                if not hasattr(AutoStart, "_half_logged"):
                    AutoStart._half_logged = False
                if not hasattr(AutoStart, "_retry_wait_active"):
                    AutoStart._retry_wait_active = False
                time_since_last = now_ts - AutoStart._last_dataset_check
                # ---------------------------------
                # NON-SPAM RETRY LOGGING
                # ---------------------------------
                if AutoStart._retry_wait_active:
                    half_interval = (retry_interval * 60) / 2
                    if not AutoStart._half_logged and time_since_last >= half_interval:
                        remaining_seconds = int((retry_interval * 60) - time_since_last)
                        if remaining_seconds < 0:
                            remaining_seconds = 0
                        minutes = remaining_seconds // 60
                        seconds = remaining_seconds % 60
                        logInfo("Monitor","Next dataset check in about %d minutes, %d seconds" % (minutes, seconds))
                        AutoStart._half_logged = True
                # ---------------------------------
                # EXECUTE CHECK
                # ---------------------------------
                if time_since_last >= retry_interval * 60:
                    AutoStart._last_dataset_check = now_ts
                    AutoStart._half_logged = False
                    logInfo("Monitor","Checking dataset...")
                    try:
                        status = check_dataset_update()
                    except Exception as e:
                        logError("Monitor","Check failed: %s" % str(e))
                        status = None
                    # ---------------------------------
                    # STATE HANDLING
                    # ---------------------------------
                    if status == "updated":
                        logInfo("Monitor","New dataset detected -> starting ratings update")
                        DATASET_MONITOR_ACTIVE = False
                        DATASET_FIRST_CHECK = False
                        AutoStart._retry_wait_active = False
                        ensure_log_initialized("Scheduled update start")
                        StartUpdate()
                    elif status == "up_to_date":
                        if DATASET_FIRST_CHECK:
                            logInfo("Monitor","Dataset already up to date -> running ratings update")
                            DATASET_MONITOR_ACTIVE = False
                            DATASET_FIRST_CHECK = False
                            AutoStart._retry_wait_active = False
                            ensure_log_initialized("Scheduled update start")
                            StartUpdate()
                    elif status == "not_available":
                        logInfo("Monitor","Dataset not yet available -> waiting")
                        AutoStart._retry_wait_active = True


if (__name__ == "__main__"):
    AutoStart()
