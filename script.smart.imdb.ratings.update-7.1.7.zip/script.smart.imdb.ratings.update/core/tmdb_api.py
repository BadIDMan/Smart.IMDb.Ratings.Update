# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import re
import json as jSon
import socket
from urllib.parse import quote
from support.common import *
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

user_agent = "Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (Kresp, like Gecko) Chrome/28.0.1468.0 Safari/537.36"
base_url = "https://api.themoviedb.org/3/"
API_KEY = "5a1a77e2eba8984804586122754f969f"


def _normalize_title(t):
    if not t:
        return ""
    t = t.lower()
    t = re.sub(r'[^a-z0-9]', '', t)
    return t

def _normalize_name(n):
    if not n:
        return ""
    n = n.lower()
    n = re.sub(r'[^a-z0-9]', '', n)
    return n

def get_TVDB_episode_ID_from_TMDB(tvshow_tmdb, season, episode):
    try:
        request = ("tv/%s/season/%s/episode/%s/external_ids?api_key=%s" % (tvshow_tmdb, season, episode, API_KEY))
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        data = jSon.loads(response)
        tvdb_id = data.get("tvdb_id")
        if tvdb_id:
            return str(tvdb_id)
    except Exception as e:
        logError("TMDBAPI", "Episode TVDB recovery failed: %s" % str(e))
    return None

def get_TVDB_tvshow_ID_from_TMDB(tvshow_tmdb):
    try:
        request = ("tv/%s/external_ids?api_key=%s" % (tvshow_tmdb, API_KEY))
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        tvdb_id = data.get("tvdb_id")
        if tvdb_id:
            return str(tvdb_id)
    except Exception as e:
        logError("TMDBAPI", "TV Show TVDB recovery failed: %s" % str(e))
    return None

def send_API_request(request):
    req = Request(request)
    req.add_header('User-Agent', user_agent)
    socket.setdefaulttimeout(30)
    resp = ""
    try:
        response = urlopen(req)
        resp = response.read().decode("utf-8")
        response.close()
        return (resp, "OK", "OK")
    except HTTPError as err:
        error = str(err.code) + " " + err.reason
        statusInfo = "TMDB API request error (" + error + ")"
        return (resp, "HTTP", statusInfo)
    except socket.error as err:
        statusInfo = "TMDB API request error (" + str(err) + ")"
        return (resp, "socket", statusInfo)
    except URLError as err:
        error = err.reason if not isinstance(err, str) else err
        statusInfo = "TMDB API request error (" + str(error) + ")"
        return (resp, "socket", statusInfo)

def get_IMDb_ID_from_TMDb(updateitem, tmdb_id, season=0, episode=0, debug_log=None):
    if debug_log is None:
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
    if not tmdb_id:
        return (None, "Method get_IMDb_ID_from_TMDb - Missing TMDB ID")
    if updateitem == "movie":
        request = "movie/%s/external_ids?api_key=%s" % (tmdb_id, API_KEY)
    elif updateitem == "tvshow":
        request = "tv/%s/external_ids?api_key=%s" % (tmdb_id, API_KEY)
    elif updateitem == "episode":
        request = "tv/%s/season/%s/episode/%s/external_ids?api_key=%s" % (tmdb_id, season, episode, API_KEY)
    else:
        return (None, "Unsupported media type")
    if debug_log:
        logDebug("TMDB", "Request=%s" % (base_url + request))
    (response, status, statusInfo) = send_API_request(base_url + request)
    if debug_log:
        logDebug("TMDB", "Status=%s statusInfo=%s" % (status, statusInfo))
        logDebug("TMDB", "Response=%s" % response)
    if statusInfo != "OK":
        return (None, statusInfo)
    try:
        data = jSon.loads(response)
        if debug_log:
            logDebug("TMDB", "Parsed=%s" % data)
        imdb_id = data.get("imdb_id")
    except Exception as e:
        logError("TMDB", "Json exception=%s" % str(e))
        imdb_id = None
    if debug_log:
        logDebug("TMDB", "imdb_id=%s" % imdb_id)
    if not imdb_id:
        return (None, "Method get_IMDb_ID_from_TMDb - Missing IMDb ID")
    return (imdb_id, "OK")

def get_TMDB_rating(updateitem, tmdb_id, season=0, episode=0):
    if not tmdb_id:
        return (None, None, "Missing TMDB ID")
    if updateitem == "movie":
        request = "movie/%s?api_key=%s" % (tmdb_id, API_KEY)
    elif updateitem == "tvshow":
        request = "tv/%s?api_key=%s" % (tmdb_id, API_KEY)
    elif updateitem == "episode":
        request = "tv/%s/season/%s/episode/%s?api_key=%s" % (tmdb_id, season, episode, API_KEY)
    else:
        return (None, None, "Unsupported media type")
    (response, status, statusInfo) = send_API_request(base_url + request)
    if statusInfo != "OK":
        return (None, None, statusInfo)
    try:
        data = jSon.loads(response)
        rating = data.get("vote_average")
        votes = data.get("vote_count")
    except Exception as e:
        logError("TMDB", "JSON parse error: %s" % str(e))
        return (None, None, "TMDB JSON parse error: %s" % str(e))
    if rating is None:
        return (None, None, "TMDB rating missing")
    return (rating, votes, "TMDB rating used")

def get_TMDB_episode_ID_from_IMDb(imdb_id):
    try:
        request = "find/%s?external_source=imdb_id&api_key=%s" % (imdb_id, API_KEY)
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        results = data.get("tv_episode_results", [])
        if results:
            return str(results[0].get("id"))
    except Exception as e:
        logError("TMDBAPI", "TMDB episode recovery failed: %s" % str(e))
    return None

def get_TMDB_movie_ID_from_IMDb(imdb_id):
    try:
        request = "find/%s?external_source=imdb_id&api_key=%s" % (imdb_id, API_KEY)
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        results = data.get("movie_results", [])
        if results:
            return str(results[0].get("id"))
    except Exception as e:
        logError("TMDBAPI", "TMDB movie recovery failed: %s" % str(e))
    return None

def get_TMDB_tvshow_ID_from_IMDb(imdb_id):
    try:
        request = "find/%s?external_source=imdb_id&api_key=%s" % (imdb_id, API_KEY)
        (response, status, statusInfo) = send_API_request(base_url + request)
        if status != "OK":
            return None
        data = jSon.loads(response)
        results = data.get("tv_results", [])
        if results:
            return str(results[0].get("id"))
    except Exception as e:
        logError("TMDBAPI", "TMDB TV show recovery failed: %s" % str(e))
    return None

def get_TMDB_ID_from_TVDB(tvdb_id, media_type):
    if not tvdb_id:
        return (None, "Missing TVDB ID")
    request = "find/%s?api_key=%s&external_source=tvdb_id" % (tvdb_id, API_KEY)
    (response, status, statusInfo) = send_API_request(base_url + request)
    if statusInfo != "OK":
        return (None, statusInfo)
    try:
        data = jSon.loads(response)
        if media_type == "movie" and data.get("movie_results"):
            return (data["movie_results"][0]["id"], "OK")
        if media_type in ("tvshow", "episode") and data.get("tv_results"):
            return (data["tv_results"][0]["id"], "OK")
    except Exception as e:
        logError("TMDB", "TMDB TVDB mapping parse error: %s" % str(e))
        return (None, "TMDB TVDB mapping parse error: %s" % str(e))
    return (None, "No TMDB match found for TVDB ID")

# --------------------------------------------------------------
# STRICT TITLE + YEAR + DIRECTOR SEARCH
# --------------------------------------------------------------
def search_TMDB_by_title(updateitem, title, year=None, movieid=None, debug_log=None):
    if debug_log is None:
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
    if debug_log:
        logDebug("TMDB", "search_TMDB_by_title() title='%s' year=%s movieid=%s" % (title, year, movieid))
    if updateitem != "movie" or not title or not year:
        if debug_log:
            logDebug("TMDB", "Skipped (updateitem=%s title=%s year=%s)" % (updateitem, title, year))
        return (None, None)
    query = quote(title)
    request = "search/movie?api_key=%s&query=%s&year=%s" % (API_KEY, query, year)
    if debug_log:
        logDebug("TMDB", "Request=%s" % (base_url + request))
    (response, status, statusInfo) = send_API_request(base_url + request)
    if debug_log:
        logDebug("TMDB", "Status=%s statusInfo=%s" % (status, statusInfo))
    if statusInfo != "OK":
        return (None, None)
    try:
        data = jSon.loads(response)
        results = data.get("results", [])
        if debug_log:
            logDebug("TMDB", "TMDB returned %d result(s)" % len(results))
    except Exception as e:
        if debug_log:
            logDebug("TMDB", "JSON parsing failed: %s" % str(e))
        return (None, None)
    if not results:
        if debug_log:
            logDebug("TMDB", "No search results")
        return (None, None)
    input_title_norm = _normalize_title(title)
    input_year = str(year)
    if debug_log:
        logDebug("TMDB", "Normalized input title='%s' year=%s" % (input_title_norm, input_year))
    strict_matches = []
    for r in results:
        result_title = r.get("title")
        release_date = r.get("release_date")
        if debug_log:
            logDebug("TMDB", "Candidate title='%s' release_date='%s' id=%s" %
                (result_title, release_date, r.get("id")))
        if not result_title or not release_date:
            if debug_log:
                logDebug("TMDB", "Rejected (missing title or release date)")
            continue
        normalized_title = _normalize_title(result_title)
        if normalized_title != input_title_norm:
            if debug_log:
                logDebug("TMDB", "Rejected (title mismatch '%s' != '%s')" % (normalized_title, input_title_norm))
            continue
        try:
            result_year = int(release_date[:4])
            if abs(result_year - int(input_year)) > 1:
                if debug_log:
                    logDebug("TMDB", "Rejected (year mismatch %d vs %s)" % (result_year, input_year))
                continue
        except Exception as e:
            if debug_log:
                logDebug("TMDB", "Rejected (invalid year): %s" % str(e))
            continue
        strict_matches.append(r)
        if debug_log:
            logDebug("TMDB",
                "Accepted candidate id=%s" % r.get("id"))
    if debug_log:
        logDebug("TMDB", "Strict matches=%d" % len(strict_matches))
    if not strict_matches:
        return (None, None)
    # Exact match
    if len(strict_matches) == 1:
        if debug_log:
            logDebug("TMDB", "Single strict match id=%s" % strict_matches[0].get("id"))
        return (strict_matches[0].get("id"), "Title+Year")
    # Director verification
    if not movieid:
        if debug_log:
            logDebug("TMDB", "Multiple matches but movieid missing")
        return (None, None)
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails",'
            '"params":{"movieid":%d,"properties":["director"]},"id":1}'
        ) % movieid
        jSonResponse = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        moviedetails = jSonResponse.get("result", {}).get("moviedetails", {})
        kodi_directors = moviedetails.get("director", [])
        if debug_log:
            logDebug("TMDB", "Kodi directors=%s" % kodi_directors)
        if not kodi_directors:
            return (None, None)
        kodi_directors_norm = [_normalize_name(d) for d in kodi_directors]
        for match in strict_matches:
            movie_tmdb_id = match.get("id")
            credits_request = "movie/%s/credits?api_key=%s" % (movie_tmdb_id, API_KEY)
            if debug_log:
                logDebug("TMDB", "Checking directors for TMDB ID=%s" % movie_tmdb_id)
            (resp, st, stInfo) = send_API_request(base_url + credits_request)
            if stInfo != "OK":
                continue
            credits = jSon.loads(resp)
            crew = credits.get("crew", [])
            for person in crew:
                if person.get("job") != "Director":
                    continue
                tmdb_director = _normalize_name(person.get("name"))
                if debug_log:
                    logDebug("TMDB", "TMDB director='%s'" % tmdb_director)
                if tmdb_director in kodi_directors_norm:
                    if debug_log:
                        logDebug("TMDB", "Director match -> TMDB ID=%s" % movie_tmdb_id)
                    return (movie_tmdb_id, "Title+Year+Director")
    except Exception as e:
        if debug_log:
            logDebug("TMDB", "Director verification failed: %s" % str(e))
        return (None, None)
    if debug_log:
        logDebug("TMDB", "No matching director found")
    return (None, None)

def get_TMDB_tvshow_status(tmdb_id):
    if not tmdb_id:
        return (None, "Missing TMDB ID")
    request = "tv/%s?api_key=%s" % (tmdb_id, API_KEY)
    (response, status, statusInfo) = send_API_request(base_url + request)
    if statusInfo != "OK":
        return (None, statusInfo)
    try:
        data = jSon.loads(response)
        tvshow_status = data.get("status")
    except Exception as e:
        logError("TMDB", "JSON parse error: %s" % str(e))
        return (None, "TMDB JSON parse error: %s" % str(e))
    if not tvshow_status:
        return (None, "TMDB TV show status missing")
    return (tvshow_status, "TMDB TV show status used")