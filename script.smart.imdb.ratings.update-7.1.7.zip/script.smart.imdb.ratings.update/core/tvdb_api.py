# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc, xbmcaddon, xbmcgui, xbmcaddon
import json as jSon
import requests
import uuid
from support.common import *

addonSettings = xbmcaddon.Addon()

TVDB_APIKEY = "edae60dc-1b44-4bac-8db7-65c0aaf5258b"
TVDB_LOGIN_URL = "https://api4.thetvdb.com/v4/login"
TVDB_SERIES_URL = "https://api4.thetvdb.com/v4/series/%s/extended"


def TVDBLogin():
    if not xbmcaddon.Addon().getSetting("TVDB_UUID"):
        xbmcaddon.Addon().setSetting("TVDB_UUID", str(uuid.uuid4()))
    payload = {"apikey": TVDB_APIKEY, "gender": "Other", "birthYear": 1900, "uuid": xbmcaddon.Addon().getSetting("TVDB_UUID")}
    headers = {"User-Agent": "TheTVDB v.4 TV Scraper for Kodi", "Accept": "application/json"}
    response = requests.post(TVDB_LOGIN_URL, json=payload, headers=headers, timeout=30)
    response.raise_for_status()
#temporary to get token
#    token = response.json()["data"]["token"]
#    logInfo("TVDBAPI", "JWT=%s" % token)
    return response.json()["data"]["token"]

def GetTVDBSeries(tvdbid):
    token = TVDBLogin()
    headers = {"User-Agent": "TheTVDB v.4 TV Scraper for Kodi", "Accept": "application/json", "Authorization": "Bearer %s" % token}
    response = requests.get(TVDB_SERIES_URL % tvdbid, headers=headers, timeout=30)
    response.raise_for_status()
    return response.json()["data"]

def GetTVDBBanner(tvdbid):
    show = GetTVDBSeries(tvdbid)
    artworks = show.get("artworks", [])
    banners = []
    for art in artworks:
        if art.get("type") == 1:
            banners.append(art)
    if not banners:
        return None
    banners.sort(key=lambda x: x.get("score", 0), reverse=True)
    return banners[0]["image"]

def UpdateMissingBanner(tvshowid, tvdbid, title, log):
    try:
        if not tvdbid:
            logInfo("TVDBAPI","Banner update skipped for '%s' - no TVDB ID" % title)
            return "no_tvdb"
        # GET CURRENT ARTWORK
        query = {
            "jsonrpc": "2.0",
            "method": "VideoLibrary.GetTVShowDetails",
            "params": {
                "tvshowid": tvshowid,
                "properties": ["art"]
            },
            "id": 1
        }
        result = jSon.loads(xbmc.executeJSONRPC(jSon.dumps(query)))
        art = (
            result.get("result", {})
                  .get("tvshowdetails", {})
                  .get("art", {})
        )
        if art.get("banner"):
            if log:
                logInfo("TVDBAPI","Banner already exists for '%s'" % title)
            return "exists"
        # FETCH BANNER FROM TVDB
        banner_url = GetTVDBBanner(tvdbid)
        if not banner_url:
            logInfo("TVDBAPI","No TVDB banner found for '%s'" % title)
            return "not_found"
        logInfo("TVDBAPI","Adding TVDB banner for '%s': %s" % (title, banner_url))
        # UPDATE KODI LIBRARY
        query = {
            "jsonrpc": "2.0",
            "method": "VideoLibrary.SetTVShowDetails",
            "params": {
                "tvshowid": tvshowid,
                "art": {
                    "banner": banner_url
                }
            },
            "id": 1
        }
        xbmc.executeJSONRPC(jSon.dumps(query))
        return "downloaded"
    except Exception as e:
        logError("TVDBAPI", "Banner update failed for '%s': %s" % (title, str(e)))
        return "error"

def GetTVDBEpisode(tvdbid):
    token = TVDBLogin()
    headers = {"User-Agent": "TheTVDB v.4 TV Scraper for Kodi", "Accept": "application/json", "Authorization": "Bearer %s" % token}
    response = requests.get("https://api4.thetvdb.com/v4/episodes/%s/extended" % tvdbid, headers=headers, timeout=30)
    response.raise_for_status()
    return response.json()["data"]

def GetTVDBEpisodeIMDbID(tvdbid):
    try:
        episode = GetTVDBEpisode(tvdbid)
        for remote_id in episode.get("remoteIds", []):
            source_name = remote_id.get("sourceName", "")
            if source_name.upper() == "IMDB":
                imdb_id = remote_id.get("id")
                if imdb_id:
                    return imdb_id
        return None
    except Exception as e:
        logError("TVDBAPI","GetTVDBEpisodeIMDbID failed for TVDB %s: %s" % (tvdbid, str(e)))
        return None

def GetTVDBSeriesIMDbID(tvdbid):
    try:
        series = GetTVDBSeries(tvdbid)
        for remote_id in series.get("remoteIds", []):
            source_name = remote_id.get("sourceName", "")
            if source_name.upper() == "IMDB":
                imdb_id = remote_id.get("id")
                if imdb_id:
                    return imdb_id
        return None
    except Exception as e:
        logError("TVDBAPI","GetTVDBSeriesIMDbID failed for TVDB %s: %s" % (tvdbid, str(e)))
        return None

def GetTVDBEpisodeID(tvshow_tvdbid, season, episode):
    try:
        token = TVDBLogin()
        headers = {"User-Agent": "TheTVDB v.4 TV Scraper for Kodi", "Accept": "application/json", "Authorization": "Bearer %s" % token}
        page = 0
        while True:
            response = requests.get("https://api4.thetvdb.com/v4/series/%s/episodes/official?page=%d" % (tvshow_tvdbid, page), headers=headers, timeout=30)
            response.raise_for_status()
            data = response.json()["data"]
            episodes = data.get("episodes", [])
            for ep in episodes:
                if (ep.get("seasonNumber") == season and ep.get("number") == episode):
                    return str(ep.get("id"))
            links = response.json().get("links", {})
            if not links.get("next"):
                break
            page += 1
        return None
    except Exception as e:
        logError("TVDBAPI", "GetTVDBEpisodeID failed for TVDB series %s S%02dE%02d: %s" % (tvshow_tvdbid, season, episode, str(e)))
        return None