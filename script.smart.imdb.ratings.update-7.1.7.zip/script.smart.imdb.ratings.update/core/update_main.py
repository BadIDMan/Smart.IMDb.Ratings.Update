# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc, xbmcgui, xbmcaddon
import json as jSon
from datetime import datetime, timedelta
from support.common import *
from _thread import start_new_thread, allocate_lock
from support.httptools import wait_for_internet
from core.imdb_scraper import parse_IMDb_page, parse_IMDbAPI_page
from core.tmdb_api import get_TMDB_rating
from core.tmdb_api import get_TMDB_ID_from_TVDB
from core.tmdb_api import get_IMDb_ID_from_TMDb
from core.tmdb_api import search_TMDB_by_title
from core.tmdb_api import get_TVDB_episode_ID_from_TMDB
from core.tmdb_api import get_TMDB_episode_ID_from_IMDb
from core.tmdb_api import get_TMDB_movie_ID_from_IMDb
from core.tmdb_api import get_TMDB_tvshow_ID_from_IMDb
from core.tmdb_api import get_TVDB_tvshow_ID_from_TMDB
from core.tmdb_api import get_TMDB_tvshow_status
from core.imdb_dataset import get_local_rating
from core.imdb_dataset import ensure_dataset_available
from core.top250 import get_local_top250_path
from core.top250 import update_from_html
from core.tvdb_api import GetTVDBEpisodeIMDbID
from core.tvdb_api import GetTVDBEpisodeID
from core.tvdb_api import GetTVDBSeriesIMDbID

max_threads = [1, 2, 4, 8, 16][int(xbmcaddon.Addon().getSetting("NumberOfThreads"))] - 1
num_threads = 0
RecoveryStats = {
    "S01": 0,
    "S02": 0,
    "S03": 0,
    "S04": 0,
    "S05": 0,
    "S06": 0,
    "S07": 0,
    "S08": 0,
    "S09": 0,
    "S10": 0,
    "S11": 0,
    "S12": 0,
    "S13": 0,
    "I01": 0   # Metadata inconsistencies
}
LibraryHealth = {
    "MissingIDs": [],
    "Inconsistencies": []
}



def getUpdateTime():
    return {
        1: 32,
        2: 93,
        3: 183,
        4: 366
    }.get(int(xbmcaddon.Addon().getSetting("UpdateTime") or 0), 0)

def get_episode_number(episodeid):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0",'
            '"method":"VideoLibrary.GetEpisodeDetails",'
            '"params":{"episodeid":%d,"properties":["episode"]},'
            '"id":1}'
        ) % episodeid
        result = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        return result["result"]["episodedetails"]["episode"]
    except:
        return None

def get_tvshow_tmdb_id(tvshowid):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0",'
            '"method":"VideoLibrary.GetTVShowDetails",'
            '"params":{"tvshowid":%d,"properties":["uniqueid"]},'
            '"id":1}'
        ) % tvshowid
        result = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        unique_id = (result["result"]["tvshowdetails"].get("uniqueid", {}))
        return unique_id.get("tmdb")
    except Exception as e:
        logError("Update", "get_tvshow_tmdb_id failed: %s" % str(e))
        return None

def get_tvshow_tvdb_id(tvshowid):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0",'
            '"method":"VideoLibrary.GetTVShowDetails",'
            '"params":{"tvshowid":%d,"properties":["uniqueid"]},'
            '"id":1}'
        ) % tvshowid
        result = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        unique_id = (result["result"]["tvshowdetails"].get("uniqueid", {}))
        return unique_id.get("tvdb")
    except Exception as e:
        logError("Update", "get_tvshow_tvdb_id failed: %s" % str(e))
        return None

def get_tvshow_title(tvshowid):
    jSonQuery = (
        '{"jsonrpc":"2.0",'
        '"method":"VideoLibrary.GetTVShowDetails",'
        '"params":{"tvshowid":%d,"properties":["title"]},'
        '"id":1}'
    ) % tvshowid
    response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
    try:
        return response["result"]["tvshowdetails"]["title"]
    except:
        return None

def get_tvshow_IMDb_ID(updateitem, tvshowid, TVDB, TMDB, Title):
    IMDb = None
    if updateitem != "tvshow":
        TVDB = None; TMDB = None
        jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"properties":["uniqueid","title"]},"id":1}'
        jSonResponse = xbmc.executeJSONRPC( jSonQuery )
        jSonResponse = jSon.loads( jSonResponse )
        item = jSonResponse['result']['tvshowdetails']
        Title = item.get('title')
        unique_id = item.get('uniqueid')
        if unique_id is not None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
    sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
    statusInfo = "Method get_tvshow_IMDb_ID - " + Title + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: "+ sTMDB + ")"
    if IMDb == None:
        (IMDb, add_statusInfo) = get_IMDb_ID_from_TMDb("tvshow", TMDB, debug_log=debug_log)
        statusInfo = statusInfo + "\n" + add_statusInfo
        if IMDb == None:
            return(None, statusInfo)
        else:
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"uniqueid": {"imdb": "' + IMDb + '"}},"id":1}'
            jSonResponse = xbmc.executeJSONRPC( jSonQuery )
    return (IMDb, "OK")

def UpdateTVShowStatus(tvshowid, status):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0",'
            '"method":"VideoLibrary.SetTVShowDetails",'
            '"params":{"tvshowid":%d,"status":"%s"},'
            '"id":1}'
        ) % (tvshowid, status)
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        if "error" in jSonResponse:
            return (False, jSonResponse["error"].get("message", "Unknown JSON-RPC error"))
        return (True, "Status updated")
    except Exception as e:
        return (False, str(e))

def doUpdateEpisodesBySeason(tvshowid, IMDb, season, progress, percentage, flock, source_override=None):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
            '"params":{"tvshowid":%d,'
            '"season":%d,'
            '"properties":["uniqueid","episode","season","showtitle"],'
            '"sort":{"method":"episode"}},'
            '"id":1}'
        ) % (tvshowid, season)

        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        episodes = jSonResponse.get("result", {}).get("episodes", [])
        total = len(episodes)
        count = 0
        lock = allocate_lock()
        for item in episodes:
            episodeid = item.get("episodeid")
            season_num = item.get("season")
            episode_num = "%02d" % item.get("episode")
            title = (
                item.get("showtitle")
                + " "
                + str(season_num)
                + "x"
                + episode_num
            )
            unique_id = item.get("uniqueid", {})
            IMDb = unique_id.get("imdb")
            TVDB = unique_id.get("tvdb")
            TMDB = unique_id.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(
                IMDb,
                TVDB,
                TMDB
            )
            count += 1
            current_percentage = int(
                (count / float(total)) * 100
            ) if total > 0 else 100
            if ShowProgress:
                progress.update(current_percentage, get_progress_title(source_override), "%s (%d/%d)" % (title, count, total))
            thread_parse_IMDb_page("episode", episodeid, IMDb, TVDB, TMDB, title, season_num, tvshowid, progress, current_percentage, lock, flock, source_override)
    except Exception as e:
        logError("Season", "Season update exception: %s" % str(e))
    return

# =================================================================================
# Recover missing TMDB, TVDB and IMDb IDs using cross-reference APIs
# =================================================================================
def RecoverMissingIDs(updateitem, updateitem_id, tvshowid, season, IMDb, TVDB, TMDB, Title, log_category=None, log_prefix=None, debug_log=None):
    if debug_log is None:
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
    try:
        recovered = {"imdb": None, "tvdb": None, "tmdb": None}
        if log_category is None:
            log_category = "Update"
        if log_prefix is None:
            log_prefix = "[P2]"
        log_item = Title
        if updateitem == "episode":
            episode_num = get_episode_number(updateitem_id)
            tvshow_title = get_tvshow_title(tvshowid)
            tvshow_tvdb = get_tvshow_tvdb_id(tvshowid)
            tvshow_tmdb = get_tvshow_tmdb_id(tvshowid)
            if tvshow_title and episode_num is not None:
                log_item = "%s S%02dE%02d" % (tvshow_title, season, episode_num)
        # ---------------------------------------------
        # Step 1: Recovery episode TMDB ID from IMDb ID
        # ---------------------------------------------
        if updateitem == "episode" and not TMDB and IMDb:
            if debug_log:
                logDebug("Update", "%s [S01] Recovering TMDB episode ID from IMDb=%s" % (log_prefix, IMDb))
            recovered_tmdb = get_TMDB_episode_ID_from_IMDb(IMDb)
            if debug_log:
                logDebug("Update", "%s [S01] TMDB lookup result=%s" % (log_prefix, recovered_tmdb))
            if recovered_tmdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetEpisodeDetails",'
                    '"params":{"episodeid":%d,'
                    '"uniqueid":{"tmdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tmdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                TMDB = recovered_tmdb
                RecoveryStats["S01"] += 1
                recovered["tmdb"] = recovered_tmdb
                logInfo(log_category, "%s[S01] Recovered missing TMDB episode ID %s from IMDb ID %s (%s)" % (log_prefix, recovered_tmdb, IMDb, log_item))
        # ---------------------------------------------
        # Step 2: Recovery episode IMDb ID from TMDB ID
        # ---------------------------------------------
        if updateitem == "episode" and not IMDb and TMDB:
            if debug_log:
                logDebug("Update", "%s [S02] Recovering IMDb episode ID from TMDB ID=%s" % (log_prefix, tvshow_tmdb))
                logDebug("Update", "%s [S02] Recovery lookup: tvshow_tmdb=%s season=%s episode=%s" % (log_prefix, tvshow_tmdb, season, episode_num))
            recovered_imdb, status = get_IMDb_ID_from_TMDb("episode", tvshow_tmdb, season, episode_num, debug_log=debug_log)
            if debug_log:
                logDebug("Update", "%s [S02] IMDb lookup result=%s status=%s" % (log_prefix, recovered_imdb, status))
            if recovered_imdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetEpisodeDetails",'
                    '"params":{"episodeid":%d,'
                    '"uniqueid":{"imdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_imdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                IMDb = recovered_imdb
                RecoveryStats["S02"] += 1
                recovered["imdb"] = recovered_imdb
                logInfo(log_category, "%s[S02] Recovered missing IMDb episode ID %s from TMDB ID %s (%s)" % (log_prefix, recovered_imdb, tvshow_tmdb, log_item))
        # ---------------------------------------------
        # Step 3: Recovery episode TVDB ID from TMDB ID
        # ---------------------------------------------
        if updateitem == "episode" and not TVDB and TMDB:
            if debug_log:
                logDebug("Update", "%s [S03] Recovering TVDB episode from TMDB=%s" % (log_prefix, TMDB))
            if debug_log:
                logDebug("Update", "%s [S03] Recovery lookup results: episode=%s tvshow_tmdb=%s" % (log_prefix, episode_num, tvshow_tmdb))
            recovered_tvdb = get_TVDB_episode_ID_from_TMDB(tvshow_tmdb, season, episode_num)
            if recovered_tvdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetEpisodeDetails",'
                    '"params":{"episodeid":%d,'
                    '"uniqueid":{"tvdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tvdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                TVDB = recovered_tvdb
                RecoveryStats["S03"] += 1
                recovered["tvdb"] = recovered_tvdb
                logInfo(log_category, "%s[S03] Recovered missing TVDB episode ID %s from TMDB ID %s (%s)" % (log_prefix, recovered_tvdb, TMDB, log_item))
        # -----------------------------------------------------
        # Step 4: Recovery episode TVDB ID from TV show TVDB ID
        # -----------------------------------------------------
        if updateitem == "episode" and not TVDB:
            if debug_log:
                logDebug("Update", "%s [S04] Recovering TVDB episode ID from TV show TVDB ID=%s" % (log_prefix, tvshow_tvdb))
                logDebug("Update", "%s [S04] Recovery lookup: tvshow_tvdb=%s season=%s episode=%s" % (log_prefix, tvshow_tvdb, season, episode_num))
            if tvshow_tvdb:
                recovered_tvdb = GetTVDBEpisodeID(tvshow_tvdb, season, episode_num)
            else:
                recovered_tvdb = None
            if recovered_tvdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetEpisodeDetails",'
                    '"params":{"episodeid":%d,'
                    '"uniqueid":{"tvdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tvdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                TVDB = recovered_tvdb
                RecoveryStats["S04"] += 1
                recovered["tvdb"] = recovered_tvdb
                logInfo(log_category, "%s[S04] Recovered missing TVDB episode ID %s from TV show TVDB ID %s (%s)" % (log_prefix, recovered_tvdb, tvshow_tvdb, log_item))
        # ---------------------------------------------
        # Step 5: Recovery episode IMDb ID from TVDB ID
        # ---------------------------------------------
        if updateitem == "episode" and not IMDb and TVDB:
            if debug_log:
                logDebug("Update", "%s [S05] Recovering IMDb episode ID from TVDB=%s" % (log_prefix, TVDB))
            recovered_imdb = GetTVDBEpisodeIMDbID(TVDB)
            if debug_log:
                logDebug("Update", "%s [S05] IMDb lookup result=%s" % (log_prefix, recovered_imdb))
            if recovered_imdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetEpisodeDetails",'
                    '"params":{"episodeid":%d,'
                    '"uniqueid":{"imdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_imdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                IMDb = recovered_imdb
                RecoveryStats["S05"] += 1
                recovered["imdb"] = recovered_imdb
                logInfo(log_category, "%s[S05] Recovered missing IMDb episode ID %s from TVDB ID %s (%s)" % (log_prefix, recovered_imdb, TVDB, log_item))
        # ---------------------------------------------------------
        # Step 6: Episode TMDB completion from newly recovered IMDb
        # ---------------------------------------------------------
        if updateitem == "episode" and not TMDB and IMDb:
            if debug_log:
                logDebug("Update", "%s [S06] Recovering TMDB episode ID from IMDb=%s" % (log_prefix, IMDb))
            recovered_tmdb = get_TMDB_episode_ID_from_IMDb(IMDb)
            if debug_log:
                logDebug("Update", "%s [S06] TMDB lookup result=%s" % (log_prefix, recovered_tmdb))
            if recovered_tmdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetEpisodeDetails",'
                    '"params":{"episodeid":%d,'
                    '"uniqueid":{"tmdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tmdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                TMDB = recovered_tmdb
                RecoveryStats["S06"] += 1
                recovered["tmdb"] = recovered_tmdb
                logInfo(log_category, "%s[S06] Recovered missing TMDB episode ID %s from IMDb ID %s (%s)" % (log_prefix, recovered_tmdb, IMDb, log_item))
        # -------------------------------------------
        # Step 7: Recovery movie TMDB ID from IMDb ID
        # -------------------------------------------
        if updateitem == "movie" and not TMDB and IMDb:
            if debug_log:
                logDebug("Update", "%s [S07] Recovering TMDB movie ID from IMDb=%s" % (log_prefix, IMDb))
            recovered_movie_tmdb = get_TMDB_movie_ID_from_IMDb(IMDb)
            if debug_log:
                logDebug("Update", "%s [S07] TMDB lookup result=%s" % (log_prefix, recovered_movie_tmdb))
            if recovered_movie_tmdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetMovieDetails",'
                    '"params":{"movieid":%d,'
                    '"uniqueid":{"tmdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_movie_tmdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                TMDB = recovered_movie_tmdb
                RecoveryStats["S07"] += 1
                recovered["tmdb"] = recovered_movie_tmdb
                logInfo(log_category, "%s[S07] Recovered missing TMDB movie ID %s from IMDb ID %s (%s)" % (log_prefix, recovered_movie_tmdb, IMDb, Title))
        # -------------------------------------------
        # Step 8: Recovery movie IMDb ID from TMDB ID
        # -------------------------------------------
        if updateitem == "movie" and not IMDb and TMDB:
            if debug_log:
                logDebug("Update", "%s [S08] Recovering IMDb movie ID from TMDB=%s" % (log_prefix, TMDB))
            (recovered_movie_imdb, status) = get_IMDb_ID_from_TMDb("movie", TMDB, debug_log=debug_log)
            if debug_log:
                logDebug("Update", "%s [S08] IMDb lookup result=%s" % (log_prefix, recovered_movie_imdb))
            if recovered_movie_imdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetMovieDetails",'
                    '"params":{"movieid":%d,'
                    '"uniqueid":{"imdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_movie_imdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                IMDb = recovered_movie_imdb
                RecoveryStats["S08"] += 1
                recovered["imdb"] = recovered_movie_imdb
                logInfo(log_category, "%s[S08] Recovered missing IMDb movie ID %s from TMDB ID %s (%s)" % (log_prefix, recovered_movie_imdb, TMDB, Title))
        # ---------------------------------------------
        # Step 9: Recovery TV show TMDB ID from IMDb ID
        # ---------------------------------------------
        if updateitem == "tvshow" and not TMDB and IMDb:
            if debug_log:
                logDebug("Update", "%s [S09] Recovering TMDB TV show ID from IMDb=%s" % (log_prefix, IMDb))
            recovered_tvshow_tmdb = get_TMDB_tvshow_ID_from_IMDb(IMDb)
            if debug_log:
                logDebug("Update", "%s [S09] TMDB lookup result=%s" % (log_prefix, recovered_tvshow_tmdb))
            if recovered_tvshow_tmdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetTVShowDetails",'
                    '"params":{"tvshowid":%d,'
                    '"uniqueid":{"tmdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tvshow_tmdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                TMDB = recovered_tvshow_tmdb
                RecoveryStats["S09"] += 1
                recovered["tmdb"] = recovered_tvshow_tmdb
                logInfo(log_category, "%s[S09] Recovered missing TMDB TV Show ID %s from IMDb ID %s (%s)" % (log_prefix, recovered_tvshow_tmdb, IMDb, Title))
        # ---------------------------------------------
        # Step 10: Recovery TV show IMDb ID from TMDB ID
        # ---------------------------------------------
        if updateitem == "tvshow" and not IMDb and TMDB:
            if debug_log:
                logDebug("Update", "%s [S10] Recovering IMDb TV show ID from TMDB=%s" % (log_prefix, TMDB))
            (recovered_tvshow_imdb, statusInfo) = get_IMDb_ID_from_TMDb("tvshow", TMDB, debug_log=debug_log)
            if debug_log:
                logDebug("Update", "%s [S10] IMDb lookup result=%s" % (log_prefix, recovered_tvshow_imdb))
            if recovered_tvshow_imdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetTVShowDetails",'
                    '"params":{"tvshowid":%d,'
                    '"uniqueid":{"imdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tvshow_imdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                IMDb = recovered_tvshow_imdb
                RecoveryStats["S10"] += 1
                recovered["imdb"] = recovered_tvshow_imdb
                logInfo(log_category, "%s[S10] Recovered missing IMDb TV Show ID %s from TMDB ID %s (%s)" % (log_prefix, recovered_tvshow_imdb, TMDB, Title))
        # ----------------------------------------------
        # Step 11: Recovery TV show TVDB ID from IMDb ID
        # ----------------------------------------------
        if updateitem == "tvshow" and not TVDB and TMDB:
            if debug_log:
                logDebug("Update", "%s [S11] Recovering TVDB TV show ID from TMDB=%s" % (log_prefix, TMDB))
            recovered_tvshow_tvdb = get_TVDB_tvshow_ID_from_TMDB(TMDB)
            if debug_log:
                logDebug("Update", "%s [S11] TVDB lookup result=%s" % (log_prefix, recovered_tvshow_tvdb))
            if recovered_tvshow_tvdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetTVShowDetails",'
                    '"params":{"tvshowid":%d,'
                    '"uniqueid":{"tvdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tvshow_tvdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                TVDB = recovered_tvshow_tvdb
                RecoveryStats["S11"] += 1
                recovered["tvdb"] = recovered_tvshow_tvdb
                logInfo(log_category, "%s[S11] Recovered missing TVDB TV Show ID %s from TMDB ID %s (%s)" % (log_prefix, recovered_tvshow_tvdb, TMDB, Title))
        # ----------------------------------------------
        # Step 12: Recovery TV show IMDb ID from TVDB ID
        # ----------------------------------------------
        if updateitem == "tvshow" and not IMDb and TVDB:
            if debug_log:
                logDebug("Update", "%s [S12] Recovering IMDb TV show ID from TVDB=%s" % (log_prefix, TVDB))
            recovered_tvshow_imdb = GetTVDBSeriesIMDbID(TVDB)
            if debug_log:
                logDebug("Update", "%s [S12] IMDb lookup result=%s" % (log_prefix, recovered_tvshow_imdb))
            if recovered_tvshow_imdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetTVShowDetails",'
                    '"params":{"tvshowid":%d,'
                    '"uniqueid":{"imdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tvshow_imdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                IMDb = recovered_tvshow_imdb
                RecoveryStats["S12"] += 1
                recovered["imdb"] = recovered_tvshow_imdb
                logInfo(log_category, "%s[S12] Recovered missing IMDb TV Show ID %s from TVDB ID %s (%s)" % (log_prefix, recovered_tvshow_imdb, TVDB, Title))
        # ----------------------------------------------------------
        # Step 13: TV show TMDB completion from newly recovered IMDb
        # ----------------------------------------------------------
        if updateitem == "tvshow" and not TMDB and IMDb:
            if debug_log:
                logDebug("Update", "%s [S13] Recovering TMDB TV show ID from IMDb=%s" % (log_prefix, IMDb))
            recovered_tvshow_tmdb = get_TMDB_tvshow_ID_from_IMDb(IMDb)
            if debug_log:
                logDebug("Update", "%s [S13] TMDB lookup result=%s" % (log_prefix, recovered_tvshow_tmdb))
            if recovered_tvshow_tmdb:
                jSonQuery = (
                    '{"jsonrpc":"2.0",'
                    '"method":"VideoLibrary.SetTVShowDetails",'
                    '"params":{"tvshowid":%d,'
                    '"uniqueid":{"tmdb":"%s"}},'
                    '"id":1}'
                ) % (
                    updateitem_id,
                    recovered_tvshow_tmdb
                )
                xbmc.executeJSONRPC(jSonQuery)
                TMDB = recovered_tvshow_tmdb
                RecoveryStats["S13"] += 1
                recovered["tmdb"] = recovered_tvshow_tmdb
                logInfo(log_category, "%s[S13] Recovered missing TMDB TV Show ID %s from IMDb ID %s (%s)" % (log_prefix, recovered_tvshow_tmdb, IMDb, Title))
    except Exception as e:
        logError(log_category, "%s Exception: %s" % (log_prefix, str(e)))
    return IMDb, TVDB, TMDB, recovered

# ----------------------------------------------------------
# IMDb RATING LOOKUP
# Local Dataset -> (optional) IMDb Transport
# ----------------------------------------------------------
def get_IMDb_rating(updateitem, IMDb, debug_log=None):
    updatedRating = None
    updatedVotes = None
    updatedTop250 = 0
    provider = None
    statusInfo = ""
    if debug_log is None:
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
    try:
        # LOCAL IMDb DATASET
        if xbmcaddon.Addon().getSettingBool("LocalIMDbSQL"):
            if debug_log:
                logDebug("Update", "Using local IMDb dataset for IMDb=%s" % IMDb)
            (updatedRating, updatedVotes) = get_local_rating(IMDb)
            if debug_log:
                logDebug("Update", "Dataset result: rating=%s votes=%s" % (updatedRating, updatedVotes))
            if updatedRating is not None:
                provider = "imdb"
                statusInfo = "Rating: %s, Votes: %s (Local IMDb dataset)" % (updatedRating, updatedVotes)
                if updateitem == "movie":
                    updatedTop250 = get_top250_rank(IMDb)
                else:
                    updatedTop250 = 0
                return (updatedRating, updatedVotes, updatedTop250, provider, statusInfo)
            # USER DOES NOT WANT ONLINE FALLBACK
            if not xbmcaddon.Addon().getSettingBool("DatasetFallbackToOnline"):
                statusInfo = "IMDb rating not found in local dataset"
                return (None, None, 0, None, statusInfo)
        # IMDb TRANSPORT
        if debug_log:
            logDebug("Update", "Using IMDb transport for IMDb=%s" % IMDb)
        if int(xbmcaddon.Addon().getSetting("IMDbSource")) == 0:
            (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDbAPI_page(IMDb)
            if updatedRating is None:
                statusInfo = "(failure fetching rating from api.tiffara.com)"
        else:
            (updatedRating, updatedVotes, updatedTop250, statusInfo) = parse_IMDb_page(IMDb)
        if updatedRating is not None:
            provider = "imdb"
            if updateitem == "movie":
                updatedTop250 = get_top250_rank(IMDb)
            else:
                updatedTop250 = 0
    except Exception as e:
        logError("Update", "IMDb rating lookup failed: %s" % str(e))
        statusInfo = "IMDb rating lookup failed: %s" % str(e)
    return (updatedRating, updatedVotes, updatedTop250, provider, statusInfo)



def thread_parse_IMDb_page(updateitem, updateitem_id, IMDb, TVDB, TMDB, title, season, tvshowid, progress, percentage, lock, flock, source_override=None, debug_log=None):
    if debug_log is None:
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
    LocalIMDbSQL = xbmcaddon.Addon().getSettingBool("LocalIMDbSQL")
    IMDbSource = int(xbmcaddon.Addon().getSetting("IMDbSource"))
    if xbmcaddon.Addon().getSettingBool("DebugLog"):
        logDebug("Update", "=== START thread === %s | ID=%s | IMDb=%s | TVDB=%s | TMDB=%s | season=%s | tvshowid=%s" % (updateitem, updateitem_id, IMDb, TVDB, TMDB, season, tvshowid))
    # -------------------------------------------------
    # CONTEXT SOURCE OVERRIDE
    # -------------------------------------------------
    if debug_log:
        logDebug("Update", "Source override BEFORE: LocalIMDbSQL=%s IMDbSource=%s" % (LocalIMDbSQL, IMDbSource))
    if source_override == "api":
        LocalIMDbSQL = False
        IMDbSource = 0
    elif source_override == "dataset":
        LocalIMDbSQL = True
        IMDbSource = 0
    elif source_override == "html":
        LocalIMDbSQL = False
        IMDbSource = 1
    if debug_log:
        logDebug("Update", "Source override AFTER: LocalIMDbSQL=%s IMDbSource=%s" % (LocalIMDbSQL, IMDbSource))
    fallback_chain = []
    global num_threads
    provider = None
    updatedRating = None
    updatedVotes = None
    updatedTop250 = 0
    statusInfo = ""
    if updateitem in ("movie", "tvshow", "episode"):
        if debug_log:
            logDebug("Update", "Enter main processing block")
        # ==================================================
        # PRIORITY 1 - Bootstrap TMDB ID from movie metadata
        # TITLE + YEAR + (Director) -> TMDB (when no IDs)
        # ==================================================
        if updateitem == "movie" and not IMDb and not TMDB and source_override is None:
            if debug_log:
                logDebug("Update", "[P1] ENTER movie derivation from title + year")
                logDebug("Update", "[P1] INPUT title=%s id=%s" % (title, updateitem_id))
            try:
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails",'
                    '"params":{"movieid":%d,"properties":["year"]},"id":1}'
                ) % updateitem_id
                if debug_log:
                    logDebug("Update", "[P1] JSONRPC year query=%s" % jSonQuery)
                jSonResponse = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
                moviedetails = jSonResponse.get("result", {}).get("moviedetails", {})
                movie_year = moviedetails.get("year")
                if debug_log:
                    logDebug("Update", "[P1] Extracted year=%s" % movie_year)
                resolved_tmdb, resolve_method = search_TMDB_by_title("movie", title, movie_year, updateitem_id, debug_log=debug_log)
                if debug_log:
                    logDebug("Update", "[P1] TMDB search result tmdb=%s method=%s" % (resolved_tmdb, resolve_method))
                if resolved_tmdb:
                    TMDB = str(resolved_tmdb)
                    if debug_log:
                        logDebug("Update", "[P1] Writing TMDB=%s to Kodi" % TMDB)
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                        '"params":{"movieid":%d,"uniqueid":{"tmdb":"%s"}},"id":1}'
                    ) % (updateitem_id, TMDB)
                    xbmc.executeJSONRPC(jSonQuery)
                    if resolve_method == "Title+Year":
                        fallback_chain.append("Title + Year -> TMDB")
                    elif resolve_method == "Title+Year+Director":
                        fallback_chain.append("Title + Year + Director -> TMDB")
                    fallback_chain.append("TMDB -> IMDb")
            except Exception as e:
                logError("Update", "[P1] Exception: %s" % str(e))
                updatedRating = None
        # ================================
        # PRIORITY 2: Recovery missing IDs
        # ================================
        if (not IMDb) or (not TMDB) or (not TVDB):
            try:
                IMDb, TVDB, TMDB, recovered = RecoverMissingIDs(updateitem, updateitem_id, tvshowid, season, IMDb, TVDB, TMDB, title, log_category="Update", log_prefix="[P2]", debug_log=debug_log)
            except Exception as e:
                logError("Update", "[P2] Exception: %s" % str(e))
        # ===============================
        # PRIORITY 3 - IMDb rating lookup
        # ===============================
        if IMDb:
            (updatedRating, updatedVotes, updatedTop250, provider, statusInfo) = get_IMDb_rating(updateitem, IMDb, debug_log=debug_log)
        # ===============================================================
        # PRIORITY 4 - Validate IMDb/TMDB mapping and retry rating lookup
        # ===============================================================
        if (updateitem in ("movie", "tvshow") and IMDb and TMDB and TMDB != "0" and updatedRating is None and source_override is None):
            imdb_repaired = False
            if debug_log:
                logDebug("Update", "[P4] IMDb=%s TMDB=%s updatedRating=%s" % (IMDb, TMDB, updatedRating))
                logDebug("Update", "[P4] Validating IMDb/TMDB mapping")
            try:
                # -----------------------------
                # Validate IMDb -> TMDB mapping
                # -----------------------------
                tmdb_imdb = None
                tmdb_status = None
                if updateitem == "movie":
                    recovered_tmdb = get_TMDB_movie_ID_from_IMDb(IMDb)
                    status = "OK" if recovered_tmdb else "TMDB ID not found"
                else:
                    recovered_tmdb = get_TMDB_tvshow_ID_from_IMDb(IMDb)
                    status = "OK" if recovered_tmdb else "TMDB ID not found"
                if debug_log:
                    logDebug("Update", "[P4] IMDb -> TMDB result=%s status=%s" % (recovered_tmdb, status))
                # ---------------------
                # Mapping is consistent
                # ---------------------
                if recovered_tmdb == TMDB:
                    if debug_log:
                        logDebug("Update", "[P4] IMDb/TMDB mapping is valid")
                # -------------------------------------------
                # Mapping differs - regenerate IMDb from TMDB
                # -------------------------------------------
                elif recovered_tmdb and recovered_tmdb != TMDB:
                    recovered_imdb, status = get_IMDb_ID_from_TMDb(updateitem, TMDB, debug_log=debug_log)
                    if debug_log:
                        logDebug("Update", "[P4] TMDB -> IMDb repair result=%s status=%s" % (recovered_imdb, status))
                    if recovered_imdb and recovered_imdb != IMDb:
                        old_imdb = IMDb
                        if updateitem == "movie":
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                                '"params":{"movieid":%d,"uniqueid":{"imdb":"%s"}},"id":1}'
                            ) % (updateitem_id, recovered_imdb)
                        else:
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails",'
                                '"params":{"tvshowid":%d,"uniqueid":{"imdb":"%s"}},"id":1}'
                            ) % (updateitem_id, recovered_imdb)
                        xbmc.executeJSONRPC(jSonQuery)
                        IMDb = recovered_imdb
                        imdb_repaired = True
                        logInfo("Update", "[P4] Repaired IMDb ID %s -> %s using TMDB ID %s (%s)" % (old_imdb, recovered_imdb, TMDB, title))
                        fallback_chain.append("IMDb repaired from TMDB")
                else:
                    if debug_log:
                        logDebug("Update", "[P4] Unable to validate IMDb/TMDB mapping")
                # -----------------------------------------------
                # Retry IMDb rating lookup using repaired IMDb ID
                # -----------------------------------------------
                if imdb_repaired:
                    if debug_log:
                        logDebug("Update", "[P4] Retrying IMDb rating lookup for IMDb=%s" % IMDb)
                    (updatedRating, updatedVotes, updatedTop250, provider, statusInfo) = get_IMDb_rating(updateitem, IMDb, debug_log=debug_log)
                    if debug_log:
                        logDebug("Update", "[P4] Retry result: rating=%s votes=%s" % (updatedRating, updatedVotes))
                else:
                    if (not imdb_repaired and tmdb_imdb and tmdb_imdb != IMDb):
                        RecoveryStats["I01"] += 1
                        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
                        if updateitem == "tvshow":
                            logLine = (title + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: " + sTMDB + ")")
                        else:
                            logLine = (title + " (IMDb ID: " + sIMDb + ", TMDB ID: " + sTMDB + ")")
                        LibraryHealth["Inconsistencies"].append(logLine)
            except Exception as e:
                logError("Update", "[P4] Exception: %s" % str(e))
        # =============================================================
        # PRIORITY 5 - Validate Episode IMDb ID and retry rating lookup
        # =============================================================
        if (updateitem == "episode" and IMDb and TMDB and updatedRating is None and source_override is None):
            imdb_repaired = False
            if debug_log:
                logDebug("Update", "[P5] INPUT IMDb=%s TMDB=%s TVDB=%s updatedRating=%s" % (IMDb, TMDB, TVDB, updatedRating))
            try:
                # -------------------------
                # Resolve IMDb ID from TMDB
                # -------------------------
                tmdb_imdb = None
                tmdb_status = None
                tvshow_tmdb = get_tvshow_tmdb_id(tvshowid)
                episode_num = get_episode_number(updateitem_id)
                if debug_log:
                    if episode_num is None:
                        logDebug("Update", "[P5] Episode number not available")
                    if tvshow_tmdb is None:
                        logDebug("Update", "[P5] TV Show TMDB ID not available")
                if episode_num is not None and tvshow_tmdb is not None:
                    tmdb_imdb, tmdb_status = get_IMDb_ID_from_TMDb("episode", tvshow_tmdb, season, episode_num, debug_log=debug_log)
                # ------------------------------------
                # Resolve IMDb ID from TVDB (optional)
                # ------------------------------------
                tvdb_imdb = None
                if TVDB:
                    tvdb_imdb = GetTVDBEpisodeIMDbID(TVDB)
                if debug_log:
                    logDebug("Update", "[P5] IMDb IDs delivered from providers: TMDB=%s TVDB=%s" % (tmdb_imdb, tvdb_imdb))
                repaired_imdb = None
                # -------------------
                # HIGH CONFIDENCE
                # TMDB and TVDB agree
                # -------------------
                if (tmdb_imdb and tvdb_imdb and tmdb_imdb == tvdb_imdb and IMDb != tmdb_imdb):
                    repaired_imdb = tmdb_imdb
                    if debug_log:
                        logDebug("Update", "[P5] High confidence repair (TMDB == TVDB)")
                # -------------------
                # MEDIUM CONFIDENCE
                # Only TMDB available
                # -------------------
                elif (tmdb_imdb and not tvdb_imdb and IMDb != tmdb_imdb):
                    repaired_imdb = tmdb_imdb
                    if debug_log:
                        logDebug("Update", "[P5] Medium confidence repair (TMDB only)")
                # -------------------
                # MEDIUM CONFIDENCE
                # Only TVDB available
                # -------------------
                elif (tvdb_imdb and not tmdb_imdb and IMDb != tvdb_imdb):
                    repaired_imdb = tvdb_imdb
                    if debug_log:
                        logDebug("Update", "[P5] Medium confidence repair (TVDB only)")
                # ---------------------------------
                # LOW CONFIDENCE
                # Providers disagree - don't repair
                # ---------------------------------
                elif (tmdb_imdb and tvdb_imdb and tmdb_imdb != tvdb_imdb):
                    logInfo("Update", "[P5] Conflicting IMDb mappings for '%s' (Kodi=%s TMDB=%s TVDB=%s)" % (title, IMDb, tmdb_imdb, tvdb_imdb))
                # --------------
                # Repair IMDb ID
                # --------------
                if repaired_imdb:
                    old_imdb = IMDb
                    jSonQuery = (
                        '{"jsonrpc":"2.0",'
                        '"method":"VideoLibrary.SetEpisodeDetails",'
                        '"params":{"episodeid":%d,'
                        '"uniqueid":{"imdb":"%s"}},'
                        '"id":1}'
                    ) % (
                        updateitem_id,
                        repaired_imdb
                    )
                    xbmc.executeJSONRPC(jSonQuery)
                    IMDb = repaired_imdb
                    imdb_repaired = True
                    fallback_chain.append("Episode IMDb repaired")
                    logInfo("Update", "[P5] Repaired Episode IMDb ID %s -> %s (%s)" % (old_imdb, repaired_imdb, title))
                # -----------------
                # Retry IMDb lookup
                # -----------------
                if imdb_repaired:
                    if debug_log:
                        logDebug("Update", "[P5] Retrying IMDb lookup using repaired IMDb=%s" % IMDb)
                    (updatedRating, updatedVotes, updatedTop250, provider, statusInfo) = get_IMDb_rating(updateitem, IMDb, debug_log=debug_log)
                    if debug_log:
                        logDebug("Update", "[P5] Retry result rating=%s votes=%s" % (updatedRating, updatedVotes))
                else:
                    if (not imdb_repaired and IMDb and TMDB and TVDB and updatedRating is None):
                        RecoveryStats["I01"] += 1
                        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
                        logLine = (title + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: " + sTMDB + ")")
                        LibraryHealth["Inconsistencies"].append(logLine)
            except Exception as e:
                logError("Update", "[P4.5] Exception: %s" % str(e))
        # =================================================
        # PRIORITY 6 - TMDB rating fallback
        # Fetch rating from TMDB if there is no IMDb rating
        # =================================================
        if updatedRating is None and source_override is None:
            if debug_log:
                logDebug("Update", "[P6] Get ratings from TMDB - IMDb not resolved or empty)")
                logDebug("Update", "[P6] INPUT updateitem=%s TMDB=%s tvshowid=%s season=%s" % (updateitem, TMDB, tvshowid, season))
            try:
                # --------------
                # MOVIE / TVSHOW
                # --------------
                if updateitem in ("movie", "tvshow") and TMDB and TMDB != "0":
                    if debug_log:
                        logDebug("Update", "[P6] Fetch TMDB rating for %s id=%s" % (updateitem, TMDB))
                    (updatedRating, updatedVotes, statusInfo) = get_TMDB_rating(updateitem, TMDB)
                    if debug_log:
                        logDebug("Update", "[P6] TMDB result rating=%s votes=%s status=%s" % (updatedRating, updatedVotes, statusInfo))
                    # ---------------------
                    # INVALID TMDB ID (404)
                    # ---------------------
                    if updatedRating is None and statusInfo and "404" in statusInfo:
                        if debug_log:
                            logDebug("Update", "[P6] TMDB returned 404 - marking as neutral")
                        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
                        flock.acquire()
                        try:
                            if updateitem == "movie":
                                statusLog(title + " (IMDb ID: " + sIMDb + ", TMDB ID: " + sTMDB + ")  --> (Invalid TMDB ID. Marking as neutral)")
                            else:
                                statusLog(title + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: " + sTMDB + ")  --> (Invalid TMDB ID. Marking as neutral)")
                        finally:
                            flock.release()
                        if updateitem == "movie":
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                                '"params":{"movieid":%d,"uniqueid":{"tmdb":"0"}},"id":1}'
                            ) % updateitem_id
                        else:
                            jSonQuery = (
                                '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails",'
                                '"params":{"tvshowid":%d,"uniqueid":{"tmdb":"0"}},"id":1}'
                            ) % updateitem_id
                        xbmc.executeJSONRPC(jSonQuery)
                        TMDB = "0"
                        updatedRating = None
                        provider = None
                    # -----------------
                    # VALID TMDB RATING
                    # -----------------
                    elif updatedRating is not None:
                        if debug_log:
                            logDebug("Update", "[P6] Using TMDB rating")
                        provider = "tmdb"
                        updatedTop250 = 0
                        fallback_chain.append("TMDB rating")
                # -----------------------
                # EPISODE (use show TMDB)
                # -----------------------
                elif updateitem == "episode" and tvshowid:
                    if debug_log:
                        logDebug("Update", "[P6] Episode fallback using show TMDB")
                    show_tmdb = None
                    jSonQuery = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                        '"params":{"tvshowid":%d,"properties":["uniqueid"]},"id":1}'
                    ) % tvshowid
                    jSonResponse = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
                    tvshowdetails = jSonResponse.get("result", {}).get("tvshowdetails", {})
                    unique_id = tvshowdetails.get("uniqueid")
                    if unique_id:
                        show_tmdb = unique_id.get("tmdb")
                    if debug_log:
                        logDebug("Update", "[P6] show_tmdb=%s" % show_tmdb)
                    if show_tmdb:
                        ep_number = int(title.split("x")[-1])
                        if debug_log:
                            logDebug("Update", "[P6] Fetch TMDB episode rating S%sE%s" % (season, ep_number))
                        (updatedRating, updatedVotes, statusInfo) = get_TMDB_rating("episode", show_tmdb, season, ep_number)
                        if debug_log:
                            logDebug("Update", "[P6] Episode TMDB result rating=%s votes=%s status=%s" % (updatedRating, updatedVotes, statusInfo))
                        if updatedRating is not None:
                            provider = "tmdb"
                            fallback_chain.append("Episode -> ShowTMDB")
            except Exception as e:
                logError("Update", "[P6] Exception: %s" % str(e))
                updatedRating = None
                statusInfo = "TMDB parse error: %s" % str(e)
        # =========================================================
        # LOGGING
        # =========================================================
        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
        if updatedRating is not None:
            statusInfo = "Rating: %s, Votes: %s" % (updatedRating, updatedVotes)
            if fallback_chain:
                statusInfo += " (fallback: " + " -> ".join(fallback_chain) + ")"
        flock.acquire()
        try:
            if updateitem == "movie":
                logLine = (title + " (IMDb ID: " + sIMDb + ", TMDB ID: " + sTMDB + ")")
                statusLog(logLine + "  --> " + (statusInfo if statusInfo else "(no rating resolved - possible outdated or incorrect IDs in Kodi database or no rating for this item)"))
                # --------------
                # LIBRARY HEALTH
                # --------------
                if sIMDb == "n/a" or sTMDB == "n/a":
                    LibraryHealth["MissingIDs"].append(logLine)
            else:
                logLine = (title + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: " + sTMDB + ")")
                statusLog(logLine + "  --> " + (statusInfo if statusInfo else "(no rating resolved - possible outdated or incorrect IDs in Kodi database or no rating for this item)"))
                # --------------
                # LIBRARY HEALTH
                # --------------
                if sIMDb == "n/a" or sTVDB == "n/a" or sTMDB == "n/a":
                    LibraryHealth["MissingIDs"].append(logLine)
        finally:
            flock.release()
        # =========================================================
        # WRITE RATING TO KODI
        # =========================================================
        if updatedRating is not None and provider:
            rating_block = (
                '"ratings":{"' + provider + '":{"rating":' +
                str(updatedRating) +
                ',"votes":' +
                str(updatedVotes).replace(",", "") +
                ',"default":true}}'
            )
            if updateitem == "movie":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":%d,%s,"top250":%d},"id":1}' % (updateitem_id, rating_block, updatedTop250)
            elif updateitem == "tvshow":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":%d,%s},"id":1}' % (updateitem_id, rating_block)
            elif updateitem == "episode":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":%d,%s},"id":1}' % (updateitem_id, rating_block)
            xbmc.executeJSONRPC(jSonQuery)
    elif updateitem == "season":
        doUpdateEpisodesBySeason(updateitem_id, IMDb, season, progress, percentage, flock, source_override)
    lock.acquire()
    num_threads -= 1
    lock.release()


class Movies:
    def __init__(self):
        self.lock = allocate_lock()
        self.flock = allocate_lock()

    def doUpdate(self, startedFromIcon=False):
        self.AllMovies = []
        self.getDBMovies(startedFromIcon)
        if len( self.AllMovies ) == 0:
            xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32840) )
            return
        if xbmcaddon.Addon().getSettingBool("ShowNotifications"):
            doNotify( addonLanguage(32255), 5000 )
            xbmc.sleep(5000)
        statusLog("---------------------------------------------------")
        if startedFromIcon:
            statusLog("---> Add-on icon click started ratings update for movies")
        else:
            statusLog("---> Scheduled/autostart ratings update for movies started")
        if xbmcaddon.Addon().getSetting("FullRefreshMode") == "true":
            statusLog("---> Monthly Full Refresh for movies started")
        if startedFromIcon:
            statusLog("---> Full Refresh for movies started from add-on icon click")
        statusLog("---------------------------------------------------")
        self.doUpdateTop250Movies()
        self.doUpdateMovies()
        if startedFromIcon:
            statusLog("---> Add-on icon click ratings update for movies finished")
        else:
            statusLog("---> Scheduled/autostart ratings update for movies finished")
        if xbmcaddon.Addon().getSettingBool("ShowNotifications"):
            doNotify( addonLanguage(32258), 5000 )
            xbmc.sleep(8000)
        return

    def doUpdateTop250Movies(self):
        global num_threads
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
        if not xbmcaddon.Addon().getSettingBool("Top250Support"):
            return
        logInfo("Update","Top250 synchronization started")
        Top250LogLevel = int(xbmcaddon.Addon().getSetting("Top250LogLevel"))
        changed_positions = 0
        # ----------------
        # LOAD TOP250 FILE
        # ----------------
        Top250Map = {}
        top250_path = get_local_top250_path(addonSettings)
        if not xbmcvfs.exists(top250_path):
            logInfo("Update","Top250 synchronization skipped: Top250.txt not found")
            return
        try:
            with open(top250_path, "r") as f:
                for line in f:
                    line = line.strip()
                    if not line:
                        continue
                    try:
                        pos, imdb_id = line.split("|", 1)
                        pos = int(pos.strip())
                        imdb_id = imdb_id.strip()
                        if imdb_id:
                            Top250Map[imdb_id] = pos
                    except:
                        continue
            logInfo("Update","Top250 entries loaded (have to be 250): %d" % len(Top250Map))
        except Exception as e:
            logError("Update", "Failed to parse Top250.txt: %s" % str(e))
            return
        # ----------------------------
        # LOAD ALL MOVIES FROM KODI DB
        # ----------------------------
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"params":{"properties":["uniqueid","title","top250"]},'
            '"id":1}'
        )
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        try:
            movies = jSonResponse.get('result', {}).get('movies', [])
            # -------------------------------------------------------
            # COUNT UNIQUE MOVIES FROM USER LIBRARY PRESENT IN TOP250
            # -------------------------------------------------------
            top250_imdb_ids = set()
            for item in movies:
                IMDb = TVDB = TMDB = None
                unique_id = item.get('uniqueid')
                if unique_id:
                    IMDb = unique_id.get('imdb')
                    TVDB = unique_id.get('tvdb')
                    TMDB = unique_id.get('tmdb')
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                if IMDb and IMDb in Top250Map:
                    top250_imdb_ids.add(IMDb)
            top250_movies_count = len(top250_imdb_ids)
            logInfo("Update","Movies from library found in Top250: %d" % top250_movies_count)
            counter = 0
            processed_top250 = 0
            progress = None
            if ShowProgress:
                progress = xbmcgui.DialogProgressBG()
                progress.create("%s (0 of %d)" % (addonLanguage(32261), top250_movies_count))
            for item in movies:
                counter += 1
                IMDb = TVDB = TMDB = None
                unique_id = item.get('uniqueid')
                if unique_id:
                    IMDb = unique_id.get('imdb')
                    TVDB = unique_id.get('tvdb')
                    TMDB = unique_id.get('tmdb')
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                if not IMDb:
                    continue
                movieid = item.get('movieid')
                title = item.get('title')
                currentTop250 = item.get('top250', 0)
                # ----------------------------
                # MOVIE IS CURRENTLY IN TOP250
                # ----------------------------
                if IMDb in Top250Map:
                    processed_top250 += 1
                    if ShowProgress and top250_movies_count > 0:
                        progress.update(int((processed_top250 * 100) / top250_movies_count), "%s (%d of %d)" % (addonLanguage(32261), processed_top250, top250_movies_count), title)
                    newTop250 = Top250Map[IMDb]
                    if currentTop250 != newTop250:
                        changed_positions += 1
                        if Top250LogLevel >= 1:
                            if currentTop250 > 0:
                                logInfo("Update", "Top250 update: %s: #%d -> #%d" % (title, currentTop250, newTop250))
                            else:
                                logInfo("Update", "Top250 update: %s (#%d)" % (title, newTop250))
                    elif Top250LogLevel == 2:
                        logInfo("Update", "Top250 update: %s (#%d)" % (title, newTop250))
                    while num_threads > max_threads * 2:
                        xbmc.sleep(500)
                    start_new_thread(
                        thread_parse_IMDb_page,
                        (
                            "movie",
                            movieid,
                            IMDb,
                            TVDB,
                            TMDB,
                            title,
                            -1,
                            None,
                            None,
                            Top250Map[IMDb],
                            self.lock,
                            self.flock,
                            None,
                            debug_log
                        )
                    )
                    self.lock.acquire()
                    num_threads += 1
                    self.lock.release()
                # -----------------
                # MOVIE LEFT TOP250
                # -----------------
                elif currentTop250 > 0:
                    if Top250LogLevel == 2:
                        logInfo("Update", "Removing stale Top250 position for: %s (#%d)" % (title, currentTop250))
                    query = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails",'
                        '"params":{"movieid":%d,"top250":0},'
                        '"id":1}'
                    ) % movieid
                    xbmc.executeJSONRPC(query)
            while num_threads > 0:
                xbmc.sleep(500)
            if ShowProgress:
                xbmc.sleep(1000)
                progress.close()
            logInfo("Update", "Top250 synchronization finished. Number of movies changed position in Top250: %d" % changed_positions)
        except Exception as e:
            if ShowProgress and progress:
                try:
                    progress.close()
                except:
                    pass
            logError("Update", "Exception: %s" % str(e))

    def getDBMovies(self, startedFromIcon=False):
        self.AllMovies = []
        dateAfter = None
        if xbmcaddon.Addon().getSetting("FullRefreshMode") != "true" and int(xbmcaddon.Addon().getSetting("UpdateMovieTime")) > 0 and not startedFromIcon:
            dateAfter = (datetime.now() - timedelta(days=365 * int(xbmcaddon.Addon().getSetting("UpdateMovieTime")))).date()
            logInfo("Update","Movie premiered filter enabled: date >= %s" % dateAfter)
        elif startedFromIcon:
            logInfo("Update","Movie premiered filter disabled: updating ALL movies (add-on click)")
        else:
            logInfo("Update","Movie premiered filter disabled: updating ALL movies")
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"params":{"properties":["uniqueid","title","year","premiered"],'
            '"sort":{"method":"year","order":"descending"}},'
            '"id":1}'
        )
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        try:
            movies = jSonResponse.get('result', {}).get('movies', [])
            logInfo("Update","Movies returned by Kodi DB (before filter): %d" % len(movies))
            for item in movies:
                premiered = item.get('premiered')
                # Apply premiered date filter
                if dateAfter:
                    try:
                        if not premiered:
                            continue
                        if datetime.strptime(premiered, "%Y-%m-%d").date() < dateAfter:
                            continue
                    except:
                        continue
                IMDb = TVDB = TMDB = None
                unique_id = item.get('uniqueid')
                if unique_id:
                    IMDb = unique_id.get('imdb')
                    TVDB = unique_id.get('tvdb')
                    TMDB = unique_id.get('tmdb')
                    IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                movieid = item.get('movieid')
                title = item.get('title')
                self.AllMovies.append((movieid, IMDb, TVDB, TMDB, title))
            logInfo("Update","Movies selected for update (after filter): %d" % len(self.AllMovies))
        except Exception as e:
            logError("Update", "getDBMovies exception: %s" % str(e))
        return

    def doUpdateMovies(self):
        global num_threads
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
        AllMovies = len(self.AllMovies)
        Counter = 0
        progress = None
        if ShowProgress:
            progress = xbmcgui.DialogProgressBG()
            progress.create(get_progress_title())
        for Movie in self.AllMovies:
            while num_threads > max_threads * 2:
                xbmc.sleep(500)
            if ShowProgress:
                Counter += 1
                progress.update(int((Counter * 100) / AllMovies), get_progress_title(), Movie[4])
            IMDb = Movie[1]
            TVDB = Movie[2]
            TMDB = Movie[3]
            if IMDb is None and TMDB:
                (IMDb, statusInfo) = get_IMDb_ID_from_TMDb("movie", TMDB, debug_log=debug_log)
                # DO NOT skip if both IMDb and TMDB are None. Title+Year+(Director if needed) fallback will be handled in thread_parse_IMDb_page().
            # ALWAYS START THREAD (even if IMDb and TMDB are None)
            start_new_thread(
                thread_parse_IMDb_page,
                (
                    "movie",
                    Movie[0],
                    IMDb,
                    TVDB,
                    TMDB,
                    Movie[4],
                    -1,
                    None,
                    progress,
                    0,
                    self.lock,
                    self.flock,
                    None,
                    debug_log
                )
            )
            self.lock.acquire()
            num_threads += 1
            self.lock.release()
        while num_threads > 0:
            xbmc.sleep(500)
        if ShowProgress:
            xbmc.sleep(1000)
            progress.close()
        return


class TVShows:
    def __init__(self):
        self.lock = allocate_lock()
        self.flock = allocate_lock()
        self.episodes_total_before = 0
        self.episodes_total_after = 0
        self._episode_filter_logged = False

    def doUpdate(self, startedFromIcon=False):
        self.AllTVShows = []
        self.getDBTVShows(startedFromIcon)
        if len( self.AllTVShows ) == 0:
            xbmcgui.Dialog().ok( "%s" % ( addonName ), addonLanguage(32841) )
            return
        if xbmcaddon.Addon().getSettingBool("ShowNotifications"):
            doNotify( addonLanguage(32256), 5000 )
            xbmc.sleep(5000)
        statusLog("-----------------------------------------------------")
        if startedFromIcon:
            statusLog("---> Add-on icon click started ratings update for TV shows")
        else:
            statusLog("---> Scheduled/autostart ratings update for TV shows started")
        if xbmcaddon.Addon().getSetting("FullRefreshMode") == "true" and xbmcaddon.Addon().getSetting("MonthlyFullTVShowsStatusSync") != "true":
            statusLog("---> Monthly Full Refresh for TV shows started")
        if xbmcaddon.Addon().getSetting("FullRefreshMode") == "true" and xbmcaddon.Addon().getSetting("SyncTVShows") == "true" and xbmcaddon.Addon().getSetting("MonthlyFullTVShowsStatusSync") == "true":
            statusLog("---> Monthly Full Refresh for TV shows started (ratings and statuses)")
        if xbmcaddon.Addon().getSetting("IconClickFullUpdate") == "true" and startedFromIcon:
            statusLog("---> Full Refresh for TV shows started from add-on icon click")
        statusLog("-----------------------------------------------------")
        self.doUpdateTVShows(startedFromIcon=startedFromIcon)
        if xbmcaddon.Addon().getSetting("SyncTVShows") == "true":
            self.AllTVShows = []
            self.getDBTVShows(ignoreFilter=True, startedFromIcon=startedFromIcon)
            self.doSynchronizeTVShowStatuses()
        if startedFromIcon:
            statusLog("---> Add-on icon click ratings update for TV shows finished")
        else:
            statusLog("---> Scheduled/autostart ratings update for TV shows finished")
        if xbmcaddon.Addon().getSettingBool("ShowNotifications"):
            doNotify( addonLanguage(32259), 5000 )
            xbmc.sleep(5000)
        return

    def getDBTVShows(self, ignoreFilter=False, startedFromIcon=False):
        UpdateTime = getUpdateTime()
        if (not ignoreFilter and not startedFromIcon and xbmcaddon.Addon().getSetting("FullRefreshMode") != "true" and UpdateTime > 0):
            dateAfter = (datetime.now() - timedelta(days=UpdateTime)).strftime('%Y-%m-%d')
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["uniqueid","title"], "filter": {"field": "dateadded", "operator": "greaterthan", "value": "' + str( dateAfter ) + '"}, "sort":{"method": "dateadded","order":"descending"}},"id":1}'
        else:
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["uniqueid","title"], "sort":{"method": "dateadded","order":"descending"}},"id":1}'
        jSonResponse = xbmc.executeJSONRPC( jSonQuery )
        jSonResponse = jSon.loads( jSonResponse )
        try:
            if 'tvshows' in jSonResponse['result']:
                for item in jSonResponse['result']['tvshows']:
                    IMDb = None; TVDB = None; TMDB = None
                    unique_id = item.get('uniqueid')
                    if unique_id is not None:
                        IMDb = unique_id.get('imdb')
                        TVDB = unique_id.get('tvdb')
                        TMDB = unique_id.get('tmdb')
                        IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                    tvshowid = item.get('tvshowid')
                    title = item.get('title')
                    self.AllTVShows.append((tvshowid, IMDb, TVDB, TMDB, title))
        except: pass
        return

    def doSynchronizeTVShowStatuses(self):
        if len(self.AllTVShows) == 0:
            statusLog("---> No TV shows found")
            return
        firstTVShowID = self.AllTVShows[0][0]
        if detectTVShowStatusSupport(firstTVShowID):
            self.synchronizeUsingKodiStatus()
        else:
            self.legacySyncAllTVShows()

    def synchronizeUsingKodiStatus(self):
        AllTVShows = len(self.AllTVShows)
        TotalTVShows = AllTVShows
        Counter = 0
        StatusesUpdated = 0
        progress = None
        if ShowProgress:
            progress = xbmcgui.DialogProgressBG()
            progress.create("Synchronizing TV show statuses")
        # Build Kodi status dictionary
        jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["status","premiered"]},"id":1}'
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        KodiTVShows = {}
        try:
            if 'tvshows' in jSonResponse['result']:
                for item in jSonResponse['result']['tvshows']:
                    KodiTVShows[item['tvshowid']] = {
                        "status": item.get("status", ""),
                        "premiered": item.get("premiered", "")
                    }
        except:
            pass
        TVShowsSyncFilter = int(xbmcaddon.Addon().getSetting("TVShowsSyncFilter"))
        ForceAllTVShows = (xbmcaddon.Addon().getSetting("FullRefreshMode") == "true" and xbmcaddon.Addon().getSetting("MonthlyFullTVShowsStatusSync") == "true")
        if (TVShowsSyncFilter > 0) and (not ForceAllTVShows):
            CurrentYear = datetime.now().year
            MinYear = CurrentYear - TVShowsSyncFilter
            FilteredTVShows = []
            for TVShow in self.AllTVShows:
                tvshowid = TVShow[0]
                kodi = KodiTVShows.get(tvshowid)
                if kodi is None:
                    continue
                premiered = kodi["premiered"]
                try:
                    premiered_year = int(premiered[:4])
                    if premiered_year >= MinYear:
                        FilteredTVShows.append(TVShow)
                except:
                    # Missing or invalid premiered date -> skip
                    pass
            self.AllTVShows = FilteredTVShows
            AllTVShows = len(self.AllTVShows)
        # Build TMDB status dictionary
        if TVShowsSyncFilter == 0:
            statusLog("---> TV show status synchronization (TVShow status mode) started on all %d TV shows" % TotalTVShows)
        elif ForceAllTVShows:
            statusLog("---> TV show status synchronization (TVShow status mode) started on all %d TV shows (Monthly full sync)" % TotalTVShows)
        else:
            statusLog("---> TV show status synchronization (TVShow status mode) started on %d TV shows (Last %d years, of %d total)" % (AllTVShows, TVShowsSyncFilter, TotalTVShows))
        TMDBStatuses = {}
        for TVShow in self.AllTVShows:
            tvshowid = TVShow[0]
            tmdb_id = TVShow[3]
            title = TVShow[4]
            if ShowProgress:
                Counter += 1
                percentage = (Counter * 100) / AllTVShows
                if ForceAllTVShows:
                    progress.update(int(percentage), "Reading TMDB statuses... (%d of %d) (Monthly full sync)" % (Counter, AllTVShows), title)
                elif TVShowsSyncFilter == 0:
                    progress.update(int(percentage), "Reading TMDB statuses... (%d of %d)" % (Counter, AllTVShows), title)
                else:
                    progress.update(int(percentage), "Reading TMDB statuses... (%d of %d) (of %d total) (Last %d years)" % (Counter, AllTVShows, TotalTVShows, TVShowsSyncFilter), title)
            (tmdb_status, statusInfo) = get_TMDB_tvshow_status(tmdb_id)
            if tmdb_status:
                TMDBStatuses[tvshowid] = tmdb_status
            else:
                logInfo("Update", "TV show '%s' status unavailable: %s" % (title, statusInfo))
        # Compare statuses and build update list
        TVShowsToUpdate = []
        for TVShow in self.AllTVShows:
            tvshowid = TVShow[0]
            title = TVShow[4]
            tmdb_status = TMDBStatuses.get(tvshowid)
            if tmdb_status is None:
                continue
            kodi = KodiTVShows.get(tvshowid)
            kodi_status = kodi["status"] if kodi else ""
            if kodi_status != tmdb_status:
                TVShowsToUpdate.append((tvshowid, title, kodi_status, tmdb_status))
        # Nothing to update?
        if len(TVShowsToUpdate) == 0:
            if ShowProgress:
                progress.close()
            statusLog("---> TV show status synchronization finished")
            if xbmcaddon.Addon().getSettingBool("ShowNotifications"):
                doNotify( addonLanguage(32275), 45000 )
            logInfo("Update", "All TV show statuses are already up to date")
            return
        # Update only changed TV shows
        StatusesUpdated = 0
        Counter = 0
        TotalToUpdate = len(TVShowsToUpdate)
        for (tvshowid, title, kodi_status, tmdb_status) in TVShowsToUpdate:
            kodi = KodiTVShows.get(tvshowid)
            premiered = kodi["premiered"] if kodi else ""
            if ShowProgress:
                Counter += 1
                percentage = (Counter * 100) / TotalToUpdate
                if ForceAllTVShows:
                    progress.update(int(percentage), "Updating TV show statuses... (%d of %d) (Monthly full sync)" % (Counter, TotalToUpdate), title)
                elif TVShowsSyncFilter == 0:
                    progress.update(int(percentage), "Updating TV show statuses... (%d of %d)" % (Counter, TotalToUpdate), title)
                else:
                    progress.update(int(percentage), "Updating TV show statuses... (%d of %d) (of %d total)" % (Counter, TotalToUpdate, TotalTVShows), title)
            (status, statusInfo) = UpdateTVShowStatus(tvshowid, tmdb_status)
            if status:
                StatusesUpdated += 1
                logInfo("Update", "TV show '%s' [%s] status updated: '%s' -> '%s'" % (title, premiered, kodi_status, tmdb_status))
            else:
                logInfo("Update", "TV show '%s' status not synchronized: %s" % (title, statusInfo))
        if ShowProgress:
            xbmc.sleep(7000)
            progress.close()
        statusLog("---> TV show status synchronization finished")
        logInfo("Update", "TV show statuses synchronized for %d of %d TV shows requiring an update" % (StatusesUpdated, TotalToUpdate))
        return

    def legacySyncAllTVShows(self):
        AllTVShows = len(self.AllTVShows)
        TotalTVShows = AllTVShows
        Counter = 0
        updated = 0
        percentage = 0
        progress = None
        # Build Kodi premiered dictionary
        jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows","params":{"properties":["premiered"]},"id":1}'
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        KodiTVShows = {}
        try:
            if 'tvshows' in jSonResponse['result']:
                for item in jSonResponse['result']['tvshows']:
                    KodiTVShows[item['tvshowid']] = item.get("premiered", "")
        except:
            pass
        # Apply TV show filter
        TVShowsSyncFilter = int(xbmcaddon.Addon().getSetting("TVShowsSyncFilter"))
        ForceAllTVShows = (xbmcaddon.Addon().getSetting("FullRefreshMode") == "true" and xbmcaddon.Addon().getSetting("MonthlyFullTVShowsStatusSync") == "true")
        if (TVShowsSyncFilter > 0) and (not ForceAllTVShows):
            CurrentYear = datetime.now().year
            MinYear = CurrentYear - TVShowsSyncFilter
            FilteredTVShows = []
            for TVShow in self.AllTVShows:
                tvshowid = TVShow[0]
                premiered = KodiTVShows.get(tvshowid, "")
                try:
                    premiered_year = int(premiered[:4])
                    if premiered_year >= MinYear:
                        FilteredTVShows.append(TVShow)
                except:
                    pass
            self.AllTVShows = FilteredTVShows
            AllTVShows = len(self.AllTVShows)
        if TVShowsSyncFilter == 0:
            statusLog("---> Status synchronization started on %d TV shows (All TV shows)" % AllTVShows)
        elif ForceAllTVShows:
            statusLog("---> Status synchronization started on all %d TV shows (Monthly full sync)" % TotalTVShows)
        else:
            statusLog("---> Status synchronization started on %d TV shows (Last %d years, of %d total)" % (AllTVShows, TVShowsSyncFilter, TotalTVShows))
        if ShowProgress:
            progress = xbmcgui.DialogProgressBG()
            if ForceAllTVShows:
                progress.create("Synchronizing TV show statuses (Monthly full sync)")
            elif TVShowsSyncFilter == 0:
                progress.create("Synchronizing TV show statuses")
            else:
                progress.create("Synchronizing TV show statuses (Last %d years)" % TVShowsSyncFilter)
        for TVShow in self.AllTVShows:
            if ShowProgress:
                Counter += 1
                percentage = (Counter * 100) / AllTVShows
                if TVShowsSyncFilter == 0:
                    progress.update(int(percentage), "TV show status synchronization... (%d of %d)" % (Counter, AllTVShows), TVShow[4])
                else:
                    progress.update(int(percentage), "TV show status synchronization... (%d of %d) (of %d total)" % (Counter, AllTVShows, TotalTVShows), TVShow[4])
            tvshowid = TVShow[0]
            TMDB = TVShow[3]
            Title = TVShow[4]
            (status, statusInfo) = UpdateTVShowStatusFromTMDB(tvshowid, TMDB, Title)
            if status:
                updated += 1
            else:
                logInfo("Update", "TV show '%s' status not synchronized: %s" % (Title, statusInfo))
        if ShowProgress:
            xbmc.sleep(1000)
            progress.close()
        statusLog("---> TV show status synchronization finished")
        logInfo("Update", "TV show statuses synchronized for %d of %d TV shows" % (updated, AllTVShows))
        return

    def doUpdateTVShows(self, startedFromIcon=False):
        global num_threads
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
        AllTVShows = len(self.AllTVShows)
        Counter = 0
        percentage = 0
        progress = None
        if ShowProgress:
            progress = xbmcgui.DialogProgressBG()
            progress.create(get_progress_title())
        for TVShow in self.AllTVShows:
            while num_threads > max_threads:
                xbmc.sleep(500)
            if ShowProgress:
                Counter += 1
                percentage = (Counter * 100) / AllTVShows
                progress.update(int(percentage), get_progress_title(), TVShow[4])
            IMDb = TVShow[1]
            TVDB = TVShow[2]
            TMDB = TVShow[3]
            # Try to resolve IMDb only if missing
            if IMDb is None:
                IMDb, statusInfo = get_tvshow_IMDb_ID("tvshow", TVShow[0], TVDB, TMDB, TVShow[4])
            # DO NOT EXIT if IMDb is None. Let thread handle TMDB fallback / TVDB->TMDB mapping
            start_new_thread(thread_parse_IMDb_page, ("tvshow", TVShow[0], IMDb, TVDB, TMDB, TVShow[4], -1, None, progress, 0, self.lock, self.flock, None, debug_log))
            self.lock.acquire()
            num_threads += 1
            self.lock.release()
            # ALWAYS update episodes
            self.doUpdateEpisodes(TVShow[0], TMDB, -1, progress, percentage, startedFromIcon=startedFromIcon)
        while num_threads > 0:
            xbmc.sleep(500)
        try:
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
                '"params":{"limits":{"start":0,"end":1}},'
                '"id":1}'
            )
            response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
            total_episodes = response.get("result", {}).get("limits", {}).get("total", 0)
        except:
            total_episodes = 0
        logInfo("Update","All episodes returned by Kodi DB (before filter): %d" % total_episodes)
        logInfo("Update","All episodes selected for update (after filter): %d" % self.episodes_total_after)
        if ShowProgress:
            xbmc.sleep(1000)
            progress.close()
        return

    def doUpdateEpisodes(self, tvshowid, tvshowTMDB, season, progress, percentage, datefilter=False, startedFromIcon=False):
        global num_threads
        debug_log = xbmcaddon.Addon().getSettingBool("DebugLog")
        dateAfter = None
        UpdateTime = getUpdateTime()
        if xbmcaddon.Addon().getSetting("FullRefreshMode") != "true" and not startedFromIcon and UpdateTime > 0:
            dateAfter = (datetime.now() - timedelta(days=UpdateTime)).date()
            if not self._episode_filter_logged:
                logInfo("Update", "Episode firstaired filter enabled: date >= %s" % dateAfter)
                self._episode_filter_logged = True
        elif startedFromIcon:
            if not self._episode_filter_logged:
                logInfo("Update", "Episode firstaired filter disabled: updating ALL episodes (add-on click)")
                self._episode_filter_logged = True
        else:
            if not self._episode_filter_logged:
                logInfo("Update", "Episode firstaired filter disabled: updating ALL episodes")
                self._episode_filter_logged = True
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{'
            '"tvshowid":%d,'
            '"properties":["uniqueid","episode","season","showtitle","firstaired"],'
            '"sort":{"method":"episode"}'
            '},"id":1}'
        ) % tvshowid
        response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
        try:
            episodes = response.get('result', {}).get('episodes', [])
            self.episodes_total_before += len(episodes)
            selected = 0
            for item in episodes:
                firstaired = item.get('firstaired')
                if not firstaired:
                    continue
                if dateAfter:
                    try:
                        if datetime.strptime(firstaired, "%Y-%m-%d").date() < dateAfter:
                            continue
                    except:
                        continue
                selected += 1
                while num_threads > max_threads:
                    xbmc.sleep(500)
                episodeid = item.get('episodeid')
                season = item.get('season')
                episode = "%02d" % item.get('episode')
                title = item.get('showtitle') + " " + str(season) + "x" + episode
                unique_id = item.get('uniqueid', {})
                IMDb = unique_id.get('imdb')
                TVDB = unique_id.get('tvdb')
                TMDB = unique_id.get('tmdb')
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                start_new_thread(
                    thread_parse_IMDb_page,
                    (
                        "episode",
                        episodeid,
                        IMDb,
                        TVDB,
                        TMDB,
                        title,
                        season,
                        tvshowid,
                        progress,
                        percentage,
                        self.lock,
                        self.flock,
                        None,
                        debug_log
                    )
                )
                self.lock.acquire()
                num_threads += 1
                self.lock.release()
            self.episodes_total_after += selected
        except Exception as e:
            logError("Update", "doUpdateEpisodes exception: %s" % str(e))
        return


def perform_update(startedFromIcon=False):
    if not wait_for_internet(wait=2, retry=1):
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32257))
        return
    cleanup_libraryHealth_log()
    for key in RecoveryStats:
        RecoveryStats[key] = 0
    for key in LibraryHealth:
        LibraryHealth[key] = []
    if xbmcaddon.Addon().getSetting("PerformingUpdate") == "true":
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32251))
        return
    if not xbmcaddon.Addon().getSettingBool("Movies") and not xbmcaddon.Addon().getSettingBool("TVShows"):
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32842))
        return
    # --------------------------------------
    # MANUAL FULL UPDATE (ADD-ON ICON CLICK)
    # --------------------------------------
    if startedFromIcon:
        confirm = xbmcgui.Dialog().yesno(
            addonName,
            " \n\n"
            "Ratings for all Movies, TV Shows and Episodes will be updated.\n"
            "The entire process may take several minutes depending on the size of your Kodi library.\n\n"
            "Continue?"
        )
        if not confirm:
            return
    # ------------------------
    # LOCAL DATASET VALIDATION
    # ------------------------
    if xbmcaddon.Addon().getSettingBool("LocalIMDbSQL"):
        if startedFromIcon:
            result = ensure_dataset_available()
            if result == "up_to_date":
                xbmc.sleep(2600)
                confirmForce = xbmcgui.Dialog().yesno(
                    addonName,
                    " \n\n"
                    "The IMDb dataset is already up to date and ratings have already been updated today.\n"
                    "Do you still want to run a full library update?"
                )
                if not confirmForce:
                    return
            elif result != "updated":
                xbmc.sleep(2600)
                xbmcgui.Dialog().ok(addonName, "Unable to update the local IMDb dataset.")
                return
        else:
            imdb_db_path = addonProfile + "/db/imdb_ratings.db"
            if not xbmcvfs.exists(imdb_db_path):
                logInfo("Update", "Update aborted: local IMDb dataset DB missing")
                xbmcgui.Dialog().ok(addonName, "Local IMDb dataset was not found.\n\nPlease update the dataset first.\nYou can do this by enabling scheduled updates or using the context menu.")
                return
        # -----------------
        # TOP250 VALIDATION
        # -----------------
        if xbmcaddon.Addon().getSettingBool("Top250Support"):
            top250_path = addonProfile + "/db/Top250.txt"
            if not xbmcvfs.exists(top250_path):
                # --------------
                # WEBSITE SOURCE
                # --------------
                if xbmcaddon.Addon().getSetting("Top250SelectLocation") == "2":
                    logInfo("Update","Top250.txt missing - attempting download from top250.info")
                    if not update_from_html():
                        logInfo("Update","Update aborted: failed downloading Top250 from top250.info")
                        xbmcgui.Dialog().ok(addonName, "Unable to download Top250 data from top250.info.")
                        return
                # ----------------------
                # LOCAL / NETWORK SOURCE
                # ----------------------
                else:
                    logInfo("Update","Update aborted: Top250.txt missing")
                    xbmcgui.Dialog().ok(
                        addonName,
                        "\n"
                        "Top250.txt was not found.\n\n"
                        "Disable Top250 support in add-on settings\n"
                        "or place Top250.txt in the add-on's /db folder\n"
                        "or specify a network share where the file is located.\n"
                        "or select a website as a source for downloading Top250.\n\n"
                        "Required format:\n"
                        "1|tt0111161\n"
                        "2|tt0068646\n"
                        "3|tt0468569\n"
                        "[...]\n"
                        "250|tt1954470"
                    )
                    return
    xbmcaddon.Addon().setSetting("PerformingUpdate", "true")
    # ------------------
    # RUN LIBRARY UPDATE
    # ------------------
    if xbmcaddon.Addon().getSettingBool("Top250Support"):
        top250_path = addonProfile + "/db/Top250.txt"
        if not xbmcvfs.exists(top250_path):
            logInfo("Update","Top250 support enabled but Top250.txt missing")
            xbmcgui.Dialog().notification(addonName, "Top250.txt not found - Top250 synchronization disabled but movies ratings update continue", xbmcgui.NOTIFICATION_WARNING, 7000)
    if xbmcaddon.Addon().getSettingBool("Movies"):
        Movies().doUpdate(startedFromIcon)
        logInfo("Update","Ratings update on Movies finished")
    if xbmcaddon.Addon().getSettingBool("TVShows"):
        TVShows().doUpdate(startedFromIcon)
        logInfo("Update","Ratings update on TV Shows finished")
    # ---------------------
    # LIBRARY HEALTH REPORT
    # ---------------------
    LibraryHealth["MissingIDs"].sort(key=str.lower)
    LibraryHealth["Inconsistencies"].sort(key=str.lower)
    if LibraryHealth["MissingIDs"]:
        libraryHealthLog("TMDB and TVDB are built by volunteers.")
        libraryHealthLog("If you have a few spare minutes, consider adding missing external IDs or correcting existing ones.")
        libraryHealthLog("Your contribution helps improve metadata quality for all Kodi users.")
        libraryHealthLog("--------------------------------------------------------------------------------")
        libraryHealthLog("Items with missing external IDs after automatic recovery:")
        libraryHealthLog("--------------------------------------------------------------------------------")
        for line in LibraryHealth["MissingIDs"]:
            libraryHealthLog(line)
    if LibraryHealth["Inconsistencies"]:
        if LibraryHealth["MissingIDs"]:
            libraryHealthLog("")
            libraryHealthLog("")
        libraryHealthLog(" ")
        libraryHealthLog("--------------------------------------------------------------------------------")
        libraryHealthLog("For the following items, no IMDb rating could be resolved although all external IDs")
        libraryHealthLog("are present and automatic validation could not identify a better mapping.")
        libraryHealthLog("This may indicate an obsolete or incorrect IMDb ID mapping in Kodi, TMDB or TVDB.")
        libraryHealthLog("--------------------------------------------------------------------------------")
        libraryHealthLog("Items with metadata inconsistencies detected:")
        libraryHealthLog("--------------------------------------------------------------------------------")
        for line in LibraryHealth["Inconsistencies"]:
            libraryHealthLog(line)
    # ----------------
    # RECOVERY SUMMARY
    # ----------------
    RecoverySummary = [
        ("S01", "Episodes - Recovered missing TMDB ID from IMDb ID"),
        ("S02", "Episodes - Recovered missing IMDb ID from TMDB ID"),
        ("S03", "Episodes - Recovered missing TVDB ID from TMDB ID"),
        ("S04", "Episodes - Recovered missing TVDB ID from TV show TVDB ID"),
        ("S05", "Episodes - Recovered missing IMDb ID from TVDB ID"),
        ("S06", "Episodes - Recovered missing TMDB ID from IMDb ID (S01 second run)"),
        ("S07", "Movies   - Recovered missing TMDB ID from IMDb ID"),
        ("S08", "Movies   - Recovered missing IMDb ID from TMDB ID"),
        ("S09", "TV Shows - Recovered missing TVDB ID from TMDB ID"),
        ("S10", "TV Shows - Recovered missing TMDB ID from TVDB ID"),
        ("S11", "TV Shows - Recovered missing TVDB ID from IMDb ID"),
        ("S12", "TV Shows - Recovered missing IMDb TV Show ID from TVDB ID"),
        ("S13", "TV Shows - Recovered missing TMDB TV Show ID from IMDb ID"),
        ("I01", "Metadata inconsistencies detected")
    ]
    totalRecovered = 0
    for key, description in RecoverySummary:
        count = RecoveryStats[key]
        if count:
            logInfo("Update", "[%s] %s: %d" % (key, description, count))
            if key != "I01":
                totalRecovered += count
    if totalRecovered:
        logInfo("Update", "%d items recovered in total" % totalRecovered)
    xbmcaddon.Addon().setSetting("PerformingUpdate", "false")
    if xbmcaddon.Addon().getSettingBool("ShowLogMessage") and xbmcaddon.Addon().getSetting("LogDialog") == "true":
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32824))
        xbmcaddon.Addon().setSetting("LogDialog", "false")
    xbmcaddon.Addon().setSetting("LastRatingsUpdateDate", datetime.now().strftime("%Y-%m-%d"))
    if xbmcaddon.Addon().getSetting("FullRefreshMode") == "true":
        xbmcaddon.Addon().setSetting("LastFullRefreshDate", datetime.now().strftime("%Y-%m-%d"))
        logInfo("Update", "Monthly Full Refresh completed. LastFullRefreshDate updated")
        xbmcaddon.Addon().setSetting("FullRefreshMode", "false")
    elif startedFromIcon:
        xbmcaddon.Addon().setSetting("LastFullRefreshDate", datetime.now().strftime("%Y-%m-%d"))
        logInfo("Update", "Add-on click Full Refresh completed. LastFullRefreshDate updated")
        xbmcaddon.Addon().setSetting("FullRefreshMode", "false")
    if xbmcaddon.Addon().getSettingBool("MonthlyFullRefresh"):
        last_refresh = datetime.strptime(xbmcaddon.Addon().getSetting("LastFullRefreshDate"), "%Y-%m-%d")
        next_full_refresh = (last_refresh + timedelta(days=30)).strftime("%Y-%m-%d")
        logInfo("Update", "Approximate next Full Refresh date: %s" % next_full_refresh)
    logInfo("Update","LastRatingsUpdateDate updated to %s" % datetime.now().strftime("%Y-%m-%d"))
    return