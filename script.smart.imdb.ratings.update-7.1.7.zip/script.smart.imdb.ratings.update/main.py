# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmcgui, xbmcaddon
from support.common import addonSettings, addonName
from core import update_main


def StartUpdate():
    update_main.perform_update()

def StartManualFullUpdate():
    if xbmcaddon.Addon().getSetting("IconClickFullUpdate") == "true":
        update_main.perform_update(startedFromIcon=True)
    else:
        xbmcgui.Dialog().ok(
            addonName,
            "Manual update via the add-on icon is disabled.\n\n"
            "Enable 'Run a full ratings update when the add-on icon is clicked' in the add-on settings."
        )

if __name__ == "__main__":
    StartManualFullUpdate()