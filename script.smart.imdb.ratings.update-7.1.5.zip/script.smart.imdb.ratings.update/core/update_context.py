# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc, xbmcgui, xbmcvfs
import re
import json as jSon
from datetime import datetime
from support.common import *
from support.httptools import wait_for_internet
from core.update_main import TVShows
from core.update_main import RecoverMissingIDs
from core.imdb_scraper import parse_IMDb_page
from core.tmdb_api import get_TMDB_rating
from core.imdb_dataset import get_local_rating
from core.imdb_dataset import get_timestamp_file_path
from core.tvdb_api import UpdateMissingBanner


def open_context_menu(filename, label):
    lower_filename = filename.lower()
    if not lower_filename.startswith("videodb://"):
        xbmcgui.Dialog().notification(addonName,"Unsupported item (non-library item)",xbmcgui.NOTIFICATION_INFO,4000)
        return
    if re.search(r"videodb://movies/sets/\d+/\?setid=\d+", lower_filename):
        from core import update_context_ms
        update_context_ms.open_context_menu(filename, label)
        return
    updateitem = ""
    movieid = -1
    episodeid = -1
    tvshowid = -1
    rating = -1
    votes = -1
    top250 = 0
    Title = ""
    IMDb = None
    TVDB = None
    TMDB = None
    season = -1
    episode = ""
    jSonQuery = None
    filename = filename.replace("/", " ")
    id_parts = re.findall(r"[+-]?\d+(?:\.\d+)?", filename)
    tag = 0
    if (
        "genreid" in filename or
        "year" in filename or
        "actorid" in filename or
        "directorid" in filename or
        "studioid" in filename or
        "setid" in filename or
        "countryid" in filename or
        "tagid" in filename or
        "videoversions" in filename
    ):
        tag = 1
    try:
        if "movies" in filename or "recentlyaddedmovies" in filename:
            updateitem = "movie"
            movieid = int(id_parts[0 + tag])
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails",'
                '"params":{"movieid":' + str(movieid) +
                ',"properties":["uniqueid","ratings","top250","title"]},"id":1}'
            )
        elif (
            ("tvshows" in filename or "inprogresstvshows" in filename)
            and "season" in filename
            and "tvshowid" in filename
        ):
            updateitem = "episode"
            episodeid = int(id_parts[2 + tag])
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails",'
                '"params":{"episodeid":' + str(episodeid) +
                ',"properties":["uniqueid","ratings","episode","season","showtitle","tvshowid"]},"id":1}'
            )
        elif (
            ("tvshows" in filename or "inprogresstvshows" in filename)
            and "tvshowid" in filename
        ):
            season = int(id_parts[1 + tag])
            if season == -1 and not label.startswith("* "):
                updateitem = "episode"
                episodeid = int(id_parts[2 + tag])
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails",'
                    '"params":{"episodeid":' + str(episodeid) +
                    ',"properties":["uniqueid","ratings","episode","season","showtitle","tvshowid"]},"id":1}'
                )
            else:
                updateitem = "season"
                tvshowid = int(id_parts[0 + tag])
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                    '"params":{"tvshowid":' + str(tvshowid) +
                    ',"properties":["uniqueid","ratings","title"]},"id":1}'
                )
        elif ("tvshows" in filename or "inprogresstvshows" in filename):
            tvshowid = int(id_parts[0 + tag])
            if tvshowid == -1:
                updateitem = "episode"
                episodeid = int(id_parts[2])
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails",'
                    '"params":{"episodeid":' + str(episodeid) +
                    ',"properties":["uniqueid","ratings","episode","season","showtitle","tvshowid"]},"id":1}'
                )
            else:
                updateitem = "tvshow"
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                    '"params":{"tvshowid":' + str(tvshowid) +
                    ',"properties":["uniqueid","ratings","title"]},"id":1}'
                )
        elif "recentlyaddedepisodes" in filename:
            updateitem = "episode"
            episodeid = int(id_parts[0])
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails",'
                '"params":{"episodeid":' + str(episodeid) +
                ',"properties":["uniqueid","ratings","episode","season","showtitle","tvshowid"]},"id":1}'
            )
    except Exception as e:
        logError("Context", "Exception: %s" % str(e))
        xbmcgui.Dialog().notification(addonName,"Unsupported item",xbmcgui.NOTIFICATION_INFO,3000)
        return
    if not jSonQuery:
        xbmcgui.Dialog().notification(addonName,"Unsupported item",xbmcgui.NOTIFICATION_INFO,3000)
        return
    jSonResponse = xbmc.executeJSONRPC(jSonQuery)
    jSonResponse = jSon.loads(jSonResponse)
    if 'moviedetails' in jSonResponse['result']:
        item = jSonResponse['result']['moviedetails']
        unique_id = item.get('uniqueid')
        if unique_id != None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
        Title = item.get('title')
        ratings = item.get('ratings')
        top250 = item.get('top250')
        imdb_rating = ratings.get('imdb')
        if imdb_rating != None:
            rating = imdb_rating.get('rating')
            votes = imdb_rating.get('votes')
    elif 'episodedetails' in jSonResponse['result']:
        item = jSonResponse['result']['episodedetails']
        unique_id = item.get('uniqueid')
        if unique_id != None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
        tvshowid = item.get('tvshowid')
        season = item.get('season')
        episode = "%02d" % item.get('episode')
        Title = item.get('showtitle') + " " + str(season) + "x" + str(episode)
        ratings = item.get('ratings')
        imdb_rating = ratings.get('imdb')
        if imdb_rating != None:
            rating = imdb_rating.get('rating')
            votes = imdb_rating.get('votes')
    elif 'tvshowdetails' in jSonResponse['result']:
        item = jSonResponse['result']['tvshowdetails']
        unique_id = item.get('uniqueid')
        if unique_id != None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
        Title = item.get('title')
        ratings = item.get('ratings')
        imdb_rating = ratings.get('imdb')
        if imdb_rating != None:
            rating = imdb_rating.get('rating')
            votes = imdb_rating.get('votes')
    context_menu_options(updateitem,movieid,episodeid,tvshowid,season,episode,IMDb,TVDB,TMDB,Title,rating,votes,top250)

def context_menu_options(updateitem, movieid, episodeid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title, rating, votes, top250):
    option = -1
    while True:
        id_label = ""
        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
        missing_tv_ids = False
        missing_movie_ids = False
        if updateitem in ("tvshow", "episode"):
            missing_tv_ids = (not IMDb) or (not TVDB) or (not TMDB)
        if updateitem == "movie":
            missing_movie_ids = (not IMDb) or (not TMDB)
        stringList = []
        api_option = len(stringList)
#----------- Show ratings updates sources
        stringList += ["[COLOR red]Update rating[/COLOR] [COLOR lightgreen](api.tiffara.com)[/COLOR]"]
        dataset_option = len(stringList)
        stringList += ["[COLOR red]Update rating[/COLOR] [COLOR lightgreen](local dataset)[/COLOR]"]
        html_option = -1
        if addonSettings.getSetting("ShowIMDbHTMLContext") == "true":
            html_option = len(stringList)
            stringList += ["[COLOR red]Update rating[/COLOR] [COLOR lightgreen](IMDb HTML)[/COLOR]"]
#----------- Show dataset update
        dataset_label = "[COLOR orange]Update local dataset now[/COLOR]"
        try:
            timestamp_file = get_timestamp_file_path()
            if xbmcvfs.exists(timestamp_file):
                with open(timestamp_file, "r") as f:
                    ts = f.read().strip()
                if ts:
                    try:
                        dt = datetime.strptime(ts, "%a, %d %b %Y %H:%M:%S %Z")
                        formatted = dt.strftime("%Y-%m-%d %H:%M")
                    except:
                        formatted = ts
                    dataset_label = "[COLOR orange]Update local dataset now[/COLOR] [COLOR gray](timestamp: %s)[/COLOR]" % formatted
        except Exception as e:
            logError("Context", "Failed to read dataset timestamp: %s" % str(e))
        dataset_update_option = len(stringList)
        stringList += [ dataset_label ]
#----------- Show IDs edits
        rating_option = -1
        top250_option = -1
        tvdb_option = -1
        tmdb_option = -1
        imdb_option = -1
        if updateitem != "season":
            rating_option = len(stringList)
            if rating != -1:
                rating = round(rating, 2)
                stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(
                    addonLanguage(32263) + ": ",
                    str(rating) + " (" + '{0:,}'.format(votes) + " " + addonLanguage(32264) + ")"
                ) ]
            else:
                stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(
                    addonLanguage(32263) + ": ",
                    addonLanguage(32531)
                ) ]
        if updateitem == "movie":
            top250_option = len(stringList)
            if top250 != 0:
                stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(
                    addonLanguage(32265) + ": ",
                    str(top250)
                ) ]
            else:
                stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(
                    addonLanguage(32265) + ": ",
                    addonLanguage(32531)
                ) ]
        elif updateitem != "season":
            tvdb_option = len(stringList)
            stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("TVDB ID: ", sTVDB) ]
        if updateitem != "season":
            tmdb_option = len(stringList)
            stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("TMDB ID: ", sTMDB) ]
            imdb_option = len(stringList)
            stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("IMDb ID: ", sIMDb) ]
#----------- Show banner update (only when do not exists)
        banner_option = -1
        if updateitem == "tvshow" and addonSettings.getSetting("FetchBanner") == "true" and not (UpdateMissingBanner(tvshowid, TVDB, Title) == "exists"):
            banner_option = len(stringList)
            stringList += [ "[COLOR deepskyblue]Refresh TV Show banner[/COLOR]" ]
#----------- Recover missing IDs (tv)
        recover_tv_ids_option = -1
        if updateitem in ("tvshow", "episode") and missing_tv_ids:
            recover_tv_ids_option = len(stringList)
            stringList += ["[COLOR orange]Recover missing IDs (if available)[/COLOR]"]
#----------- Recover missing IDs (movie)
        recover_movie_ids_option = -1
        if updateitem == "movie" and missing_movie_ids:
            recover_movie_ids_option = len(stringList)
            stringList += ["[COLOR orange]Recover missing IDs (if available)[/COLOR]"]
#----------- Show last 20 lines of logs
        timestamp_option = len(stringList)
        stringList += [ "[COLOR yellow]Show dataset timestamp log file[/COLOR]" ]
        log_option = len(stringList)
        stringList += [ "[COLOR yellow]Show last 20 lines of the log file[/COLOR]" ]
        if updateitem == "movie":
            title = addonName + " (Movie)"
        elif updateitem == "tvshow":
            title = addonName + " (TV Show)"
        elif updateitem == "episode":
            title = addonName + " (Episode)"
        elif updateitem == "season":
            title = addonName + " (Season)"
        else:
            title = addonName
#----------- Actions
        option = xbmcgui.Dialog().select(title, stringList)
        if option == -1:
            return
        elif option in (api_option, dataset_option, html_option):
            if option == api_option:
                source_override = "api"
            elif option == dataset_option:
                source_override = "dataset"
            else:
                source_override = "html"
            # dataset presence guard
            if source_override == "dataset":
                db_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/db/imdb_ratings.db"
                if not xbmcvfs.exists(db_path):
                    xbmcgui.Dialog().ok(addonName, "Local dataset not found.\n\nRun scheduled update using 'Local copy of IMDb Ratings dataset' \nor run 'Update local dataset now'")
                    continue
            _rating, _votes, _top250, _IMDb = doUpdateItem(updateitem, movieid, episodeid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title, source_override)
            if not (_rating == -1 and _votes == -1 and _top250 == -1):
                rating = _rating
                votes = int(_votes)
                top250 = _top250
            if _IMDb != None:
                IMDb = _IMDb
            if updateitem == "season":
                return
            else:
                continue
        elif option == recover_tv_ids_option:
            try:
                parts = []
                if updateitem == "episode":
                    updateitem_id = episodeid
                else:
                    updateitem_id = tvshowid
                IMDb, TVDB, TMDB, recovered = RecoverMissingIDs(updateitem, updateitem_id, tvshowid, season, IMDb, TVDB, TMDB, Title, log_category="Context", log_prefix="[Recover]")
                if recovered["imdb"]:
                    parts.append("IMDb")
                if recovered["tvdb"]:
                    parts.append("TVDB")
                if recovered["tmdb"]:
                    parts.append("TMDB")
                if parts:
                    xbmcgui.Dialog().notification(addonName, "Recovered IDs: %s" % ", ".join(parts), xbmcgui.NOTIFICATION_INFO, 5000)
                else:
                    xbmcgui.Dialog().notification(addonName, "No additional IDs could be recovered", xbmcgui.NOTIFICATION_INFO, 5000)
            except Exception as e:
                logError("Context", "ID recovery failed: %s" % str(e))
            continue
        elif option == recover_movie_ids_option:
            try:
                parts = []
                IMDb, TVDB, TMDB, recovered = RecoverMissingIDs(updateitem, movieid, tvshowid, season, IMDb, TVDB, TMDB, Title, log_category="Context", log_prefix="[Recover]")
                if recovered["imdb"]:
                    parts.append("IMDb")
                if recovered["tvdb"]:
                    parts.append("TVDB")
                if recovered["tmdb"]:
                    parts.append("TMDB")
                if parts:
                    xbmcgui.Dialog().notification(addonName, "Recovered IDs: %s" % ", ".join(parts), xbmcgui.NOTIFICATION_INFO, 5000)
                else:
                    xbmcgui.Dialog().notification(addonName, "No additional IDs could be recovered", xbmcgui.NOTIFICATION_INFO, 5000)
            except Exception as e:
                logError("Context", "ID recovery failed: %s" % str(e))
            continue
        # UPDATE LOCAL DATASET NOW
        elif option == dataset_update_option:
            try:
                logInfo("Context", "Manual dataset update requested")
                # BLOCK: update already running
                if addonSettings.getSetting("PerformingUpdate") == "true":
                    xbmcgui.Dialog().ok(addonName, "Another update is already running.\n\nPlease wait until it finishes.")
                    continue
                # BLOCK: scheduled update soon
                from core.imdb_dataset import is_scheduled_update_soon
                if is_scheduled_update_soon(10):
                    xbmcgui.Dialog().ok(addonName, "Scheduled dataset update will run shortly.\n\nManual update blocked to avoid duplication.")
                    continue
                # CHECK: already up-to-date
                from core.imdb_dataset import is_dataset_up_to_date
                up_to_date, msg = is_dataset_up_to_date()
                if up_to_date:
                    xbmcgui.Dialog().ok(addonName, "Dataset is already up to date.\n\nNo download needed.")
                    continue
                # CONFIRMATION
                confirm = xbmcgui.Dialog().yesno(
                    addonName,
                    "This will download and rebuild the local IMDb dataset.\n"
                    "It may take 2–3 minutes.\n\nContinue?"
                )
                if not confirm:
                    continue
                # RUN UPDATE
                addonSettings.setSetting("PerformingUpdate", "true")
                progress = xbmcgui.DialogProgressBG()
                progress.create("IMDb Dataset", "Updating local dataset...")
                logInfo("Context", "Starting dataset update")
                from core.imdb_dataset import check_dataset_update
                check_dataset_update()
                progress.close()
                addonSettings.setSetting("PerformingUpdate", "false")
                xbmcgui.Dialog().ok(addonName, "Local dataset update completed.")
            except Exception as e:
                addonSettings.setSetting("PerformingUpdate", "false")
                logError("Context", "Dataset update failed: %s" % str(e))
                xbmcgui.Dialog().ok(addonName, "Dataset update failed.")
            continue
        elif option == banner_option and addonSettings.getSetting("FetchBanner") == "true":
            try:
                status = UpdateMissingBanner(tvshowid, TVDB, Title)
                if status == "downloaded":
                    xbmcgui.Dialog().notification(addonName, "Banner downloaded - action completed", xbmcgui.NOTIFICATION_INFO, 5000)
                elif status == "exists":
                    xbmcgui.Dialog().notification(addonName, "Banner already present - no action needed", xbmcgui.NOTIFICATION_INFO, 5000)
                elif status == "no_tvdb":
                    xbmcgui.Dialog().notification(addonName, "TVDB ID not available", xbmcgui.NOTIFICATION_WARNING, 5000)
                elif status == "not_found":
                    xbmcgui.Dialog().notification(addonName, "No TVDB banner found", xbmcgui.NOTIFICATION_WARNING, 5000)
                else:
                    xbmcgui.Dialog().notification(addonName, "Banner update failed (wrong TVDB ID?)", xbmcgui.NOTIFICATION_ERROR, 5000)
            except Exception as e:
                logError("Context", "Banner refresh failed: %s" % str(e))
            return
        elif option == log_option:
            try:
                log_file = get_current_log_path()
                if not xbmcvfs.exists(log_file):
                    xbmcgui.Dialog().ok(addonName, "Log file not found.")
                    continue
                with open(log_file, "r", encoding="utf-8") as f:
                    content = f.read()
                lines = content.splitlines()
                last_lines = lines[-20:] if len(lines) >= 20 else lines
                formatted_lines = []
                for line in last_lines:
                    line = re.sub(r",\s*(TVDB|TMDB) ID:\s*[^,\)]+", "", line)
                    line = line.replace("Votes:", "")
                    line = line.replace("-->", "->")
                    line = re.sub(r"\s+", " ", line)
                    line = line.replace("( ", "(").replace(" )", ")").strip()
                    formatted_lines.append(line)
                text = "=== Last 20 log lines ===\n\n" + "\n".join(formatted_lines)
                xbmcgui.Dialog().textviewer("Today's Smart IMDb Log", text)
            except Exception as e:
                logError("Context", "Failed to read log: %s" % str(e))
                xbmcgui.Dialog().ok(addonName, "Failed to read log file.")
            continue
        elif option == timestamp_option:
            try:
                dataset_history_log_file = addonProfile + "/logs/_ratings_dataset.timestamp.history.log"
                if not xbmcvfs.exists(dataset_history_log_file):
                    xbmcgui.Dialog().ok(addonName, "Dataset timestamp log file not found.")
                    continue
                with open(dataset_history_log_file, "r", encoding="utf-8") as f:
                    content = f.read()
                lines = content.splitlines()
                last_lines = lines[-20:] if len(lines) >= 20 else lines
                text = ("=== IMDb Dataset Publication History (last 20 entries) ===\n\n" + "\n".join(last_lines))
                xbmcgui.Dialog().textviewer("IMDb Dataset Timestamp History", text)
            except Exception as e:
                logError("Context", "Failed to read log: %s" % str(e))
                xbmcgui.Dialog().ok(addonName, "Failed to read log file.")
            continue
        elif option == rating_option:
            continue
        elif option == top250_option:
            continue
        elif option == tvdb_option:
            id = xbmcgui.Dialog().input("TVDB ID", sTVDB)
            if id:
                TVDB = id
                id_label = "tvdb"
        elif option == tmdb_option:
            id = xbmcgui.Dialog().input("TMDB ID", sTMDB)
            if id:
                TMDB = id
                id_label = "tmdb"
        elif option == imdb_option:
            id = xbmcgui.Dialog().input("IMDb ID", sIMDb)
            if id:
                IMDb = id
                id_label = "imdb"
        if id_label:
            if updateitem == "movie":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":' + str(movieid) + ',"uniqueid": {"' + id_label + '": "' + id + '"}},"id":1}'
            elif updateitem == "tvshow":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str(tvshowid) + ',"uniqueid": {"' + id_label + '": "' + id + '"}},"id":1}'
            elif updateitem == "episode":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":' + str(episodeid) + ',"uniqueid": {"' + id_label + '": "' + id + '"}},"id":1}'
            xbmc.executeJSONRPC(jSonQuery)

def doUpdateItem(updateitem, movieid, episodeid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title, source_override=None):
    from core.update_main import thread_parse_IMDb_page
    from _thread import allocate_lock
    if not wait_for_internet(wait=0, retry=1):
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32257))
        return -1, -1, -1, None
    if addonSettings.getSetting("PerformingUpdate") == "true":
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32251))
        return -1, -1, -1, None
    addonSettings.setSetting("PerformingUpdate", "true")
    progress = xbmcgui.DialogProgressBG()
    progress.create(get_progress_title(source_override), Title)
    lock = allocate_lock()
    flock = allocate_lock()
    updateitem_id = None
    if updateitem == "movie":
        statusLog("[Context] Rating update on movie, source: " + source_override)
        updateitem_id = movieid
    elif updateitem == "tvshow":
        statusLog("[Context] Rating update on TV show, source: " + source_override)
        updateitem_id = tvshowid
        # Testing if GetTVShowDetails RETURNS value for 'status' property
        # Once it is implemented in Kodi 22 after PR merge is completed into Kodi master branch,
        # then one day it should be possible.
        # If it is not implemented then the following error is returned
        # into my add-on activity.log (or kodi.log if selected by the user):
        # {"error":{"code":-32602,"data":{"method":"VideoLibrary.GetTVShowDetails","stack":
        # {"message":"array element at index 0 does not match","name":"Item.Fields.Base",
        # "property":{"message":"Received value does not match any of the defined enum values","type":"string"},"type":"array"}},"message":"Invalid params."},"id":1,"jsonrpc":"2.0"}
#        jSonQuery = (
#            '{"jsonrpc":"2.0",'
#            '"method":"VideoLibrary.GetTVShowDetails",'
#            '"params":{"tvshowid":%d,"properties":["status"]},'
#            '"id":1}'
#        ) % tvshowid
#        response = xbmc.executeJSONRPC(jSonQuery)
#        logInfo("TEST", "GET response: %s" % response)
#        return

        if addonSettings.getSetting("SyncTVShows") == "true":
            (tvshow_status, statusInfo) = UpdateTVShowStatusFromTMDB(tvshowid, TMDB, Title)
            if tvshow_status:
                statusLog("[Context] TV show status synchronized: '%s' -> %s" % (Title, tvshow_status))
            else:
                statusLog("[Context] TV show status not synchronized: %s (%s)" % (Title, statusInfo))
    elif updateitem == "episode":
        statusLog("[Context] Rating update on episode, source: " + source_override)
        updateitem_id = episodeid
    elif updateitem == "season":
        statusLog("[Context] Rating update on Season in TV Show '%s', source: %s" % (Title, source_override))
        updateitem_id = tvshowid
    thread_parse_IMDb_page(
        updateitem,
        updateitem_id,
        IMDb,
        TVDB,
        TMDB,
        Title,
        season,
        tvshowid,
        progress,
        100,
        lock,
        flock,
        source_override
    )
    # Context menu: TV Shows -> also update all episodes
    if updateitem == "tvshow":
        try:
            statusLog("[Context] Updating ratings on all episodes for TV show: '" + Title + "'")
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{'
                '"tvshowid":%d,'
                '"properties":["uniqueid","episode","season","showtitle"]'
                '},"id":1}'
            ) % tvshowid
            response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
            episodes = response.get("result", {}).get("episodes", [])
            total = len(episodes)
            count = 0
            for item in episodes:
                episodeid = item.get("episodeid")
                season = item.get("season")
                episode = "%02d" % item.get("episode")
                title = item.get("showtitle") + " " + str(season) + "x" + episode
                unique_id = item.get("uniqueid", {})
                IMDb = unique_id.get("imdb")
                TVDB = unique_id.get("tvdb")
                TMDB = unique_id.get("tmdb")
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                count += 1
                percentage = int((count / float(total)) * 100)
                progress.update(percentage, get_progress_title(source_override), "%s (%d/%d)" % (title, count, total))
                thread_parse_IMDb_page(
                    "episode",
                    episodeid,
                    IMDb,
                    TVDB,
                    TMDB,
                    title,
                    season,
                    tvshowid,
                    progress,
                    percentage,
                    lock,
                    flock,
                    source_override
                )
        except Exception as e:
            logError("Context", "Episode update failed: %s" % str(e))
    progress.update(100, get_progress_title(source_override), Title)
    xbmc.sleep(500)
    progress.close()
    addonSettings.setSetting("PerformingUpdate", "false")
    try:
        if updateitem == "movie":
            query = '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":%d,"properties":["ratings","top250","uniqueid"]},"id":1}' % movieid
        elif updateitem == "tvshow":
            query = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":%d,"properties":["ratings","uniqueid"]},"id":1}' % tvshowid
        elif updateitem == "episode":
            query = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails","params":{"episodeid":%d,"properties":["ratings","uniqueid"]},"id":1}' % episodeid
        else:
            return -1, -1, -1, None
        response = jSon.loads(xbmc.executeJSONRPC(query))
        details = list(response["result"].values())[0]
        ratings = details.get("ratings", {})
        imdb_rating = ratings.get("imdb")
        if imdb_rating:
            rating = imdb_rating.get("rating")
            votes = imdb_rating.get("votes")
        else:
            rating = -1
            votes = -1
        unique_id = details.get("uniqueid", {})
        IMDb = unique_id.get("imdb")
        top250 = details.get("top250", 0)
        return rating, votes, top250, IMDb
    except:
        return -1, -1, -1, None