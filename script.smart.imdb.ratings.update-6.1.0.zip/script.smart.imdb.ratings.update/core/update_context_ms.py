# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# Movies Collection Context #
#############################

import xbmc, xbmcgui
import json as jSon

from support.common import *
from core.update_common import *
from support.httptools import wait_for_internet


def open_context_menu(filename, label):
    UpdateMovieSet(filename, label)


def UpdateMovieSet(filename, label):
    set_name = label
    if not set_name:
        xbmcgui.Dialog().ok(addonName, "Unable to detect movie collection.")
        return
    while True:
        stringList = [
            "[COLOR red]Update rating[/COLOR] [COLOR lightgreen](IMDbAPI.dev)[/COLOR]",
            "[COLOR red]Update rating[/COLOR] [COLOR lightgreen](local dataset)[/COLOR]",
            "[COLOR red]Update rating[/COLOR] [COLOR lightgreen](IMDb HTML)[/COLOR]",
            "[COLOR yellow]Show last 20 lines of the log file[/COLOR]"
        ]
        option = xbmcgui.Dialog().select(
            addonName + " (Collection)",
            stringList
        )
        if option == -1:
            return
        if option in (0,1,2):
            source_override = ["api","dataset","html"][option]
            run_collection_update(set_name, source_override)
            continue
        elif option == 3:
            show_log()
            continue


# =========================================================
# CORE UPDATE
# =========================================================
def run_collection_update(set_name, source_override):
    from core.update_main import thread_parse_IMDb_page
    from _thread import allocate_lock
    if not wait_for_internet(wait=0, retry=1):
        xbmcgui.Dialog().ok(addonName, addonLanguage(32257))
        return
    if addonSettings.getSetting("PerformingUpdate") == "true":
        xbmcgui.Dialog().ok(addonName, addonLanguage(32251))
        return
    addonSettings.setSetting("PerformingUpdate", "true")
    safe_name = set_name.replace("'", "")
    statusLog(" [Context] Updating ratings on all movies in '%s', source: %s" % (safe_name, source_override))
    progress = xbmcgui.DialogProgressBG()
    progress.create(get_progress_title(source_override), set_name)
    lock = allocate_lock()
    flock = allocate_lock()
    query = (
        '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
        '"params":{"filter":{"field":"set","operator":"is","value":"%s"},'
        '"properties":["uniqueid","title"]},"id":1}'
    ) % set_name
    response = jSon.loads(xbmc.executeJSONRPC(query))
    movies = response.get("result", {}).get("movies", [])
    total = len(movies)
    count = 0
    for item in movies:
        movieid = item.get("movieid")
        title = item.get("title")
        unique = item.get("uniqueid", {})
        IMDb, TVDB, TMDB = normalize_IDs(
            unique.get("imdb"),
            unique.get("tvdb"),
            unique.get("tmdb")
        )
        count += 1
        percentage = int((count / float(total)) * 100)
        progress.update(percentage, get_progress_title(source_override), "%s (%d/%d)" % (set_name, count, total))
        thread_parse_IMDb_page(
            "movie",
            movieid,
            IMDb,
            TVDB,
            TMDB,
            title,
            -1,
            None,
            progress,
            percentage,
            lock,
            flock,
            source_override
        )
    progress.close()
    addonSettings.setSetting("PerformingUpdate", "false")


# =========================================================
# LOG VIEWER
# =========================================================
def show_log():
    try:
        import xbmcvfs
        log_file = get_current_log_path()
        if not xbmcvfs.exists(log_file):
            xbmcgui.Dialog().ok(addonName, "Log file not found.")
            return
        with open(log_file, "r", encoding="utf-8") as f:
            content = f.read()
        f.close()
        lines = content.splitlines()
        last_lines = lines[-20:] if len(lines) >= 20 else lines
        formatted_lines = []
        for line in last_lines:
            line = re.sub(r",\s*(TVDB|TMDB) ID:\s*[^,\)]+", "", line)
            line = line.replace("Votes:", "")
            line = line.replace("-->", "->")
            line = re.sub(r"\s+", " ", line)
            line = line.replace("( ", "(").replace(" )", ")").strip()
            formatted_lines.append(line)
        text = "=== Last 20 log lines ===\n\n" + "\n".join(formatted_lines)
        xbmcgui.Dialog().textviewer("Log Viewer", text)
    except Exception as e:
        xbmc.log("[IMDbRatings][CONTEXT] Failed to read log: %s" % str(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(addonName, "Failed to read log file.")


# =========================================================
# ENTRY POINT
# =========================================================
if __name__ == "__main__":
    UpdateMovieSet()