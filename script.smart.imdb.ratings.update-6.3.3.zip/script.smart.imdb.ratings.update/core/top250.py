# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################


import sys
import os
import xbmcvfs
import re
import xbmcgui, xbmc, xbmcaddon

from support.common import *
from core.imdb_dataset import check_dataset_update

# FILE Top250.txt WITH TOP250 MOVIES.
# FORMAT MUST BE AS FOLLOW (of course without leading #):
#1|tt0111161
#2|tt0068646
#3|tt0468569
#4|tt0071562
#5|tt0050083
#6|tt0167260
#7|tt0108052
#8|tt0120737
#9|tt0110912
#[...]
#246|tt0019254
#247|tt4016934
#248|tt0074958
#249|tt4430212
#250|tt8108198


def log(msg):
    logInfo("Top250", msg)



def validate_credentials(creds):
    # login:password
    pattern = r"^[^:]+:[^:]+$"
    return re.match(pattern, creds) is not None

def validate_location(location):
    if not location.startswith("//"):
        return False
    if not location.lower().endswith(".txt"):
        return False
    return True

def validate_top250_file(path):
    try:
        with open(path, "r") as f:
            lines = [x.strip() for x in f.readlines() if x.strip()]
        if len(lines) != 250:
            return False
        for idx, line in enumerate(lines, start=1):
            pattern = r"^%d\|tt\d+$" % idx
            if not re.match(pattern, line):
                return False
        return True
    except Exception as e:
        logError("Top250","File validation failed: %s" % str(e))
        return False

def get_local_top250_path(addonSettings):
    return (xbmc.translatePath(addonSettings.getAddonInfo("profile")) + "/db/Top250.txt")

def get_remote_top250_path(addonSettings):
    Top250Location = addonSettings.getSetting("Top250Location")
    Top250Authenticate = addonSettings.getSetting("Top250Authenticate")
    Top250Creds = addonSettings.getSetting("Top250Creds")
    # normalize slashes
    Top250Location = Top250Location.replace("\\", "/")
    # =========================
    # VALIDATE LOCATION
    # =========================
    if not validate_location(Top250Location):
        log("Invalid location")
        xbmcgui.Dialog().ok("Smart IMDb Ratings Update", "Top250 file location is invalid.\n\nIt MUST start with // and end with .txt")
        return None
    # =========================
    # LINUX -> NFS
    # =========================
    if sys.platform.startswith("linux"):
        return "nfs:" + Top250Location
    # =========================
    # WINDOWS -> SMB
    # =========================
    elif sys.platform.startswith("win"):
        smb = "smb:" + Top250Location
        # =========================
        # AUTHENTICATION
        # =========================
        if Top250Authenticate == "true":
            if not validate_credentials(Top250Creds):
                log("Invalid credentials")
                xbmcgui.Dialog().ok("Smart IMDb Ratings Update", "Top250 credentials are invalid.\n\nRequired format:\nuser:password")
                return None
            smb = smb.replace(
                "smb://",
                "smb://%s@" % Top250Creds,
                1
            )
        return smb
    return None


def get_remote_mtime():
    try:
        remote_path = get_remote_top250_path(addonSettings)
        if not remote_path:
            return None
        stat = xbmcvfs.Stat(remote_path)
        return stat.st_mtime()
    except Exception as e:
        logError("Top250","Stat failed: %s" % str(e))
        return None


def update_if_needed(addonSettings, db_folder, log):
    Top250SelectLocation = addonSettings.getSetting("Top250SelectLocation")
    # =========================================================
    # LOCAL MODE
    # =========================================================
    if Top250SelectLocation == "0":
        local_top250 = get_local_top250_path(addonSettings)
        if not os.path.exists(local_top250):
            log("Top 250: Local file missing")
            return
        if not validate_top250_file(local_top250):
            log("Top 250: Local file invalid")
            xbmcgui.Dialog().ok("Smart IMDb Ratings Update", "Local Top250.txt file is invalid.")
            return
        log("Top250: Local mode: using local file")
        return
    local_file = os.path.join(db_folder, "Top250.txt")
    temp_file = os.path.join(db_folder, "Top250_temp.txt")
    remote_path = get_remote_top250_path(addonSettings)
    if not remote_path:
        log("Top 250: Invalid remote path")
        xbmcgui.Dialog().ok("Smart IMDb Ratings Update", "Top250 remote path is invalid or inaccessible.")
        return
    log("Top 250: Remote path: %s" % remote_path)
    remote_mtime = get_remote_mtime()
    if not remote_mtime:
        log("Top 250: Cannot read remote file")
        return
    local_mtime = addonSettings.getSetting("Top250MTime")
    if str(remote_mtime) == local_mtime and os.path.exists(local_file):
        log("Top 250: Up to date")
        return
    log("Top 250: Updating...")
    try:
        # =========================
        # COPY TO TEMP
        # =========================
        success = xbmcvfs.copy(remote_path, temp_file)
        if not success:
            log("Top 250: File copy failed")
            if addonSettings.getSetting("Top250Authenticate") == "true":
                xbmcgui.Dialog().ok("Smart IMDb Ratings Update", "Failed to copy Top250 file from remote location.\n\nCheck remote path and credentials.")
            else:
                xbmcgui.Dialog().ok("Smart IMDb Ratings Update", "Failed to copy Top250 file from remote location.")
            return
        # =========================
        # VALIDATE TEMP FILE
        # =========================
        if not validate_top250_file(temp_file):
            log("Top 250: File validation failed")
            xbmcgui.Dialog().ok("Smart IMDb Ratings Update", "Top250 remote file is invalid.\n\nIt MUST contain exactly:\n1|tt0111161\n...\n250|tt1234567")
            if xbmcvfs.exists(temp_file):
                xbmcvfs.delete(temp_file)
            return
        # =========================
        # REPLACE REAL FILE
        # =========================
        if xbmcvfs.exists(local_file):
            xbmcvfs.delete(local_file)
        xbmcvfs.rename(temp_file, local_file)
        addonSettings.setSetting("Top250MTime", str(remote_mtime))
        log("Top 250: File updated")
    except Exception as e:
        logError("Top250", "Exception: %s" % str(e))