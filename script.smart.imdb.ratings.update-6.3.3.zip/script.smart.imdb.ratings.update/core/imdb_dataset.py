# -*- coding: utf-8 -*-

####################################
# Smart IMDb Local Dataset Engine  #
# by rafikW                        #
####################################

import os
import sqlite3
import gzip
import urllib.request

import xbmc
import xbmcvfs
import xbmcaddon
from datetime import datetime, timedelta
from support.common import *

addon = xbmcaddon.Addon()
DATASET_URL = "https://datasets.imdbws.com/title.ratings.tsv.gz"
ADDON_DATA_PATH = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
DB_FOLDER = os.path.join(ADDON_DATA_PATH, "db")
LOGS_FOLDER = os.path.join(ADDON_DATA_PATH, "logs")
DATASET_GZ = os.path.join(DB_FOLDER, "title.ratings.tsv.gz")
DATASET_TSV = os.path.join(DB_FOLDER, "title.ratings.tsv")
DB_FILE = os.path.join(DB_FOLDER, "imdb_ratings.db")
DB_FILE_NEW = os.path.join(DB_FOLDER, "imdb_ratings_new.db")
TIMESTAMP_FILE = os.path.join(DB_FOLDER, "ratings_dataset.timestamp")
TIMESTAMP_HISTORY_FILE = os.path.join(LOGS_FOLDER, "_ratings_dataset.timestamp.history.log")


# ----------------------------------------------------------
# LOG HELPER
# ----------------------------------------------------------
def log(msg):
    logInfo("Dataset", msg)


# ----------------------------------------------------------
# MANUAL DATASET UPDATE HELPERS
# ----------------------------------------------------------
def is_scheduled_update_soon(threshold_minutes=10):
    try:
        scheduled_date = addonSettings.getSetting("ScheduledRunDate")
        scheduled_time = addonSettings.getSetting("DayTime")
        if not scheduled_date or scheduled_date == "2000-01-01":
            return False
        if scheduled_time and len(scheduled_time) == 5:
            scheduled_time += ":00"
        scheduled_dt = datetime.strptime(scheduled_date + " " + scheduled_time, "%Y-%m-%d %H:%M:%S")
        now = datetime.now()
        delta = (scheduled_dt - now).total_seconds()
        if 0 <= delta <= threshold_minutes * 60:
            log("Scheduled update is within threshold")
            return True
    except Exception as e:
        logError("Dataset","Schedule check failed: %s" % str(e))
    return False


def is_dataset_up_to_date():
    try:
        req = urllib.request.Request(DATASET_URL, method="HEAD")
        with urllib.request.urlopen(req, timeout=30) as response:
            remote_time = response.headers.get("Last-Modified")
    except:
        return False, "HEAD request failed"
    if not remote_time:
        return False, "No timestamp"
    if os.path.exists(TIMESTAMP_FILE):
        with open(TIMESTAMP_FILE, "r") as f:
            local_time = f.read().strip()
    else:
        return False, "No local timestamp"
    if local_time == remote_time and os.path.exists(DB_FILE):
        return True, "Dataset already up to date"
    return False, "Update required"


def get_timestamp_file_path():
    import xbmc, os
    db_folder = xbmc.translatePath(addonSettings.getAddonInfo("profile")) + "/db/"
    return os.path.join(db_folder, "ratings_dataset.timestamp")

# ----------------------------------------------------------
# ENSURE LOGS DIRECTORY
# ----------------------------------------------------------
def ensure_logs_folder():
    if not xbmcvfs.exists(LOGS_FOLDER):
        xbmcvfs.mkdirs(LOGS_FOLDER)


# ----------------------------------------------------------
# DATASET TIMESTAMP HISTORY
# ----------------------------------------------------------
def append_timestamp_history(remote_time):
    ensure_logs_folder()
    try:
        remote_dt = datetime.strptime(remote_time, "%a, %d %b %Y %H:%M:%S %Z")
        history_line = "%s|%s" % (remote_dt.strftime("%Y-%m-%d"), remote_time)
        # ---------------------------------
        # DUPLICATE PROTECTION
        # ---------------------------------
        if os.path.exists(TIMESTAMP_HISTORY_FILE):
            try:
                with open(TIMESTAMP_HISTORY_FILE, "r") as f:
                    lines = [line.strip() for line in f if line.strip()]
                if lines and lines[-1] == history_line:
                    log("Dataset timestamp history already contains latest entry")
                    return
            except:
                pass
        with open(TIMESTAMP_HISTORY_FILE, "a") as f:
            f.write(history_line + "\n")
        log("Dataset timestamp added to history: %s" % remote_time)
    except Exception as e:
        logError("Dataset", "Failed to update timestamp history: %s" % str(e))


def append_dataset_missing_history():
    ensure_logs_folder()
    max_window = int(addonSettings.getSetting("RetryWindow") or 180)
    start_dt = datetime.strptime(addonSettings.getSetting("DayTime"), "%H:%M")
    end_dt = start_dt + timedelta(minutes=max_window)
    window = "%s-%s" % (start_dt.strftime("%H:%M"), end_dt.strftime("%H:%M"))
    try:
        no_dataset = (
            "No new IMDb dataset detected within the monitoring window "
            "(%s). Ratings update skipped. IMDb may have released the "
            "dataset later than your configured monitoring period or "
            "not published a new dataset that day."
        ) % window
        history_line = "%s|%s" % (datetime.now().strftime("%Y-%m-%d"), no_dataset)
        if os.path.exists(TIMESTAMP_HISTORY_FILE):
            try:
                with open(TIMESTAMP_HISTORY_FILE, "r") as f:
                    lines = [line.strip() for line in f if line.strip()]
                if lines and lines[-1] == history_line:
                    return
            except:
                pass
        with open(TIMESTAMP_HISTORY_FILE, "a") as f:
            f.write(history_line + "\n")
        log("Dataset missing entry added to history")
    except Exception as e:
        logError("Dataset","Failed to update timestamp history: %s" % str(e))


# ----------------------------------------------------------
# ENSURE DB DIRECTORY
# ----------------------------------------------------------
def ensure_db_folder():
    if not xbmcvfs.exists(DB_FOLDER):
        xbmcvfs.mkdirs(DB_FOLDER)


def check_dataset_update():
    if addonSettings.getSetting("Top250Support") == "true":
        from core.top250 import update_if_needed
        update_if_needed(addonSettings, DB_FOLDER, log)
    ensure_db_folder()
    log("Checking IMDb dataset timestamp")
    # -------------------------------
    # FETCH REMOTE TIMESTAMP
    # -------------------------------
    try:
        req = urllib.request.Request(DATASET_URL, method="HEAD")
        with urllib.request.urlopen(req, timeout=30) as response:
            remote_time = response.headers.get("Last-Modified")
    except Exception as e:
        logError("Dataset","Dataset HEAD check failed: %s" % str(e))
        return "not_available"
    if not remote_time:
        log("Dataset timestamp not found")
        return "not_available"
    # -------------------------------
    # PARSE REMOTE DATE (UTC!)
    # -------------------------------
    try:
        remote_dt = datetime.strptime(remote_time, "%a, %d %b %Y %H:%M:%S %Z")
        dataset_date = remote_dt.date()
    except Exception as e:
        logError("Dataset","Failed to parse remote timestamp: %s" % str(e))
        return "not_available"
    today_utc = datetime.utcnow().date()
    log("Remote timestamp: %s | Parsed date: %s | UTC today: %s" % (remote_time, dataset_date, today_utc))
    # -------------------------------
    # CHECK IF TODAY'S DATASET EXISTS
    # -------------------------------
    if dataset_date < today_utc:
        return "not_available"
    # -------------------------------
    # CHECK LOCAL VERSION
    # -------------------------------
    local_time = None
    if os.path.exists(TIMESTAMP_FILE):
        with open(TIMESTAMP_FILE, "r") as f:
            local_time = f.read().strip()
    if local_time == remote_time and os.path.exists(DB_FILE):
        return "up_to_date"
    # -------------------------------
    # NEW DATASET AVAILABLE
    # -------------------------------
    log("New dataset detected")
    download_dataset()
    extract_dataset()
    build_sqlite_db()
    with open(TIMESTAMP_FILE, "w") as f:
        f.write(remote_time)
    append_timestamp_history(remote_time)
    cleanup_temp_files()
    log("Dataset update completed")
    return "updated"


# ----------------------------------------------------------
# DOWNLOAD DATASET
# ----------------------------------------------------------
def download_dataset():
    log("Downloading IMDb ratings dataset")
    try:
        urllib.request.urlretrieve(DATASET_URL, DATASET_GZ)
    except Exception as e:
        logError("Dataset","Dataset gz file download failed: %s" % str(e))
        return
    log("Dataset gz file download finished")


# ----------------------------------------------------------
# EXTRACT DATASET
# ----------------------------------------------------------
def extract_dataset():
    log("Extracting dataset")
    try:
        with gzip.open(DATASET_GZ, "rb") as gz:
            with open(DATASET_TSV, "wb") as out:
                out.write(gz.read())
    except Exception as e:
        logError("Dataset","Dataset extraction failed: %s" % str(e))
        return
    log("Dataset extraction finished")


# ----------------------------------------------------------
# BUILD SQLITE DATABASE
# ----------------------------------------------------------
def build_sqlite_db():
    log("Building SQLite database")
    if os.path.exists(DB_FILE_NEW):
        os.remove(DB_FILE_NEW)
    conn = sqlite3.connect(DB_FILE_NEW)
    cur = conn.cursor()
    # Performance pragmas
    cur.execute("PRAGMA synchronous = OFF")
    cur.execute("PRAGMA journal_mode = MEMORY")
    cur.execute("PRAGMA temp_store = MEMORY")
    # Optimized schema
    cur.execute("""
        CREATE TABLE ratings (
            imdb_id TEXT PRIMARY KEY,
            rating REAL,
            votes INTEGER
        ) WITHOUT ROWID
    """)
    conn.commit()
    batch = []
    count = 0
    with open(DATASET_TSV, "r", encoding="utf-8") as f:
        next(f)
        for line in f:
            parts = line.strip().split("\t")
            if len(parts) != 3:
                continue
            imdb_id = parts[0]
            rating = float(parts[1])
            votes = int(parts[2])
            batch.append((imdb_id, rating, votes))
            if len(batch) >= 10000:
                cur.executemany("INSERT INTO ratings VALUES (?, ?, ?)", batch)
                batch = []
            count += 1
            if count % 600000 == 0:
                log("Processed %d rows" % count)
    if batch:
        cur.executemany("INSERT INTO ratings VALUES (?, ?, ?)", batch)
    conn.commit()
    cur.execute("PRAGMA optimize")
    conn.commit()
    conn.close()
    # Replace when db is created
    if os.path.exists(DB_FILE):
        os.remove(DB_FILE)
    os.rename(DB_FILE_NEW, DB_FILE)
    log("SQLite DB build finished (%d rows)" % count)


# ----------------------------------------------------------
# CLEANUP TEMP FILES
# ----------------------------------------------------------
def cleanup_temp_files():
    try:
        if os.path.exists(DATASET_GZ):
            os.remove(DATASET_GZ)
        if os.path.exists(DATASET_TSV):
            os.remove(DATASET_TSV)
    except Exception as e:
        logError("Dataset","Cleanup failed: %s" % str(e))

# ----------------------------------------------------------
# LOCAL RATING LOOKUP
# ----------------------------------------------------------
def get_local_rating(imdb_id):
    if not os.path.exists(DB_FILE):
        return (None, None)
    try:
        conn = sqlite3.connect(DB_FILE)
        cur = conn.cursor()
        cur.execute("SELECT rating, votes FROM ratings WHERE imdb_id=?", (imdb_id,))
        row = cur.fetchone()
        conn.close()
        if row:
            return (row[0], row[1])
    except Exception as e:
        logError("Dataset","SQLite lookup failed: %s" % str(e))
    return (None, None)