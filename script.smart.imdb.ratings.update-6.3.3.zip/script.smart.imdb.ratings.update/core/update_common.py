# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc
import sys, re
from datetime import datetime, timedelta

if sys.version_info[0] >= 3:
    import json as jSon
else:
    import simplejson as jSon

from support.common import *
#from core.imdb_scraper import parse_IMDb_episodes_page <--- OBSOLETE
from core.tmdb_api import get_IMDb_ID_from_TMDb



def doUpdateEpisodesBySeason(tvshowid, IMDb, season, progress, percentage, flock, source_override=None):
    from core.update_main import thread_parse_IMDb_page
    from _thread import allocate_lock
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
            '"params":{"tvshowid":%d,'
            '"season":%d,'
            '"properties":["uniqueid","episode","season","showtitle"],'
            '"sort":{"method":"episode"}},'
            '"id":1}'
        ) % (tvshowid, season)

        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        episodes = jSonResponse.get("result", {}).get("episodes", [])
        total = len(episodes)
        count = 0
        lock = allocate_lock()
        for item in episodes:
            episodeid = item.get("episodeid")
            season_num = item.get("season")
            episode_num = "%02d" % item.get("episode")
            title = (
                item.get("showtitle")
                + " "
                + str(season_num)
                + "x"
                + episode_num
            )
            unique_id = item.get("uniqueid", {})
            IMDb = unique_id.get("imdb")
            TVDB = unique_id.get("tvdb")
            TMDB = unique_id.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(
                IMDb,
                TVDB,
                TMDB
            )
            count += 1
            current_percentage = int(
                (count / float(total)) * 100
            ) if total > 0 else 100
            if ShowProgress == "true":
                progress.update(
                    current_percentage,
                    get_progress_title(source_override),
                    "%s (%d/%d)"
                    % (title, count, total)
                )
            thread_parse_IMDb_page(
                "episode",
                episodeid,
                IMDb,
                TVDB,
                TMDB,
                title,
                season_num,
                tvshowid,
                progress,
                current_percentage,
                lock,
                flock,
                source_override
            )
    except Exception as e:
        logError("Season", "Season update exception: %s" % str(e))
    return


def get_tvshow_IMDb_ID(updateitem, tvshowid, TVDB, TMDB, Title):
    IMDb = None
    if updateitem != "tvshow":
        TVDB = None; TMDB = None
        jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"properties":["uniqueid","title"]},"id":1}'
        jSonResponse = xbmc.executeJSONRPC( jSonQuery )
        jSonResponse = jSon.loads( jSonResponse )
        item = jSonResponse['result']['tvshowdetails']
        Title = item.get('title')
        unique_id = item.get('uniqueid')
        if unique_id != None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
    sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
    statusInfo = "Method get_tvshow_IMDb_ID - " + Title + " (IMDb ID: " + sIMDb + ", TVDB ID: " + sTVDB + ", TMDB ID: "+ sTMDB + ")"
    if IMDb == None:
        (IMDb, add_statusInfo) = get_IMDb_ID_from_TMDb("tvshow", TMDB)
        statusInfo = statusInfo + "\n" + add_statusInfo
        if IMDb == None:
            return(None, statusInfo)
        else:
            jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str( tvshowid ) + ',"uniqueid": {"imdb": "' + IMDb + '"}},"id":1}'
            jSonResponse = xbmc.executeJSONRPC( jSonQuery )
    return (IMDb, "OK")


def printable_IDs(imdb, tvdb, tmdb):
    if imdb == None: imdb = addonLanguage(32528)
    if tvdb == None: tvdb = addonLanguage(32528)
    if tmdb == None: tmdb = addonLanguage(32528)
    return imdb, tvdb, tmdb


def normalize_IDs(imdb, tvdb, tmdb):
    if imdb == "": imdb = None
    if tvdb == "": tvdb = None
    if tmdb == "": tmdb = None
    return imdb, tvdb, tmdb