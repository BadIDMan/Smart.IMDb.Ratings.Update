# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################


import xbmc, xbmcaddon, xbmcgui
import json
import requests
import uuid
from support.common import *

addonSettings = xbmcaddon.Addon()

TVDB_APIKEY = "edae60dc-1b44-4bac-8db7-65c0aaf5258b"
TVDB_LOGIN_URL = "https://api4.thetvdb.com/v4/login"
TVDB_SERIES_URL = "https://api4.thetvdb.com/v4/series/%s/extended"


def log(msg):
    logInfo("TVDBAPI", msg)


# ==============================================================================================
# HELPERS - GET BANNER FOR NEWLY ADDED TV SHOW / (ALSO AVAILABLE IN THE CONTEXT MENU ON TV SHOW)
# ==============================================================================================
def TVDBLogin():
    if not addonSettings.getSetting("TVDB_UUID"):
        addonSettings.setSetting("TVDB_UUID", str(uuid.uuid4()))
    payload = {"apikey": TVDB_APIKEY, "gender": "Other", "birthYear": 1900, "uuid": addonSettings.getSetting("TVDB_UUID")}
    headers = {"User-Agent": "TheTVDB v.4 TV Scraper for Kodi", "Accept": "application/json"}
    response = requests.post(TVDB_LOGIN_URL, json=payload, headers=headers, timeout=30)
    response.raise_for_status()
    return response.json()["data"]["token"]

def GetTVDBSeries(tvdbid):
    token = TVDBLogin()
    headers = {"User-Agent": "TheTVDB v.4 TV Scraper for Kodi", "Accept": "application/json", "Authorization": "Bearer %s" % token}
    response = requests.get(TVDB_SERIES_URL % tvdbid, headers=headers, timeout=30)
    response.raise_for_status()
    return response.json()["data"]

def GetTVDBBanner(tvdbid):
    show = GetTVDBSeries(tvdbid)
    artworks = show.get("artworks", [])
    banners = []
    for art in artworks:
        if art.get("type") == 1:
            banners.append(art)
    if not banners:
        return None
    banners.sort(key=lambda x: x.get("score", 0), reverse=True)
    return banners[0]["image"]

def UpdateMissingBanner(tvshowid, tvdbid, title):
    try:
        if not tvdbid:
            log("Banner update skipped for '%s' - no TVDB ID" % title)
            return
        # ---------------------------------------------------------
        # GET CURRENT ARTWORK
        # ---------------------------------------------------------
        query = {
            "jsonrpc": "2.0",
            "method": "VideoLibrary.GetTVShowDetails",
            "params": {
                "tvshowid": tvshowid,
                "properties": ["art"]
            },
            "id": 1
        }
        result = json.loads(xbmc.executeJSONRPC(json.dumps(query)))
        art = (result.get("result", {}).get("tvshowdetails", {}).get("art", {}))
        if art.get("banner"):
            log("Banner already exists for '%s'" % title)
            return
        # ---------------------------------------------------------
        # FETCH BANNER FROM TVDB
        # ---------------------------------------------------------
        banner_url = GetTVDBBanner(tvdbid)
        if not banner_url:
            log("No TVDB banner found for '%s'" % title)
            return
        log("Adding TVDB banner for '%s': %s" % (title, banner_url))
        # ---------------------------------------------------------
        # UPDATE KODI LIBRARY
        # ---------------------------------------------------------
        query = {
            "jsonrpc": "2.0",
            "method": "VideoLibrary.SetTVShowDetails",
            "params": {
                "tvshowid": tvshowid,
                "art": {
                    "banner": banner_url
                }
            },
            "id": 1
        }
        result = xbmc.executeJSONRPC(json.dumps(query))
    except Exception as e:
        logError("TVDBAPI", "Banner update failed for '%s': %s" % (title, str(e)))

# ====================================================================================================================
# HELPERS - LET'S TRY TO RESOLVE IMDb ID from TVDB, because in TMDb sometimes there is no relationship TMDb -> IMDb ID
# ====================================================================================================================
def GetTVDBEpisode(tvdbid):
    token = TVDBLogin()
    headers = {"User-Agent": "TheTVDB v.4 TV Scraper for Kodi", "Accept": "application/json", "Authorization": "Bearer %s" % token}
    response = requests.get("https://api4.thetvdb.com/v4/episodes/%s/extended" % tvdbid, headers=headers, timeout=30)
    response.raise_for_status()
    return response.json()["data"]

def GetTVDBEpisodeIMDbID(tvdbid):
    try:
        episode = GetTVDBEpisode(tvdbid)
        for remote_id in episode.get("remoteIds", []):
            source_name = remote_id.get("sourceName", "")
            if source_name.upper() == "IMDB":
                imdb_id = remote_id.get("id")
                if imdb_id:
                    return imdb_id
        return None
    except Exception as e:
        logError("TVDBAPI","GetTVDBEpisodeIMDbID failed for TVDB %s: %s" % (tvdbid, str(e)))
        return None
