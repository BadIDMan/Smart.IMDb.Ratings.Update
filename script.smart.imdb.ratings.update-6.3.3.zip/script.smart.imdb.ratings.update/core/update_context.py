# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc, xbmcgui
import sys, re
import math
import os


from datetime import datetime
if sys.version_info[0] >= 3:
    import json as jSon
else:
    import simplejson as jSon
from support.common import *
from core.update_common import *
from support.httptools import wait_for_internet
from core.update_main import TVShows
from core.imdb_scraper import parse_IMDb_page
from core.tmdb_api import get_TMDB_rating
from core.imdb_dataset import get_local_rating
from core.imdb_dataset import get_timestamp_file_path
from core.tvdb_api import UpdateMissingBanner



def open_context_menu(filename, label):
    lower_filename = filename.lower()
    if not lower_filename.startswith("videodb://"):
        xbmcgui.Dialog().notification(addonName,"Unsupported item (non-library item)",xbmcgui.NOTIFICATION_INFO,4000)
        return
    if re.search(r"videodb://movies/sets/\d+/\?setid=\d+", lower_filename):
        from core import update_context_ms
        update_context_ms.open_context_menu(filename, label)
        return
    updateitem = ""
    movieid = -1
    episodeid = -1
    tvshowid = -1
    rating = -1
    votes = -1
    top250 = 0
    Title = ""
    IMDb = None
    TVDB = None
    TMDB = None
    season = -1
    episode = ""
    jSonQuery = None
    filename = filename.replace("/", " ")
    id_parts = re.findall(r"[+-]?\d+(?:\.\d+)?", filename)
    tag = 0
    if (
        "genreid" in filename or
        "year" in filename or
        "actorid" in filename or
        "directorid" in filename or
        "studioid" in filename or
        "setid" in filename or
        "countryid" in filename or
        "tagid" in filename or
        "videoversions" in filename
    ):
        tag = 1
    try:
        if "movies" in filename or "recentlyaddedmovies" in filename:
            updateitem = "movie"
            movieid = int(id_parts[0 + tag])
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails",'
                '"params":{"movieid":' + str(movieid) +
                ',"properties":["uniqueid","ratings","top250","title"]},"id":1}'
            )
        elif (
            ("tvshows" in filename or "inprogresstvshows" in filename)
            and "season" in filename
            and "tvshowid" in filename
        ):
            updateitem = "episode"
            episodeid = int(id_parts[2 + tag])
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails",'
                '"params":{"episodeid":' + str(episodeid) +
                ',"properties":["uniqueid","ratings","episode","season","showtitle","tvshowid"]},"id":1}'
            )
        elif (
            ("tvshows" in filename or "inprogresstvshows" in filename)
            and "tvshowid" in filename
        ):
            season = int(id_parts[1 + tag])
            if season == -1 and not label.startswith("* "):
                updateitem = "episode"
                episodeid = int(id_parts[2 + tag])
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails",'
                    '"params":{"episodeid":' + str(episodeid) +
                    ',"properties":["uniqueid","ratings","episode","season","showtitle","tvshowid"]},"id":1}'
                )
            else:
                updateitem = "season"
                tvshowid = int(id_parts[0 + tag])
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                    '"params":{"tvshowid":' + str(tvshowid) +
                    ',"properties":["uniqueid","ratings","title"]},"id":1}'
                )
        elif ("tvshows" in filename or "inprogresstvshows" in filename):
            tvshowid = int(id_parts[0 + tag])
            if tvshowid == -1:
                updateitem = "episode"
                episodeid = int(id_parts[2])
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails",'
                    '"params":{"episodeid":' + str(episodeid) +
                    ',"properties":["uniqueid","ratings","episode","season","showtitle","tvshowid"]},"id":1}'
                )
            else:
                updateitem = "tvshow"
                jSonQuery = (
                    '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                    '"params":{"tvshowid":' + str(tvshowid) +
                    ',"properties":["uniqueid","ratings","title"]},"id":1}'
                )
        elif "recentlyaddedepisodes" in filename:
            updateitem = "episode"
            episodeid = int(id_parts[0])
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails",'
                '"params":{"episodeid":' + str(episodeid) +
                ',"properties":["uniqueid","ratings","episode","season","showtitle","tvshowid"]},"id":1}'
            )
    except Exception as e:
        logError("Context", "Exception: %s" % str(e))
        xbmcgui.Dialog().notification(addonName,"Unsupported item",xbmcgui.NOTIFICATION_INFO,3000)
        return
    if not jSonQuery:
        xbmcgui.Dialog().notification(addonName,"Unsupported item",xbmcgui.NOTIFICATION_INFO,3000)
        return
    jSonResponse = xbmc.executeJSONRPC(jSonQuery)
    jSonResponse = jSon.loads(jSonResponse)
    if 'moviedetails' in jSonResponse['result']:
        item = jSonResponse['result']['moviedetails']
        unique_id = item.get('uniqueid')
        if unique_id != None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
        Title = item.get('title')
        ratings = item.get('ratings')
        top250 = item.get('top250')
        imdb_rating = ratings.get('imdb')
        if imdb_rating != None:
            rating = imdb_rating.get('rating')
            votes = imdb_rating.get('votes')
    elif 'episodedetails' in jSonResponse['result']:
        item = jSonResponse['result']['episodedetails']
        unique_id = item.get('uniqueid')
        if unique_id != None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
        tvshowid = item.get('tvshowid')
        season = item.get('season')
        episode = "%02d" % item.get('episode')
        Title = item.get('showtitle') + " " + str(season) + "x" + str(episode)
        ratings = item.get('ratings')
        imdb_rating = ratings.get('imdb')
        if imdb_rating != None:
            rating = imdb_rating.get('rating')
            votes = imdb_rating.get('votes')
    elif 'tvshowdetails' in jSonResponse['result']:
        item = jSonResponse['result']['tvshowdetails']
        unique_id = item.get('uniqueid')
        if unique_id != None:
            IMDb = unique_id.get('imdb')
            TVDB = unique_id.get('tvdb')
            TMDB = unique_id.get('tmdb')
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
        Title = item.get('title')
        ratings = item.get('ratings')
        imdb_rating = ratings.get('imdb')
        if imdb_rating != None:
            rating = imdb_rating.get('rating')
            votes = imdb_rating.get('votes')
    context_menu_options(updateitem,movieid,episodeid,tvshowid,season,episode,IMDb,TVDB,TMDB,Title,rating,votes,top250)



def context_menu_options(updateitem, movieid, episodeid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title, rating, votes, top250):
    option = -1
    while True:
        id_label = ""
        sIMDb, sTVDB, sTMDB = printable_IDs(IMDb, TVDB, TMDB)
        stringList = []
        stringList += [ "[COLOR red]Update rating[/COLOR] [COLOR lightgreen](IMDbAPI.dev)[/COLOR]" ]
        stringList += [ "[COLOR red]Update rating[/COLOR] [COLOR lightgreen](local dataset)[/COLOR]" ]
        stringList += [ "[COLOR red]Update rating[/COLOR] [COLOR lightgreen](IMDb HTML)[/COLOR]" ]
        dataset_label = "[COLOR orange]Update local dataset now[/COLOR]"
        try:
            timestamp_file = get_timestamp_file_path()
            if os.path.exists(timestamp_file):
                with open(timestamp_file, "r") as f:
                    ts = f.read().strip()
                if ts:
                    try:
                        dt = datetime.strptime(ts, "%a, %d %b %Y %H:%M:%S %Z")
                        formatted = dt.strftime("%Y-%m-%d %H:%M")
                    except:
                        formatted = ts
                    dataset_label = "[COLOR orange]Update local dataset now[/COLOR] [COLOR gray](timestamp: %s)[/COLOR]" % formatted
        except Exception as e:
            logError("Context", "Failed to read dataset timestamp: %s" % str(e))
        stringList += [ dataset_label ]
        if updateitem != "season":
            if rating != -1:
                rating = round(rating, 2)
                stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(
                    addonLanguage(32263) + ": ",
                    str(rating) + " (" + '{0:,}'.format(votes) + " " + addonLanguage(32264) + ")"
                ) ]
            else:
                stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(
                    addonLanguage(32263) + ": ",
                    addonLanguage(32528)
                ) ]
        if updateitem == "movie":
            if top250 != 0:
                stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(
                    addonLanguage(32265) + ": ",
                    str(top250)
                ) ]
            else:
                stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format(
                    addonLanguage(32265) + ": ",
                    addonLanguage(32528)
                ) ]
        elif updateitem != "season":
            stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("TVDB ID: ", sTVDB) ]
        if updateitem != "season":
            stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("TMDB ID: ", sTMDB) ]
            stringList += [ "[COLOR skyblue]{0}[/COLOR][COLOR white]{1}[/COLOR]".format("IMDb ID: ", sIMDb) ]
        # Show banner update option
        banner_option = -1
        if updateitem == "tvshow" and addonSettings.getSetting("FetchBanner") == "true":
            banner_option = len(stringList)
            stringList += [ "[COLOR deepskyblue]Refresh TV Show banner[/COLOR]" ]
        # Show last 20 lines of logs
        timestamp_option = len(stringList)
        stringList += [ "[COLOR yellow]Show dataset timestamp log file[/COLOR]" ]
        log_option = len(stringList)
        stringList += [ "[COLOR yellow]Show last 20 lines of the log file[/COLOR]" ]
        if updateitem == "movie":
            title = addonName + " (Movie)"
        elif updateitem == "tvshow":
            title = addonName + " (TV Show)"
        elif updateitem == "episode":
            title = addonName + " (Episode)"
        elif updateitem == "season":
            title = addonName + " (Season)"
        else:
            title = addonName
        option = xbmcgui.Dialog().select(title, stringList)
        if option == -1:
            return
        elif option in (0,1,2):
            if option == 0:
                source_override = "api"
            elif option == 1:
                source_override = "dataset"
            else:
                source_override = "html"
            # dataset presence guard
            if source_override == "dataset":
                import xbmcvfs
                db_path = xbmc.translatePath(addonSettings.getAddonInfo("profile")) + "/db/imdb_ratings.db"
                if not xbmcvfs.exists(db_path):
                    xbmcgui.Dialog().ok(addonName, "Local dataset not found.\n\nRun scheduled update using 'Local copy of IMDb Ratings dataset' \nor run 'Update local dataset now'")
                    continue
            _rating, _votes, _top250, _IMDb = doUpdateItem(
                updateitem,
                movieid,
                episodeid,
                tvshowid,
                season,
                episode,
                IMDb,
                TVDB,
                TMDB,
                Title,
                source_override
            )
            if not (_rating == -1 and _votes == -1 and _top250 == -1):
                rating = _rating
                votes = int(_votes)
                top250 = _top250
            if _IMDb != None:
                IMDb = _IMDb
            if updateitem == "season":
                return
            else:
                continue
        # -------------------------------------------------
        # UPDATE LOCAL DATASET NOW
        # -------------------------------------------------
        elif option == 3:
            try:
                logInfo("Context", "Manual dataset update requested")
                # --------------------------------------------
                # BLOCK: update already running
                # --------------------------------------------
                if addonSettings.getSetting("PerformingUpdate") == "true":
                    xbmcgui.Dialog().ok(addonName, "Another update is already running.\n\nPlease wait until it finishes.")
                    continue
                # --------------------------------------------
                # BLOCK: scheduled update soon
                # --------------------------------------------
                from core.imdb_dataset import is_scheduled_update_soon
                if is_scheduled_update_soon(10):
                    xbmcgui.Dialog().ok(addonName, "Scheduled dataset update will run shortly.\n\nManual update blocked to avoid duplication.")
                    continue
                # --------------------------------------------
                # CHECK: already up-to-date
                # --------------------------------------------
                from core.imdb_dataset import is_dataset_up_to_date
                up_to_date, msg = is_dataset_up_to_date()
                if up_to_date:
                    xbmcgui.Dialog().ok(addonName, "Dataset is already up to date.\n\nNo download needed.")
                    continue
                # --------------------------------------------
                # CONFIRMATION
                # --------------------------------------------
                confirm = xbmcgui.Dialog().yesno(
                    addonName,
                    "This will download and rebuild the local IMDb dataset.\n"
                    "It may take 2–3 minutes.\n\nContinue?"
                )
                if not confirm:
                    continue
                # --------------------------------------------
                # RUN UPDATE
                # --------------------------------------------
                addonSettings.setSetting("PerformingUpdate", "true")
                progress = xbmcgui.DialogProgressBG()
                progress.create("IMDb Dataset", "Updating local dataset...")
                logInfo("Context", "Starting dataset update")
                from core.imdb_dataset import check_dataset_update
                check_dataset_update()
                progress.close()
                addonSettings.setSetting("PerformingUpdate", "false")
                xbmcgui.Dialog().ok(addonName, "Local dataset update completed.")
            except Exception as e:
                addonSettings.setSetting("PerformingUpdate", "false")
                logError("Context", "Dataset update failed: %s" % str(e))
                xbmcgui.Dialog().ok(addonName, "Dataset update failed.")
            continue
        elif option == banner_option and addonSettings.getSetting("FetchBanner") == "true":
            try:
                UpdateMissingBanner(tvshowid, TVDB, Title)
                xbmcgui.Dialog().notification(addonName, "Banner refresh action completed", xbmcgui.NOTIFICATION_INFO, 4000)
            except Exception as e:
                logError("Context", "Banner refresh failed: %s" % str(e))
            continue
        elif option == log_option:
            try:
                import xbmcvfs
                log_file = get_current_log_path()
                if not xbmcvfs.exists(log_file):
                    xbmcgui.Dialog().ok(addonName, "Log file not found.")
                    continue
                with open(log_file, "r", encoding="utf-8") as f:
                    content = f.read()
                lines = content.splitlines()
                last_lines = lines[-20:] if len(lines) >= 20 else lines
                formatted_lines = []
                for line in last_lines:
                    # 1) Remove TVDB and TMDB ID sections
                    line = re.sub(r",\s*(TVDB|TMDB) ID:\s*[^,\)]+", "", line)
                    # 2) Remove "Votes:" label (keep number)
                    line = line.replace("Votes:", "")
                    # 3) Replace --> with ->
                    line = line.replace("-->", "->")
                    # 4) Normalize multiple spaces to single
                    line = re.sub(r"\s+", " ", line)
                    # 5) Cleanup small visual artifacts
                    line = line.replace("( ", "(").replace(" )", ")").strip()
                    formatted_lines.append(line)
                text = "=== Last 20 log lines ===\n\n" + "\n".join(formatted_lines)
                xbmcgui.Dialog().textviewer("Today's Smart IMDb Log", text)
            except Exception as e:
                logError("Context", "Failed to read log: %s" % str(e))
                xbmcgui.Dialog().ok(addonName, "Failed to read log file.")
            continue
        elif option == timestamp_option:
            try:
                import xbmcvfs
                dataset_history_log_file = addonProfile + "/logs/_ratings_dataset.timestamp.history.log"
                if not xbmcvfs.exists(dataset_history_log_file):
                    xbmcgui.Dialog().ok(addonName, "Dataset timestamp log file not found.")
                    continue
                with open(dataset_history_log_file, "r", encoding="utf-8") as f:
                    content = f.read()
                lines = content.splitlines()
                last_lines = lines[-20:] if len(lines) >= 20 else lines
                text = ("=== IMDb Dataset Publication History (last 20 entries) ===\n\n" + "\n".join(last_lines))
                xbmcgui.Dialog().textviewer("IMDb Dataset Timestamp History", text)
            except Exception as e:
                logError("Context", "Failed to read log: %s" % str(e))
                xbmcgui.Dialog().ok(addonName, "Failed to read log file.")
            continue
        elif option == 4:
            continue
        elif option == 5 and updateitem == "movie":
            continue
        elif option == 5:
            id = xbmcgui.Dialog().input("TVDB ID", sTVDB)
            if id:
                TVDB = id
                id_label = "tvdb"
        elif option == 6:
            id = xbmcgui.Dialog().input("TMDB ID", sTMDB)
            if id:
                TMDB = id
                id_label = "tmdb"
        elif option == 7:
            id = xbmcgui.Dialog().input("IMDb ID", sIMDb)
            if id:
                IMDb = id
                id_label = "imdb"
        if id_label:
            if updateitem == "movie":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetMovieDetails","params":{"movieid":' + str(movieid) + ',"uniqueid": {"' + id_label + '": "' + id + '"}},"id":1}'
            elif updateitem == "tvshow":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetTVShowDetails","params":{"tvshowid":' + str(tvshowid) + ',"uniqueid": {"' + id_label + '": "' + id + '"}},"id":1}'
            elif updateitem == "episode":
                jSonQuery = '{"jsonrpc":"2.0","method":"VideoLibrary.SetEpisodeDetails","params":{"episodeid":' + str(episodeid) + ',"uniqueid": {"' + id_label + '": "' + id + '"}},"id":1}'
            xbmc.executeJSONRPC(jSonQuery)


def doUpdateItem(updateitem, movieid, episodeid, tvshowid, season, episode, IMDb, TVDB, TMDB, Title, source_override=None):
    from core.update_main import thread_parse_IMDb_page
    from _thread import allocate_lock
    if not wait_for_internet(wait=0, retry=1):
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32257))
        return -1, -1, -1, None
    if addonSettings.getSetting("PerformingUpdate") == "true":
        xbmcgui.Dialog().ok("%s" % (addonName), addonLanguage(32251))
        return -1, -1, -1, None
    addonSettings.setSetting("PerformingUpdate", "true")
    progress = xbmcgui.DialogProgressBG()
    progress.create(get_progress_title(source_override), Title)
    lock = allocate_lock()
    flock = allocate_lock()
    updateitem_id = None
    if updateitem == "movie":
        statusLog("[Context] Rating update on movie, source: " + source_override)
        updateitem_id = movieid
    elif updateitem == "tvshow":
        statusLog("[Context] Rating update on TV show, source: " + source_override)
        updateitem_id = tvshowid
    elif updateitem == "episode":
        statusLog("[Context] Rating update on episode, source: " + source_override)
        updateitem_id = episodeid
    elif updateitem == "season":
        statusLog("[Context] Rating update on Season in TV Show '%s', source: %s" % (Title, source_override))
        updateitem_id = tvshowid
    # Direct call to the SAME engine used by scheduled update
    thread_parse_IMDb_page(
        updateitem,
        updateitem_id,
        IMDb,
        TVDB,
        TMDB,
        Title,
        season,
        tvshowid,
        progress,
        100,
        lock,
        flock,
        source_override
    )
    # Context menu: TV Shows -> also update all episodes
    if updateitem == "tvshow":
        try:
            statusLog("[Context] Updating ratings on all episodes for TV show: '" + Title + "'")
            jSonQuery = (
                '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes","params":{'
                '"tvshowid":%d,'
                '"properties":["uniqueid","episode","season","showtitle"]'
                '},"id":1}'
            ) % tvshowid
            response = jSon.loads(xbmc.executeJSONRPC(jSonQuery))
            episodes = response.get("result", {}).get("episodes", [])
            total = len(episodes)
            count = 0
            for item in episodes:
                episodeid = item.get("episodeid")
                season = item.get("season")
                episode = "%02d" % item.get("episode")
                title = item.get("showtitle") + " " + str(season) + "x" + episode
                unique_id = item.get("uniqueid", {})
                IMDb = unique_id.get("imdb")
                TVDB = unique_id.get("tvdb")
                TMDB = unique_id.get("tmdb")
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                count += 1
                percentage = int((count / float(total)) * 100)
                progress.update(percentage, get_progress_title(source_override), "%s (%d/%d)" % (title, count, total))
                thread_parse_IMDb_page(
                    "episode",
                    episodeid,
                    IMDb,
                    TVDB,
                    TMDB,
                    title,
                    season,
                    tvshowid,
                    progress,
                    percentage,
                    lock,
                    flock,
                    source_override
                )
        except Exception as e:
            logError("Context", "Episode update failed: %s" % str(e))
    progress.update(100, get_progress_title(source_override), Title)
    xbmc.sleep(500)
    progress.close()
    addonSettings.setSetting("PerformingUpdate", "false")
    try:
        if updateitem == "movie":
            query = '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovieDetails","params":{"movieid":%d,"properties":["ratings","top250","uniqueid"]},"id":1}' % movieid
        elif updateitem == "tvshow":
            query = '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails","params":{"tvshowid":%d,"properties":["ratings","uniqueid"]},"id":1}' % tvshowid
        elif updateitem == "episode":
            query = '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodeDetails","params":{"episodeid":%d,"properties":["ratings","uniqueid"]},"id":1}' % episodeid
        else:
            return -1, -1, -1, None
        response = jSon.loads(xbmc.executeJSONRPC(query))
        details = list(response["result"].values())[0]
        ratings = details.get("ratings", {})
        imdb_rating = ratings.get("imdb")
        if imdb_rating:
            rating = imdb_rating.get("rating")
            votes = imdb_rating.get("votes")
        else:
            rating = -1
            votes = -1
        unique_id = details.get("uniqueid", {})
        IMDb = unique_id.get("imdb")
        top250 = details.get("top250", 0)
        return rating, votes, top250, IMDb
    except:
        return -1, -1, -1, None