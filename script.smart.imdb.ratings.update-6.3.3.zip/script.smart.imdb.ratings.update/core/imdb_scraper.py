# -*- coding: utf-8 -*-

##############################
# Smart IMDb Ratings Update  #
# by rafikW                  #
############################ #

import re
import xbmc
import time
import random
from _thread import allocate_lock
from support.common import *
from support.httptools import get_page

base_url = "https://www.imdb.com/title/"
api_lock = allocate_lock()
next_request_time = 0
IMDB_SEASON_CACHE = {}


def imdbapi_rate_limit():
    global next_request_time
    api_lock.acquire()
    try:
        now = time.time()
        if now < next_request_time:
            sleep_time = next_request_time - now
            xbmc.sleep(int(sleep_time * 1000))
        next_request_time = max(now, next_request_time) + getRateLimitThreshold()
        # small jitter prevents thread sync
        xbmc.sleep(int(random.uniform(10, 40)))
    finally:
        api_lock.release()


def parse_IMDb_page(imdb_id):
    # Should not be used since IMDb is WAF protected for API calls but I'm keeping this for reference, maybe one day it will be possible scrap data from IMDb again
    url = base_url + imdb_id + "/"
    do_loop = 1
    while do_loop > 0:
        (html, status, statusInfo) = get_page(url)
        if status == "socket":
            xbmc.sleep(1000 * do_loop)
            do_loop += 1
            if do_loop == 4:
                return (None, None, 0, statusInfo)
        elif status == "HTTP":
            return (None, None, 0, statusInfo)
        else:
            do_loop = 0
    htmlline = html.replace('\n', ' ').replace('\r', '')
    matchVotes = re.findall(r'title=\"(\d\.\d) based on (\d*,?\d*,?\d+) user ratings\"', htmlline)
    if matchVotes:
        rating = matchVotes[0][0]
        votes = matchVotes[0][1]
    else:
        matchVotes = re.findall(r'"ratingCount":(\d*,?\d*,?\d+),"bestRating":\"?\d+\.?\d?\"?,"worstRating":\"?\d+\.?\d?\"?,"ratingValue":\"?(\d+\.?\d?)\"?', htmlline.replace(' ', ''))
        if matchVotes:
            rating = matchVotes[0][1]
            votes = matchVotes[0][0]
        else:
            rating = None
            votes = None
            statusInfo = "No rating found on IMDb (wrong ID or IMDb web page BLOCKED by AMZN WAF 'Web Application Firewall')"
    matchTop250 = re.findall(r'href="/chart/top\?ref_=tt_awd" > Top Rated Movies #(\d+) </a>', htmlline)
    if matchTop250:
        top250 = matchTop250[0]
    else:
        top250 = 0
    return (rating, votes, top250, statusInfo)


# ------------------------------------------------------------------------------
# NEW DATA PROVIDER: imdbapi.dev - LETS USE IT WHEN IMDb IS "DOWN" FOR API CALLS
# ------------------------------------------------------------------------------
def parse_IMDbAPI_page(imdb_id):
    try:
        import json
        import random
        from six.moves.urllib.request import Request, urlopen
        from six.moves.urllib.error import HTTPError, URLError
        url = "https://api.imdbapi.dev/titles/%s" % imdb_id
        # rate limiting protection
        imdbapi_rate_limit()
        # small pre-request jitter (helps reduce bot detection)
        xbmc.sleep(int(random.uniform(50, 150)))
        # build request with proper headers
        req = Request(
            url,
            headers={
                "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64)",
                "Accept": "application/json",
                "Accept-Language": "en-US,en;q=0.9",
                "Connection": "keep-alive",
            }
        )
        response = urlopen(req, timeout=15)
        raw = response.read().decode("utf-8")
        response.close()
        data = json.loads(raw)
        rating_block = data.get("rating")
        if not rating_block:
            return (None, None, 0, "IMDbAPI.dev: rating block missing")
        rating = rating_block.get("aggregateRating")
        votes = rating_block.get("voteCount")
        if rating is None or votes is None:
            return (None, None, 0, "IMDbAPI.dev: rating missing")
        # normalize rating to float with 1 decimal place
        try:
            rating = float(rating)
            rating = round(rating, 1)
        except:
            return (None, None, 0, "IMDbAPI.dev: invalid rating format")
        return (rating, votes, 0, "OK")
    except HTTPError as e:
        if e.code == 403:
            logError("IMDbAPI.dev", "403 Forbidden (Cloudflare) for %s" % imdb_id)
            return (None, None, 0, "IMDbAPI.dev: 403 Forbidden (Cloudflare)")
        else:
            logError("IMDbAPI.dev", "HTTPError for %s: %s" % (imdb_id, str(e)))
            return (None, None, 0, "IMDbAPI.dev HTTP error")
    except URLError as e:
        logError("IMDbAPI.dev", "URLError for %s: %s" % (imdb_id, str(e)))
        return (None, None, 0, "IMDbAPI.dev URL error")
    except Exception as e:
        logError("IMDbAPI.dev", "ERROR for %s: %s" % (imdb_id, str(e)))
        return (None, None, 0, "IMDbAPI.dev error")


def parse_IMDb_episodes_page_OBSOLETE(imdb_show_id, season):
    if DebugLog == "true":
        logDebug("IMDbHTTPEpisode", "=== START parse_IMDb_episodes_page === show=%s season=%s" % (imdb_show_id, season))
    cache_key = "%s_%s" % (imdb_show_id, season)
    # -----------------------------------------------------
    # CACHE CHECK
    # -----------------------------------------------------
    if cache_key in IMDB_SEASON_CACHE:
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "HIT key=%s value=%s" % (cache_key, "EMPTY" if not IMDB_SEASON_CACHE[cache_key] else "FILLED"))
        return IMDB_SEASON_CACHE[cache_key], "CACHE"
    if DebugLog == "true":
        logDebug("IMDbHTTPEpisode", "MISS key=%s" % cache_key)
    url = base_url + imdb_show_id + "/episodes/?season=" + str(season)
    if DebugLog == "true":
        logDebug("IMDbHTTPEpisode", "URL=%s" % url)
    # -----------------------------------------------------
    # FETCH PAGE
    # -----------------------------------------------------
    do_loop = 1
    while do_loop > 0:
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "Attempt #%d" % do_loop)
        (html, status, statusInfo) = get_page(url)
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "status=%s info=%s html_len=%s" % (status, statusInfo, len(html) if html else "None"))
        if status == "socket":
            if DebugLog == "true":
                logDebug("IMDbHTTPEpisode", "SOCKET retry..." % ())
            xbmc.sleep(1000 * do_loop)
            do_loop += 1
            if do_loop == 4:
                if DebugLog == "true":
                    logDebug("IMDbHTTPEpisode", "SOCKET FAILED after retries")
                return (None, statusInfo)
        elif status == "HTTP":
            if DebugLog == "true":
                logDebug("IMDbHTTPEpisode", "HTTP ERROR: %s" % statusInfo)
            return (None, statusInfo)
        else:
            if DebugLog == "true":
                logDebug("IMDbHTTPEpisode", "SUCCESS")
            do_loop = 0
    # -----------------------------------------------------
    # BASIC HTML CHECK
    # -----------------------------------------------------
    if not html:
        logError("IMDbHTTPEpisode", "Parse_IMDb_episodes_page - EMPTY HTML!")
        IMDB_SEASON_CACHE[cache_key] = None
        return (None, "Empty HTML")
    if DebugLog == "true":
        logDebug("IMDbHTTPEpisode", "HTML sample (first 500 chars): %s" % html[:500])
    # -----------------------------------------------------
    # CRITICAL GUARD
    # -----------------------------------------------------
    if "tab-seasons" not in html:
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "NO 'tab-seasons' FOUND -> invalid page structure!")
        IMDB_SEASON_CACHE[cache_key] = None
        return (None, "IMDb show has no episode list")
    if DebugLog == "true":
        logDebug("IMDbHTTPEpisode", "'tab-seasons' FOUND")
    # -----------------------------------------------------
    # NORMALIZE HTML
    # -----------------------------------------------------
    episode_map = {}
    try:
        htmlline = html.replace("\n", " ").replace("\r", "")
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "Normalized HTML length=%d" % len(htmlline))
        # -------------------------------------------------
        # PATTERN 1
        # -------------------------------------------------
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "Searching pattern1...")
        pattern1 = re.findall(
            r'episodeNumber[^>]*>\s*(\d+)\s*<.*?/title/(tt\d+)/',
            htmlline,
            re.IGNORECASE
        )
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "matches=%d" % len(pattern1))
        for ep_num, imdb_id in pattern1:
            ep_num = int(ep_num)
            if ep_num not in episode_map:
                episode_map[ep_num] = imdb_id
                if DebugLog == "true":
                    logDebug("IMDbHTTPEpisode", "ADD ep=%s imdb=%s" % (ep_num, imdb_id))
        # -------------------------------------------------
        # PATTERN 2
        # -------------------------------------------------
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "Searching pattern2 blocks...")
        pattern2_blocks = re.findall(
            r'(<article.*?</article>)',
            htmlline,
            re.IGNORECASE
        )
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "blocks=%d" % len(pattern2_blocks))
        for block in pattern2_blocks:
            id_match = re.search(r'/title/(tt\d+)/', block, re.IGNORECASE)
            ep_match = re.search(r'episodeNumber[^>]*>\s*(\d+)\s*<', block, re.IGNORECASE)
            if id_match and ep_match:
                ep_num = int(ep_match.group(1))
                imdb_id = id_match.group(1)
                if ep_num not in episode_map:
                    episode_map[ep_num] = imdb_id
                    if DebugLog == "true":
                        logDebug("IMDbHTTPEpisode", "ADD ep=%s imdb=%s" % (ep_num, imdb_id))
        # -------------------------------------------------
        # PATTERN 3
        # -------------------------------------------------
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "Searching pattern3 blocks...")
        pattern3_blocks = re.findall(
            r'(<[^>]+data-testid="titleEpisode[^"]*".*?</[^>]+>)',
            htmlline,
            re.IGNORECASE
        )
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "blocks=%d" % len(pattern3_blocks))
        for block in pattern3_blocks:
            id_match = re.search(r'/title/(tt\d+)/', block, re.IGNORECASE)
            ep_match = re.search(r'episodeNumber[^>]*>\s*(\d+)\s*<', block, re.IGNORECASE)
            if id_match and ep_match:
                ep_num = int(ep_match.group(1))
                imdb_id = id_match.group(1)
                if ep_num not in episode_map:
                    episode_map[ep_num] = imdb_id
                    logDebug("IMDbHTTPEpisode", "ADD ep=%s imdb=%s" % (ep_num, imdb_id))
    except Exception as e:
        logError("IMDbHTTPEpisode", "Parse_IMDb_episodes_page - PARSE EXCEPTION: %s" % str(e))
        return (None, "IMDb season page parse error")
    # -----------------------------------------------------
    # FINAL RESULT
    # -----------------------------------------------------
    if not episode_map:
        if DebugLog == "true":
            logDebug("IMDbHTTPEpisode", "FINAL episode_map EMPTY!")
        IMDB_SEASON_CACHE[cache_key] = None
        return (None, "IMDb season page parsed but no episode IDs found")
    if DebugLog == "true":
        logDebug("IMDbHTTPEpisode", "FINAL episode_map size=%d keys=%s" % (len(episode_map), sorted(list(episode_map.keys()))))
    IMDB_SEASON_CACHE[cache_key] = episode_map
    if DebugLog == "true":
        logDebug("IMDbHTTPEpisode", "=== END parse_IMDb_episodes_page === OK")
    return (episode_map, "OK")
