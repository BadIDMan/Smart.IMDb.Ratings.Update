# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import socket, six
import xbmc
from six.moves.urllib.request import Request, urlopen
from six.moves.urllib.error import HTTPError, URLError
from support.common import *
import io, gzip

User_Agent = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/87.0.4280.88 Safari/537.36"
Accept_Encoding = "gzip"


def get_page(url):
    # It doesn't work anymore since IMDb implemented WAF anti-bot protection but I'm keeping this for reference and maybe for restart to use it
    if DebugLog == "true":
        logDebug("IMDbGetPage", "=== START === url=%s" % url)
    req = Request(url)
    req.add_header('User-Agent', User_Agent)
    req.add_header('Accept-encoding', Accept_Encoding)
    if DebugLog == "true":
        logDebug("IMDbGetPage", "headers UA=%s AE=%s" % (User_Agent, Accept_Encoding))
    socket.setdefaulttimeout(30)
    html = ""
    try:
        if DebugLog == "true":
            logDebug("IMDbGetPage", "Opening URL...")
        response = urlopen(req)
        if DebugLog == "true":
            logDebug("IMDbGetPage", "Response object=%s" % str(response))
        try:
            headers = response.info()
            if DebugLog == "true":
                logDebug("IMDbGetPage", "Response headers=%s" % str(headers))
        except Exception as e:
            logError("IMDbGetPage", "Failed reading headers: %s" % str(e))
        encoding = None
        try:
            encoding = response.info().get('Content-Encoding')
        except Exception:
            pass
        if DebugLog == "true":
            logDebug("IMDbGetPage", "Content-Encoding=%s" % str(encoding))
        # -------------------------------------------------
        # READ RAW DATA
        # -------------------------------------------------
        try:
            raw = response.read()
            if DebugLog == "true":
                logDebug("IMDbGetPage", "RAW type=%s len=%s" % (type(raw), len(raw) if raw else "None/0"))
        except Exception as e:
            logError("IMDbGetPage", "Failed reading raw response: %s" % str(e))
            raw = None
        # -------------------------------------------------
        # DECODE
        # -------------------------------------------------
        try:
            if encoding == 'gzip':
                if DebugLog == "true":
                    logDebug("IMDbGetPage", "Decoding gzip...")
                buf = io.BytesIO(raw)
                f = gzip.GzipFile(fileobj=buf)
                decoded = f.read()
                if DebugLog == "true":
                    logDebug("IMDbGetPage", "GZIP decoded len=%s" % (len(decoded) if decoded else "None/0"))
                html = decoded.decode("utf-8")
            else:
                if DebugLog == "true":
                    logDebug("IMDbGetPage", "Decoding plain utf-8...")
                html = raw.decode("utf-8") if raw else ""
        except Exception as e:
            logError("IMDbGetPage", "Decode error: %s" % str(e))
            html = None
        # -------------------------------------------------
        # FINAL HTML CHECK
        # -------------------------------------------------
        if DebugLog == "true":
            logDebug("IMDbGetPage", "FINAL html type=%s len=%s" % (type(html), len(html) if html else "None/0"))
        # Optional: detect non-HTML responses
        if html:
            snippet = html[:200].replace("\n", " ").replace("\r", "")
            if DebugLog == "true":
                logDebug("IMDbGetPage", "HTML snippet=%s" % snippet)
        else:
            if DebugLog == "true":
                logError("IMDbGetPage", "EMPTY HTML after decode!")
        response.close()
        if DebugLog == "true":
            logDebug("IMDbGetPage", "=== END OK ===")
        return (html, "OK", "OK")
    except HTTPError as err:
        error = str(err.code) + " " + err.reason
        statusInfo = "Method get_page - " + url + " -> Error accessing IMDb site (" + error + ")"
        if DebugLog == "true":
            logError("IMDbGetPage", "HTTPError: %s" % statusInfo)
        return (html, "HTTP", statusInfo)
    except socket.error as err:
        statusInfo = "Method get_page - " + url + " -> Error accessing IMDb site (" + str(err) + ")"
        if DebugLog == "true":
            logError("IMDbGetPage", "Socket error: %s" % statusInfo)
        return (html, "socket", statusInfo)
    except URLError as err:
        if not isinstance(err, six.string_types):
            error = err.reason
        else:
            error = str(err)
        statusInfo = "Method get_page - " + url + " -> Error accessing IMDb site (" + error + ")"
        if DebugLog == "true":
            logError("IMDbGetPage", "URLError: %s" % statusInfo)
        return (html, "socket", statusInfo)
    except Exception as e:
        logError("IMDbGetPage", "UNEXPECTED ERROR: %s" % str(e))
        return (html, "HTTP", "Unexpected error")


def internet():
    try:
        import requests
        headers = {'User-Agent': User_Agent}
        response = requests.get('https://www.google.com', headers=headers, timeout=3)
        return True
    except: 
        return False


def wait_for_internet(wait=30, retry=5):
    monitor = xbmc.Monitor()
    count = 0
    while True:
        if internet():
            return True
        count += 1
        if count >= retry or monitor.abortRequested():
            return False
        monitor.waitForAbort(wait)