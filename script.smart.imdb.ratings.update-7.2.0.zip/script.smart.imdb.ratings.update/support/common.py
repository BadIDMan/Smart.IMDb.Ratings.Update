# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import json as jSon
import sys
import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import os, re
from datetime import datetime, timedelta
addon = xbmcaddon.Addon()
ADDON_DATA_PATH = xbmcvfs.translatePath(addon.getAddonInfo("profile"))
DB_FOLDER = os.path.join(ADDON_DATA_PATH, "db")
LOGS_FOLDER = os.path.join(ADDON_DATA_PATH, "logs")

addonSettings           = xbmcaddon.Addon("script.smart.imdb.ratings.update")
addonName               = addonSettings.getAddonInfo("name")
addonVersion            = addonSettings.getAddonInfo("version")
addonIcon               = os.path.join(addonSettings.getAddonInfo("path"), "icon.png")
addonProfile            = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile"))
addonLanguage           = addonSettings.getLocalizedString
ShowProgress            = xbmcaddon.Addon().getSettingBool("ShowProgress")
Sound                   = xbmcaddon.Addon().getSettingBool("NotificationsSound")


def printable_IDs(imdb, tvdb, tmdb):
    if imdb == None: imdb = addonLanguage(32531)
    if tvdb == None: tvdb = addonLanguage(32531)
    if tmdb == None: tmdb = addonLanguage(32531)
    return imdb, tvdb, tmdb

def normalize_IDs(imdb, tvdb, tmdb):
    if imdb == "": imdb = None
    if tvdb == "": tvdb = None
    if tmdb == "": tmdb = None
    return imdb, tvdb, tmdb

# ----------------------------------------------------------
# ENSURE DIRECTORIES
# ----------------------------------------------------------
def ensure_logs_folder():
    if not xbmcvfs.exists(LOGS_FOLDER):
        xbmcvfs.mkdirs(LOGS_FOLDER)

def ensure_db_folder():
    if not xbmcvfs.exists(DB_FOLDER):
        xbmcvfs.mkdirs(DB_FOLDER)

def getRateLimitThreshold():
    return (
        int(xbmcaddon.Addon().getSetting("TimeSlot") or 10) /
        float(int(xbmcaddon.Addon().getSetting("MAXRequests") or 25))
    )

def getEnabledWeekdays():
    mode = xbmcaddon.Addon().getSetting("ScheduleMode")
    if mode == "0":  # every day
        return [True, True, True, True, True, True, True]
    elif mode == "1":  # single day
        selected = int(xbmcaddon.Addon().getSetting("SingleDay"))
        return [i == selected for i in range(7)]
    else:  # custom
        return [
            xbmcaddon.Addon().getSetting("ScheduleMon") == "true",
            xbmcaddon.Addon().getSetting("ScheduleTue") == "true",
            xbmcaddon.Addon().getSetting("ScheduleWed") == "true",
            xbmcaddon.Addon().getSetting("ScheduleThu") == "true",
            xbmcaddon.Addon().getSetting("ScheduleFri") == "true",
            xbmcaddon.Addon().getSetting("ScheduleSat") == "true",
            xbmcaddon.Addon().getSetting("ScheduleSun") == "true",
        ]

def detectTVShowStatusSupport(tvshowid):
    try:
        jSonQuery = (
            '{"jsonrpc":"2.0",'
            '"method":"VideoLibrary.GetTVShowDetails",'
            '"params":{"tvshowid":%d,"properties":["status"]},'
            '"id":1}'
        ) % tvshowid
        jSonResponse = xbmc.executeJSONRPC(jSonQuery)
        jSonResponse = jSon.loads(jSonResponse)
        return ("result" in jSonResponse and "tvshowdetails" in jSonResponse["result"] and "status" in jSonResponse["result"]["tvshowdetails"])
    except Exception:
        return False

def UpdateTVShowStatusFromTMDB(tvshowid, TMDB, Title):
    from core.tmdb_api import get_TMDB_tvshow_status
    (tvshow_status, statusInfo) = get_TMDB_tvshow_status(TMDB)
    if tvshow_status is None:
        return (None, statusInfo)
    jSonQuery = (
        '{"jsonrpc":"2.0",'
        '"method":"VideoLibrary.SetTVShowDetails",'
        '"params":{"tvshowid":' + str(tvshowid) +
        ',"status":"' + tvshow_status + '"},'
        '"id":1}'
    )
    response = xbmc.executeJSONRPC(jSonQuery)
    return (tvshow_status, "OK")

def cleanup_libraryHealth_log():
    try:
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_libraryHealth.log"
        with open(log_path, "w") as f:
            f.write("--------------------------------------------------------------------------------\n")
            f.write("Smart IMDb Ratings Update - Library Health Report\n")
            f.write("Generated: %s\n" % datetime.now().strftime("%Y-%m-%d %H:%M:%S"))
            f.write("Add-on version: %s | Kodi version: %s\n" % (addonVersion, get_kodi_version()))
            f.write("--------------------------------------------------------------------------------\n")
    except Exception as e:
        logError("LibraryHealth", "Unable to initialize library health log: %s" % str(e))

def cleanup_activity_log():
    try:
        retention_map = {
            0: 3,
            1: 7,
            2: 14,
            3: 31,
            4: 90,
            5: 182
        }
        setting_value = int(xbmcaddon.Addon().getSetting("ActivityLogDays") or 3)
        days = retention_map.get(setting_value, 31)
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_activity.log"
        cutoff = datetime.now() - timedelta(days=days)
        logInfo("ActivityLog", "Keeping activity log entries from last %d days" % days)
        with open(log_path, "r", encoding="utf-8") as f:
            lines = f.readlines()
        filtered = []
        for line in lines:
            try:
                line_date = datetime.strptime(line[:19], "%Y-%m-%d %H:%M:%S")
                if line_date >= cutoff:
                    filtered.append(line)
            except:
                filtered.append(line)
        with open(log_path, "w", encoding="utf-8") as f:
            f.writelines(filtered)
    except Exception as e:
        xbmc.log("[IMDbRatings][ActivityLog] Failed: %s" % str(e), xbmc.LOGERROR)

def activityLog(textMessage):
    try:
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_activity.log"
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("%s - %s\n" % (timestamp, textMessage))
    except Exception as e:
        xbmc.log("[IMDbRatings][ActivityLog] Failed: %s" % str(e), xbmc.LOGERROR)

def statusLog(textMessage):
    try:
        log_path = get_current_log_path()
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("%s - %s\n" % (timestamp, textMessage))
    except Exception as e:
        xbmc.log("[IMDbRatings][Log] statusLog failed: %s" % str(e), xbmc.LOGERROR)

def libraryHealthLog(textMessage):
    try:
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_libraryHealth.log"
        with open(log_path, "a", encoding="utf-8") as f:
            f.write("%s\n" % (textMessage))
    except Exception as e:
        xbmc.log("[IMDbRatings][HealthLog] Failed: %s" % str(e), xbmc.LOGERROR)

def logInfo(component, textMessage):
    message = "[IMDbRatings][%s] %s" % (component, textMessage)
    if int(xbmcaddon.Addon().getSetting("WhereLogs") or 0) == 1:
        xbmc.log(message, xbmc.LOGINFO)
    else:
        try:
            activityLog(message)
        except:
            pass

def logDebug(component, textMessage):
    message = "[IMDbRatings][DEBUG][%s] %s" % (component, textMessage)
    if int(xbmcaddon.Addon().getSetting("WhereLogs") or 0) == 1:
        xbmc.log(message, xbmc.LOGINFO)
    else:
        try:
            activityLog(message)
        except:
            pass

def logError(component, textMessage):
    message = "[IMDbRatings][ERROR][%s] %s" % (component, textMessage)
    if int(xbmcaddon.Addon().getSetting("WhereLogs") or 0) == 1:
        xbmc.log(message, xbmc.LOGERROR)
    else:
        try:
            activityLog(message)
        except:
            pass

def doNotify(textMessage, millSec):
    dialog = xbmcgui.Dialog()
    dialog.notification(addonName, textMessage, addonIcon, millSec, Sound)


LOG_INITIALIZED_DATE = False
def get_logs_dir():
    logs_dir = addonProfile + "/logs"
    if not xbmcvfs.exists(logs_dir):
        xbmcvfs.mkdirs(logs_dir)
    return logs_dir

def get_current_log_path():
    logs_dir = get_logs_dir()
    filename = "SmartIMDb_%s.log" % datetime.now().strftime("%Y%m%d")
    return logs_dir + "/" + filename

def cleanup_old_logs():
    try:
        logs_dir = get_logs_dir()
        keep_logs = int(xbmcaddon.Addon().getSetting("LogRotate") or 14)
        files = xbmcvfs.listdir(logs_dir)[1]
        log_files = []
        for f in files:
            if re.match(r"SmartIMDb_\d{8}\.log$", f):
                log_files.append(f)
        log_files.sort(reverse=True)
        old_logs = log_files[keep_logs:]
        for old_log in old_logs:
            try:
                xbmcvfs.delete(logs_dir + "/" + old_log)
            except:
                pass
    except Exception as e:
        xbmc.log("[IMDbRatings][Log] cleanup_old_logs failed: %s" % str(e), xbmc.LOGERROR)

def ensure_log_initialized(trigger="Service startup"):
    global LOG_INITIALIZED_DATE
    today = datetime.now().strftime("%Y-%m-%d")
    if LOG_INITIALIZED_DATE == today:
        return
    log_path = get_current_log_path()
    try:
        if int(xbmcaddon.Addon().getSetting("IMDbSource")) == 1:
            UpdateSource = "IMDb HTTP"
        else:
            UpdateSource = "IMDbAPI (https://api.tiffara.com)"
        if xbmcaddon.Addon().getSettingBool("LocalIMDbSQL"):
            UpdateSource = "IMDb dataset from  https://developer.imdb.com/non-commercial-datasets/"
        if xbmcaddon.Addon().getSettingBool("Top250Support"):
            if xbmcaddon.Addon().getSetting("Top250SelectLocation") == "0":
                Top250S = "Top250.txt in add-on data /db folder"
            if xbmcaddon.Addon().getSetting("Top250SelectLocation") == "1":
                Top250S = "Top250.txt on local network share or folder"
            if xbmcaddon.Addon().getSetting("Top250SelectLocation") == "2":
                Top250S = "Top250 download from http://top250.info/charts/"
        with open(log_path, "a", encoding="utf-8") as f:
            if xbmcvfs.exists(log_path):
                f.write("\n")
            f.write("--------------------------------------------------------------------------------\n")
            f.write("Starting %s (%s)\n" % (addonName, datetime.now().strftime("%Y-%m-%d %H:%M:%S")))
            f.write("Add-on version: %s | Kodi version: %s\n" % (addonVersion, get_kodi_version()))
            f.write("onMovies: %s | onTVShows: %s | Monthly Full Refresh: %s\n" % (xbmcaddon.Addon().getSettingBool("Movies"), xbmcaddon.Addon().getSettingBool("TVShows"), xbmcaddon.Addon().getSettingBool("MonthlyFullRefresh")))
            f.write("Schedule Enabled: %s | Update Ratings At Start: %s\n" % (xbmcaddon.Addon().getSettingBool("ScheduleEnabled"), xbmcaddon.Addon().getSettingBool("UpdateRatingsAtStart")))
            f.write("Source of update: %s\n" % UpdateSource)
            if xbmcaddon.Addon().getSettingBool("Top250Support"):
                f.write("Source of Top250: %s\n" % Top250S)
            f.write("Trigger: %s\n" % trigger)
            f.write("--------------------------------------------------------------------------------\n")
        LOG_INITIALIZED_DATE = True
        cleanup_old_logs()
    except Exception as e:
        xbmc.log("[IMDbRatings][Log] ensure_log_initialized failed: %s" % str(e), xbmc.LOGERROR)

def get_kodi_version():
    query = {
        "jsonrpc": "2.0",
        "method": "Application.GetProperties",
        "params": {
            "properties": ["version", "name"]
        },
        "id": 1
    }
    json_query = xbmc.executeJSONRPC(jSon.dumps(query))
    if sys.version_info[0] >= 3:
        json_query = str(json_query)
    else:
        json_query = unicode(json_query, 'utf-8', errors='ignore')
    json_query = jSon.loads(json_query)
    version_installed = []
    if 'result' in json_query and 'version' in json_query['result']:
        version_installed = json_query['result']['version']
        return str(version_installed['major']) + "." + str(version_installed['minor'])
    else:
        return ""

def load_top250():
    top250 = {}
    try:
        path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/db/Top250.txt"
        if not xbmcvfs.exists(path):
            return top250
        f = xbmcvfs.File(path)
        content = f.read()
        f.close()
        for line in content.splitlines():
            line = line.strip()
            if not line or "|" not in line:
                continue
            rank, imdb = line.split("|", 1)
            try:
                top250[imdb.strip()] = int(rank.strip())
            except:
                pass
    except Exception as e:
        xbmc.log("[IMDbRatings][Top250] Failed loading Top250.txt: %s" % str(e), xbmc.LOGERROR)
    return top250

def get_top250_rank(imdb_id):
    if not imdb_id:
        return 0
    top250 = load_top250()
    return top250.get(imdb_id, 0)

def get_progress_title(source_override=None):
    if source_override == "api":
        source = "api"
    elif source_override == "dataset":
        source = "dataset"
    elif source_override == "html":
        source = "IMDb HTML"
    else:
        if xbmcaddon.Addon().getSettingBool("LocalIMDbSQL"):
            source = "dataset"
        elif int(xbmcaddon.Addon().getSetting("IMDbSource")) == 1:
            source = "IMDb HTML"
        else:
            source = "api"
        if xbmcaddon.Addon().getSetting("FullRefreshMode") == "true":
            return "%s - Monthly Full Refresh (source: %s)..." % (addonLanguage(32260).replace("...", ""), source)
    return "%s (source: %s)" % (addonLanguage(32260), source)