# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# by rafikW                 #
#############################

import xbmc, xbmcaddon, xbmcvfs, xbmcgui
import json as jSon
import time
from datetime import date, datetime, timedelta
from support.common import *
from main import StartUpdate
from core.update_main import Movies
from core.tvdb_api import UpdateMissingBanner
from core.imdb_dataset import *

if not xbmcvfs.exists(addonProfile): xbmcvfs.mkdir(addonProfile)

LAST_SCHEDULE_RUN = 0
LAST_SCAN_EVENT = 0
DATASET_MONITOR_ACTIVE = False
DATASET_MONITOR_START = 0
DATASET_FIRST_CHECK = True
DATASET_LATE_MONITOR_ACTIVE = False
DATASET_LATE_MONITOR_NEXT_CHECK = 0
DATASET_LATE_MONITOR_END = 0
PRE_SCAN_MOVIE_IDS = set()
PRE_SCAN_TVSHOW_IDS = set()
PRE_SCAN_EPISODE_IDS = set()


def ensure_activity_log():
    try:
        log_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_activity.log"
        log_dir = os.path.dirname(log_path)
        if not xbmcvfs.exists(log_dir):
            xbmcvfs.mkdirs(log_dir)
        if not xbmcvfs.exists(log_path):
            with open(log_path, "w", encoding="utf-8"):
                pass
    except Exception as e:
        xbmc.log("[IMDbRatings][ActivityLog] Failed: %s" % str(e), xbmc.LOGERROR)

def UpdateSchedule():
    enabled_days = getEnabledWeekdays()
    run_time = xbmcaddon.Addon().getSetting("DayTime")
    today = datetime.now()
    today_weekday = today.weekday()
    next_run = None
    for offset in range(0, 8):
        day_index = (today_weekday + offset) % 7
        if not enabled_days[day_index]:
            continue
        candidate_date = today.date() + timedelta(days=offset)
        if offset == 0 and time.strftime("%H:%M:%S") >= run_time:
            continue
        next_run = candidate_date
        break
    if next_run:
        xbmcaddon.Addon().setSetting("ScheduledRunDate", next_run.strftime("%Y-%m-%d"))
        statusLog(addonLanguage(32655) % (next_run.strftime("%Y-%m-%d"), run_time))
    xbmc.sleep(2000)
    logInfo("Monitor","Scheduler active days: %s @ %s" % (", ".join(d for d, v in zip(["Mon","Tue","Wed","Thu","Fri","Sat","Sun"], getEnabledWeekdays()) if v), xbmcaddon.Addon().getSetting("DayTime")))

def checkMonthlyFullRefresh():
    xbmcaddon.Addon().setSetting("FullRefreshMode", "false")
    if not xbmcaddon.Addon().getSettingBool("MonthlyFullRefresh"):
        return
    try:
        last_refresh = xbmcaddon.Addon().getSetting("LastFullRefreshDate")
        if last_refresh:
            days_since = (datetime.now() - datetime.strptime(last_refresh, "%Y-%m-%d")).days
            if days_since >= 30:
                xbmcaddon.Addon().setSetting("FullRefreshMode", "true")
                logInfo("Monitor", "Monthly Full Refresh activated (last refresh %d days ago)" % days_since)
        else:
            xbmcaddon.Addon().setSetting("FullRefreshMode", "true")
            logInfo("Monitor", "Monthly Full Refresh activated (no previous refresh date found)")
    except Exception as e:
        logError("Monitor", "Failed to evaluate Monthly Full Refresh: %s" % str(e))

def start_dataset_late_monitor():
    global DATASET_LATE_MONITOR_ACTIVE
    global DATASET_LATE_MONITOR_END
    global DATASET_LATE_MONITOR_NEXT_CHECK
    try:
        UpdateSchedule()
        scheduled_date = xbmcaddon.Addon().getSetting("ScheduledRunDate")
        daytime = xbmcaddon.Addon().getSetting("DayTime")
        if not scheduled_date or scheduled_date == "2000-01-01":
            logError("Monitor", "Unable to determine next scheduled dataset check date")
            return False
        try:
            next_run_date = datetime.strptime(scheduled_date, "%Y-%m-%d")
        except TypeError:
            next_run_date = datetime(*(time.strptime(scheduled_date, "%Y-%m-%d")[0:6]))
        try:
            next_run_time = datetime.strptime(daytime, "%H:%M:%S").time()
        except ValueError:
            next_run_time = datetime.strptime(daytime, "%H:%M").time()
        next_monitor_start = datetime.combine(next_run_date.date(), next_run_time)
        # Late-publication period ends one hour before
        # the next normal dataset monitoring window starts.
# Disable for simulating late-publication period end:
        late_monitor_end = next_monitor_start - timedelta(hours=1)
# Enable for simulating late-publication period end:
#        late_monitor_end = datetime.combine(datetime.now().date(), datetime.strptime("07:20:00", "%H:%M:%S").time())

        now = datetime.now()
        if late_monitor_end <= now:
            logError("Monitor", "Unable to start late-publication period - calculated end time has already passed")
            return False
        DATASET_LATE_MONITOR_ACTIVE = True
        DATASET_LATE_MONITOR_END = time.mktime(late_monitor_end.timetuple())
        # First late-period check should happen immediately.
        DATASET_LATE_MONITOR_NEXT_CHECK = time.time()
        logInfo("Monitor", "IMDb dataset late-publication period started - checking until %s" % late_monitor_end.strftime("%Y-%m-%d %H:%M:%S"))
        doNotify("Late-publication period started because no new dataset appeared in the monitoring window...", 8000)
        return True
    except Exception as e:
        logError("Monitor", "Failed to start IMDb dataset late-publication period: %s" % str(e))
        return False

def TakeLibrarySnapshot():
    global PRE_SCAN_MOVIE_IDS
    global PRE_SCAN_TVSHOW_IDS
    PRE_SCAN_MOVIE_IDS = set()
    PRE_SCAN_TVSHOW_IDS = set()
    try:
        # MOVIES
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        movies = response.get("result", {}).get("movies", [])
        for movie in movies:
            movieid = movie.get("movieid")
            PRE_SCAN_MOVIE_IDS.add(movieid)
        # TV SHOWS
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows",'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        tvshows = response.get("result", {}).get("tvshows", [])
        for show in tvshows:
            tvshowid = show.get("tvshowid")
            PRE_SCAN_TVSHOW_IDS.add(tvshowid)
        # EPISODES
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        episodes = response.get("result", {}).get("episodes", [])
        for episode in episodes:
            episodeid = episode.get("episodeid")
            PRE_SCAN_EPISODE_IDS.add(episodeid)
        logInfo("Monitor","Library snapshot saved (%d movies, %d TV shows, %d episodes)" % (len(PRE_SCAN_MOVIE_IDS), len(PRE_SCAN_TVSHOW_IDS), len(PRE_SCAN_EPISODE_IDS)))
    except Exception as e:
        logError("Monitor","Snapshot failed: %s" % str(e))

def UpdateNewLibraryItems():
    global PRE_SCAN_MOVIE_IDS
    global PRE_SCAN_TVSHOW_IDS
    global PRE_SCAN_EPISODE_IDS
    now = time.time()
    if hasattr(UpdateNewLibraryItems, "_last_run"):
        if now - UpdateNewLibraryItems._last_run < 30:
            logInfo("Monitor","Ignoring duplicate library scan event")
            return
    result, dataset_dt = ensure_latest_dataset_available()
    if result == "not_available":
        if not xbmcvfs.exists(DB_FILE):
            logError("Update", "Dataset source selected but local dataset unavailable")
            return
        logInfo("Update", "Latest IMDb dataset unavailable - using existing local dataset")
    UpdateNewLibraryItems._last_run = now
    logInfo("Monitor","Library scan finished – checking for newly added items")
    while xbmc.getCondVisibility("Library.IsScanningVideo"):
        xbmc.sleep(1000)
    try:
        # ------------------
        # GET CURRENT MOVIES
        # ------------------
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
            '"params":{"properties":["title","uniqueid","year"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        current_movies = response.get("result", {}).get("movies", [])
        # --------------------
        # GET CURRENT TV SHOWS
        # --------------------
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShows",'
            '"params":{"properties":["title","uniqueid"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        current_tvshows = response.get("result", {}).get("tvshows", [])
        # --------------------
        # GET CURRENT EPISODES
        # --------------------
        query = (
            '{"jsonrpc":"2.0","method":"VideoLibrary.GetEpisodes",'
            '"params":{"properties":["showtitle","season","episode","tvshowid","uniqueid"]},'
            '"id":1}'
        )
        response = xbmc.executeJSONRPC(query)
        response = jSon.loads(response)
        current_episodes = response.get("result", {}).get("episodes", [])
        # -----------------
        # DETECT NEW MOVIES
        # -----------------
        movies_to_update = []
        current_movie_ids = set()
        for movie in current_movies:
            movieid = movie.get("movieid")
            current_movie_ids.add(movieid)
            if movieid not in PRE_SCAN_MOVIE_IDS:
                movies_to_update.append(movie)
                logInfo("Monitor","Detected new movie: %s (%s)" % (movie.get("title"), movie.get("year")))
        # -------------------
        # DETECT NEW TV SHOWS
        # -------------------
        tvshows_to_update = {}
        current_tvshow_ids = set()
        for show in current_tvshows:
            tvshowid = show.get("tvshowid")
            current_tvshow_ids.add(tvshowid)
            if tvshowid not in PRE_SCAN_TVSHOW_IDS:
                tvshows_to_update[tvshowid] = {"show": show, "episodes": []}
                logInfo("Monitor","Detected new TV show: %s" % show.get("title"))
        # -------------------
        # DETECT NEW EPISODES
        # -------------------
        current_episode_ids = set()
        for episode in current_episodes:
            episodeid = episode.get("episodeid")
            current_episode_ids.add(episodeid)
            if episodeid not in PRE_SCAN_EPISODE_IDS:
                tvshowid = episode.get("tvshowid")
                # -------------------------------------------------
                # EXISTING SHOW WITH NEW EPISODES
                # -------------------------------------------------
                if tvshowid not in tvshows_to_update:
                    query = (
                        '{"jsonrpc":"2.0","method":"VideoLibrary.GetTVShowDetails",'
                        '"params":{'
                        '"tvshowid":%d,'
                        '"properties":["title","uniqueid"]'
                        '},'
                        '"id":1}'
                    ) % tvshowid
                    response = xbmc.executeJSONRPC(query)
                    response = jSon.loads(response)
                    show = response.get("result",{}).get("tvshowdetails",{})
                    tvshows_to_update[tvshowid] = {"show": show, "episodes": []}
                    logInfo("Monitor","Detected new episodes for existing TV show: %s" % show.get("title"))
                tvshows_to_update[tvshowid]["episodes"].append(episode)
        # ----------------------
        # SAVE CURRENT SNAPSHOTS
        # ----------------------
        PRE_SCAN_MOVIE_IDS = current_movie_ids
        PRE_SCAN_TVSHOW_IDS = current_tvshow_ids
        PRE_SCAN_EPISODE_IDS = current_episode_ids
        # -----------
        # NOTHING NEW
        # -----------
        if not movies_to_update and not tvshows_to_update:
            logInfo("Monitor","No new items added today")
            doNotify("No new items added today...", 3500)
            return
        logInfo("Monitor","Found %d new movies and %d TV shows requiring updates" % (len(movies_to_update), len(tvshows_to_update)))
        from core.update_main import thread_parse_IMDb_page
        from _thread import allocate_lock
        lock = allocate_lock()
        flock = allocate_lock()
        progress = xbmcgui.DialogProgressBG()
        progress.create("IMDb Ratings", "Updating newly added items")
        # -----------------
        # COUNT TOTAL ITEMS
        # -----------------
        total = len(movies_to_update)
        for tvshowid in tvshows_to_update:
            total += 1
            total += len(tvshows_to_update[tvshowid]["episodes"])
        count = 0
        # -------
        # LOGGING
        # -------
        statusLog("Auto-update ratings for newly added items started")
        # -------------
        # UPDATE MOVIES
        # -------------
        for movie in movies_to_update:
            count += 1
            percentage = int((count / float(total)) * 100)
            movieid = movie.get("movieid")
            title = movie.get("title")
            unique = movie.get("uniqueid", {})
            IMDb = unique.get("imdb")
            TVDB = unique.get("tvdb")
            TMDB = unique.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
            progress.update(percentage, title)
            thread_parse_IMDb_page("movie", movieid, IMDb, TVDB, TMDB, title, -1, None, progress, percentage, lock, flock)
        # --------------------------
        # UPDATE TV SHOWS + EPISODES
        # --------------------------
        for tvshowid in tvshows_to_update:
            entry = tvshows_to_update[tvshowid]
            show = entry["show"]
            episodes = entry["episodes"]
            title = show.get("title")
            unique = show.get("uniqueid", {})
            IMDb = unique.get("imdb")
            TVDB = unique.get("tvdb")
            TMDB = unique.get("tmdb")
            IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
            # --------------
            # UPDATE TV SHOW
            # --------------
            count += 1
            percentage = int((count / float(total)) * 100)
            progress.update(percentage, title)
            thread_parse_IMDb_page("tvshow", tvshowid, IMDb, TVDB, TMDB, title, -1, tvshowid, progress, percentage, lock, flock)
            if xbmcaddon.Addon().getSetting("FetchBanner") == "true":
                UpdateMissingBanner(tvshowid, TVDB, title, log=True)
            # ---------------
            # UPDATE EPISODES
            # ---------------
            for item in episodes:
                count += 1
                percentage = int((count / float(total)) * 100)
                episodeid = item.get("episodeid")
                season = item.get("season")
                episode = "%02d" % item.get("episode")
                episode_title = (item.get("showtitle") + " " + str(season) + "x" + episode)
                unique = item.get("uniqueid", {})
                IMDb = unique.get("imdb")
                TVDB = unique.get("tvdb")
                TMDB = unique.get("tmdb")
                IMDb, TVDB, TMDB = normalize_IDs(IMDb, TVDB, TMDB)
                progress.update(percentage, episode_title)
                thread_parse_IMDb_page("episode", episodeid, IMDb, TVDB, TMDB, episode_title, season, tvshowid, progress, percentage, lock, flock)
        progress.close()
        logInfo("Monitor","Finished updating ratings for newly added items")
    except Exception as e:
        logError("Monitor","Auto-update failed: %s" % str(e))
    finally:
        xbmcaddon.Addon().setSetting("PerformingUpdate", "false")


class LibraryMonitor(xbmc.Monitor):
    def onNotification(self, sender, method, data):
        global LAST_SCAN_EVENT
        if method == "VideoLibrary.OnScanStarted":
            if not addonSettings.getSettingBool("UpdateAfterLibraryScan"):
                return
            logInfo("Monitor","Kodi library scan started")
            TakeLibrarySnapshot()
        if method == "VideoLibrary.OnScanFinished":
            if not addonSettings.getSettingBool("UpdateAfterLibraryScan"):
                return
            now = time.time()
            if now - LAST_SCAN_EVENT < 60:
                logInfo("Monitor","Duplicate scan finished event ignored")
                return
            LAST_SCAN_EVENT = now
            logInfo("Monitor","Kodi library scan finished")
            if xbmcaddon.Addon().getSetting("PerformingUpdate") == "true":
                logInfo("Monitor","Update already running – skipping auto-update")
                return
            xbmcaddon.Addon().setSetting("PerformingUpdate", "true")
            doNotify("Kodi library scan finished...ratings updates will start shortly...", 4000)
            xbmc.sleep(4000)
            UpdateNewLibraryItems()



def AutoStart():
    global LAST_SCHEDULE_RUN
    global DATASET_MONITOR_ACTIVE
    global DATASET_MONITOR_START
    global DATASET_FIRST_CHECK
    global DATASET_LATE_MONITOR_ACTIVE
    global DATASET_LATE_MONITOR_END
    global DATASET_LATE_MONITOR_NEXT_CHECK
    DATASET_LATE_MONITOR_ACTIVE = False
    DATASET_LATE_MONITOR_END = 0
    doNotify("Service started...", 3500)

    if xbmcaddon.Addon().getSetting("PerformingUpdate") == "true":
        logInfo("Monitor", "Detected unfinished update from previous session – resetting state")
    xbmcaddon.Addon().setSetting("PerformingUpdate", "false")
    xbmcaddon.Addon().setSetting("LogDialog", "false")
    if int(xbmcaddon.Addon().getSetting("WhereLogs") or 0) == 0:
        ensure_activity_log()
        cleanup_activity_log()
        activityLog("[IMDbRatings][ActivityLog] Service startup")
    else:
        xbmc.log("[IMDbRatings][ActivityLog] Service startup", xbmc.LOGINFO)
    ensure_log_initialized("Service startup")
    # --------------
    # STARTUP UPDATE
    # --------------
    if xbmcaddon.Addon().getSettingBool("UpdateRatingsAtStart"):
        logInfo("Monitor", "Startup ratings update check")
        today = datetime.now().strftime("%Y-%m-%d")
        # --------------
        # DATASET SOURCE
        # --------------
        if xbmcaddon.Addon().getSettingBool("LocalIMDbSQL"):
            try:
                result, dataset_dt = ensure_latest_dataset_available()
                if result == "updated":
                    logInfo("Monitor", "Latest available IMDb dataset downloaded -> starting startup ratings update")
                    checkMonthlyFullRefresh()
                    StartUpdate()
                elif result == "up_to_date":
                    logInfo("Monitor", "Local IMDb dataset already contains the latest available data -> startup update skipped")
                    doNotify("Ratings update not needed. The latest available IMDb dataset was already processed", 20000)
                else:
                    logError("Monitor", "Latest available IMDb dataset could not be obtained -> startup ratings update skipped")
            except Exception as e:
                logError("Monitor", "Startup dataset check failed: %s" % str(e))
        # -----------------
        # API / HTML SOURCE
        # -----------------
        else:
            if xbmcaddon.Addon().getSetting("LastRatingsUpdateDate") != today:
                logInfo("Monitor", "No ratings update performed today -> starting startup ratings update")
                checkMonthlyFullRefresh()
                StartUpdate()
            else:
                logInfo("Monitor", "Ratings already updated today -> startup update skipped")
                doNotify("Ratings update not needed. Ratings were already updated today", 15000)
    # --------------------
    # SCHEDULER MONITORING
    # --------------------
    monitor = LibraryMonitor()
    last_daytime = xbmcaddon.Addon().getSetting("DayTime")
    if xbmcaddon.Addon().getSettingBool("ScheduleEnabled"):
        UpdateSchedule()
    while not monitor.abortRequested():
        now = datetime.now()
        sleep_seconds = 60 - now.second
        monitor.waitForAbort(sleep_seconds)
        if monitor.abortRequested():
            break
        if xbmcaddon.Addon().getSetting("PerformingUpdate") == "true":
            continue
        if not xbmcaddon.Addon().getSettingBool("ScheduleEnabled"):
            continue
        current_daytime = xbmcaddon.Addon().getSetting("DayTime")
        if current_daytime != last_daytime:
            logInfo("Monitor", "Schedule / update time changed – recalculating")
            UpdateSchedule()
            last_daytime = current_daytime
        if xbmcaddon.Addon().getSetting("ScheduledRunDate") == "2000-01-01":
            UpdateSchedule()
        try:
            scheduled_day = datetime.strptime(xbmcaddon.Addon().getSetting("ScheduledRunDate"), "%Y-%m-%d")
        except TypeError:
            scheduled_day = datetime(*(time.strptime(xbmcaddon.Addon().getSetting("ScheduledRunDate"), "%Y-%m-%d")[0:6]))
        # --------------------
        # START MONITOR WINDOW
        # --------------------
        if datetime.now() >= scheduled_day:
            if time.strftime("%H:%M:%S") >= xbmcaddon.Addon().getSetting("DayTime"):
                now_ts = time.time()
                if now_ts - LAST_SCHEDULE_RUN >= 60:
                    LAST_SCHEDULE_RUN = now_ts
                    # ------------
                    # DATASET MODE
                    # ------------
                    if xbmcaddon.Addon().getSettingBool("LocalIMDbSQL"):
                        logInfo("Monitor", "Starting dataset monitoring window")
                        DATASET_MONITOR_ACTIVE = True
                        DATASET_MONITOR_START = now_ts
                        DATASET_FIRST_CHECK = True
                        retry_interval = int(xbmcaddon.Addon().getSetting("RetryInterval") or 15)
                        # Force immediate first check
                        AutoStart._last_dataset_check = (now_ts - retry_interval * 60)
                        AutoStart._half_logged = False
                        AutoStart._retry_wait_active = False
                    # --------
                    # API MODE
                    # --------
                    else:
                        ensure_log_initialized("Scheduled update start")
                        logInfo("Monitor", "Scheduled update time reached -> starting ratings update")
                        checkMonthlyFullRefresh()
                        StartUpdate()
                    UpdateSchedule()
        # =================================================
        # DATASET LATE-PUBLICATION PERIOD
        # =================================================
        if DATASET_LATE_MONITOR_ACTIVE:
            now_ts = time.time()
            # --------------------------------------
            # LATE-PUBLICATION PERIOD EXPIRED
            # --------------------------------------
            if now_ts >= DATASET_LATE_MONITOR_END:
                logInfo("Monitor", "IMDb dataset late-publication period expired")
                DATASET_LATE_MONITOR_ACTIVE = False
                DATASET_LATE_MONITOR_END = 0
                DATASET_LATE_MONITOR_NEXT_CHECK = 0
                logInfo("Monitor", "No new IMDb dataset detected during normal monitoring or late-publication period - ratings update skipped")
                append_dataset_missing_history()
                statusLog("No new IMDb dataset detected during normal monitoring or late-publication period - ratings update skipped (but Top250 update is still performed)")
                if xbmcaddon.Addon().getSettingBool("Top250Support"):
                    try:
                        logInfo("Monitor", "Running standalone Top250 synchronization")
                        Movies().doUpdateTop250Movies()
                    except Exception as e:
                        logError("Monitor", "Standalone Top250 synchronization failed: %s" % str(e))
                DATASET_FIRST_CHECK = False
                xbmcgui.Dialog().ok(
                    addonName + " - End of late-publication period",
                    "A new IMDb dataset was not detected today "
                    "within the configured monitoring and late-publication periods.\n\n"
                    "This may indicate that IMDb released the "
                    "dataset later than your configured "
                    "monitoring period.\n\n"
                    "You may consider:\n"
                    "- increasing \"Retry window\"\n"
                    "or\n"
                    "- changing \"Start dataset check / ratings update at\"\n\n"
                    "to better match IMDb dataset release times.\n\n"
                    "You may also do nothing, as IMDb occasionally "
                    "skips daily dataset releases.\n"
                    "You may also consider switching to the "
                    "api.tiffara.com source if you prefer ratings "
                    "updates that do not depend on IMDb dataset "
                    "publication times."
                )
                continue
            # --------------------------------------
            # WAIT UNTIL NEXT LATE-PERIOD CHECK
            # --------------------------------------
            if now_ts < DATASET_LATE_MONITOR_NEXT_CHECK:
                remaining_seconds = int(DATASET_LATE_MONITOR_NEXT_CHECK - now_ts)
                continue
            # --------------------------------------
            # CHECK DATASET
            # --------------------------------------
            retry_interval = int(xbmcaddon.Addon().getSetting("RetryInterval") or 15)
            logInfo("Monitor", "Late-publication period: checking for new IMDb dataset (check frequency=%d minutes)" % retry_interval)
            try:
                status = get_dataset_status()
            except Exception as e:
                logError("Monitor", "Late-publication dataset status check failed: %s" % str(e))
                status = None
            # Schedule the next check regardless of the result.
            DATASET_LATE_MONITOR_NEXT_CHECK = (time.time() + retry_interval * 60)
            logInfo("Monitor", "Late-publication period: next dataset check scheduled in %d minutes" % retry_interval)
            if status is not None:
                remote_dt = status["remote_dt"]
                local_dt = status["local_dt"]
                local_db_exists = status["local_db_exists"]
                # --------------------------------------
                # NEW DATASET AVAILABLE
                # --------------------------------------
                if (not local_db_exists or local_dt is None or (remote_dt is not None and remote_dt > local_dt)):
                    logInfo("Monitor", "New IMDb dataset detected during late-publication period")
                    try:
                        result, dataset_dt = ensure_latest_dataset_available()
                    except Exception as e:
                        logError("Monitor", "Late-publication dataset download failed: %s" % str(e))
                        continue
                    if result == "updated" and dataset_dt is not None:
                        logInfo("Monitor", "IMDb dataset downloaded during late-publication period - ratings update skipped")
                        DATASET_LATE_MONITOR_ACTIVE = False
                        DATASET_LATE_MONITOR_END = 0
                        DATASET_LATE_MONITOR_NEXT_CHECK = 0
                        DATASET_FIRST_CHECK = False
                        # IMPORTANT:
                        # No ratings update
                        # No Top250 synchronization
                        # No TV show status synchronization
                    elif result == "up_to_date":
                        logInfo("Monitor", "Late-publication check: IMDb dataset is already up to date")
                else:
                    logInfo("Monitor", "Late-publication period: new IMDb dataset not yet available")
            continue
        # --------------------
        # DATASET MONITOR LOOP
        # --------------------
        if DATASET_MONITOR_ACTIVE:
            retry_interval = int(xbmcaddon.Addon().getSetting("RetryInterval") or 15)
            max_window = int(xbmcaddon.Addon().getSetting("RetryWindow") or 180)
            now_ts = time.time()
            elapsed = (now_ts - DATASET_MONITOR_START) / 60.0
            # --------------
            # WINDOW EXPIRED
            # --------------
            if elapsed > max_window:
                logInfo("Monitor", "Dataset monitoring window expired")
                DATASET_MONITOR_ACTIVE = False
                # -------------------------------------------------
                # START LATE-PUBLICATION PERIOD
                # -------------------------------------------------
                if xbmcaddon.Addon().getSettingBool("LateIMDbDataset"):
                    if DATASET_FIRST_CHECK:
                        if start_dataset_late_monitor():
                            # IMPORTANT:
                            # Keep DATASET_FIRST_CHECK=True.
                            # It represents that today's dataset has
                            # not yet been dealt with.
                            continue
                        logError("Monitor", "Late-publication period could not be started - finalizing monitoring")
                # -------------------------------------------------
                # NO LATE-PUBLICATION PERIOD
                # OR FAILED TO START
                # -------------------------------------------------
                if DATASET_FIRST_CHECK:
                    logInfo("Monitor", "No new IMDb dataset detected within monitoring period - ratings update skipped")
                    append_dataset_missing_history()
                    statusLog("No new IMDb dataset detected within monitoring period - ratings update skipped (but Top250 update is still performed)")
                    if xbmcaddon.Addon().getSettingBool("Top250Support"):
                        try:
                            logInfo("Monitor", "Running standalone Top250 synchronization")
                            Movies().doUpdateTop250Movies()
                        except Exception as e:
                            logError("Monitor", "Standalone Top250 synchronization failed: %s" % str(e))
                    DATASET_FIRST_CHECK = False
                    xbmcgui.Dialog().ok(
                        addonName + " - End of monitoring window",
                        "A new IMDb dataset was not detected today "
                        "within the configured monitoring period.\n\n"
                        "This may indicate that IMDb released the "
                        "dataset later than your configured "
                        "monitoring period.\n\n"
                        "You may consider:\n"
                        "- increasing \"Retry window\"\n"
                        "or\n"
                        "- changing \"Start dataset check / ratings update at\"\n\n"
                        "to better match IMDb dataset release times.\n\n"
                        "You may also do nothing, as IMDb occasionally "
                        "skips daily dataset releases.\n"
                        "You may also consider switching to the "
                        "api.tiffara.com source if you prefer ratings "
                        "updates that do not depend on IMDb dataset "
                        "publication times."
                    )
            else:
                if not hasattr(AutoStart, "_last_dataset_check"):
                    AutoStart._last_dataset_check = 0
                if not hasattr(AutoStart, "_half_logged"):
                    AutoStart._half_logged = False
                if not hasattr(AutoStart, "_retry_wait_active"):
                    AutoStart._retry_wait_active = False
                time_since_last = (now_ts - AutoStart._last_dataset_check)
                # ----------------------
                # NON-SPAM RETRY LOGGING
                # ----------------------
                if AutoStart._retry_wait_active:
                    half_interval = (retry_interval * 60) / 2
                    if (not AutoStart._half_logged and time_since_last >= half_interval):
                        remaining_seconds = int((retry_interval * 60) - time_since_last)
                        if remaining_seconds < 0:
                            remaining_seconds = 0
                        minutes = remaining_seconds // 60
                        seconds = remaining_seconds % 60
                        logInfo("Monitor", "Next dataset check in about %d minutes, %d seconds" % (minutes, seconds))
                        AutoStart._half_logged = True
                # -------------
                # EXECUTE CHECK
                # -------------
                if time_since_last >= retry_interval * 60:
                    AutoStart._last_dataset_check = now_ts
                    AutoStart._half_logged = False
                    logInfo("Monitor", "Checking dataset...")
                    try:
                        status = check_dataset_update()
                    except Exception as e:
                        logError("Monitor", "Check failed: %s" % str(e))
                        status = None
                    # --------------
                    # STATE HANDLING
                    # --------------
                    if status == "updated":
                        logInfo("Monitor", "New dataset detected -> starting ratings update")
                        DATASET_MONITOR_ACTIVE = False
                        DATASET_FIRST_CHECK = False
                        AutoStart._retry_wait_active = False
                        ensure_log_initialized("Scheduled update start")
                        checkMonthlyFullRefresh()
                        StartUpdate()
# Enable for simulating late-publication period:
#                    elif status == "up_to_date":
#                        logInfo("Monitor", "SIMULATION...Dataset already up to date -> waiting for monitoring window to expire")
#                        AutoStart._retry_wait_active = True
# Disable for simulating late-publication period:
                    elif status == "up_to_date":
                        if DATASET_FIRST_CHECK:
                            logInfo("Monitor", "Dataset already up to date -> running ratings update")
                            DATASET_MONITOR_ACTIVE = False
                            DATASET_FIRST_CHECK = False
                            AutoStart._retry_wait_active = False
                            ensure_log_initialized("Scheduled update start")
                            checkMonthlyFullRefresh()
                            StartUpdate()

                    elif status == "not_available":
                        logInfo("Monitor", "Dataset not yet available -> waiting")
                        AutoStart._retry_wait_active = True
# ----------------------------------------------------------

if (__name__ == "__main__"):
    AutoStart()
