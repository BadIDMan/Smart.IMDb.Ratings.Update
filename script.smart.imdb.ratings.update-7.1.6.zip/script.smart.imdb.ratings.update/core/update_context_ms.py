# -*- coding: utf-8 -*-

#############################
# Smart IMDb Ratings Update #
# Movies Collection Context #
#############################

import xbmc, xbmcgui, xbmcvfs
import json as jSon
from support.common import *
from support.httptools import wait_for_internet


def open_context_menu(filename, label):
    UpdateMovieSet(filename, label)

def UpdateMovieSet(filename, label):
    set_name = label
    if not set_name:
        xbmcgui.Dialog().ok(addonName, "Unable to detect movie collection.")
        return
    while True:
        stringList = []
#----------- Show ratings updates sources
        dataset_option = len(stringList)
        stringList += ["[COLOR red]Update rating[/COLOR] [COLOR lightgreen](local dataset)[/COLOR]"]
        api_option = -1
        if addonSettings.getSetting("ShowAPIContext") == "true":
            api_option = len(stringList)
            stringList += ["[COLOR red]Update rating[/COLOR] [COLOR lightgreen](api.tiffara.com)[/COLOR]"]
        html_option = -1
        if addonSettings.getSetting("ShowIMDbHTMLContext") == "true":
            html_option = len(stringList)
            stringList += ["[COLOR red]Update rating[/COLOR] [COLOR lightgreen](IMDb HTML)[/COLOR]"]
        dataset_update_option = len(stringList)
        stringList += ["[COLOR orange]Update local dataset now[/COLOR]"]
#----------- Show dataset timestamp log file
        timestamp_option = -1
        if addonSettings.getSetting("ShowDatasetTimestamp") == "true" and addonSettings.getSetting("LocalIMDbSQL") == "true":
            timestamp_option = len(stringList)
            stringList += [ "[COLOR yellow]Show dataset timestamp log file[/COLOR]" ]
#----------- Show Top250 timestamp log file
        Top250_timestamp_option = -1
        if addonSettings.getSetting("ShowTop250Timestamp") == "true" and addonSettings.getSetting("Top250Support") == "true" and addonSettings.getSetting("Top250SelectLocation") == "2":
            Top250_timestamp_option = len(stringList)
            stringList += [ "[COLOR yellow]Show Top250 timestamp log file[/COLOR]" ]
#----------- Show Library Health Report log file
        Library_health_report_option = -1
        if addonSettings.getSetting("ShowLibraryHealthLog") == "true":
            Library_health_report_option = len(stringList)
            stringList += [ "[COLOR yellow]Show Library Health Report log file[/COLOR]" ]
#----------- Show last 20 lines of update log
        log_option = -1
        if addonSettings.getSetting("ShowUpdateLogLines") == "true":
            log_option = len(stringList)
            stringList += [ "[COLOR yellow]Show last 20 lines of the ratings update log file[/COLOR]" ]
#----------- Show last 40 lines of activity log
        if addonSettings.getSetting("ShowActivityLogLines") == "true" and WhereLogs == 0:
            activity_log_option = len(stringList)
            stringList += [ "[COLOR yellow]Show last 40 lines of the add-on activity log file[/COLOR]" ]
        option = xbmcgui.Dialog().select(addonName + " (Collection)", stringList)
        if option == -1:
            return
        if option in (api_option, dataset_option, html_option):
            if option == api_option:
                source_override = "api"
            elif option == dataset_option:
                source_override = "dataset"
            else:
                source_override = "html"
            # dataset presence guard
            if source_override == "dataset":
                db_path = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/db/imdb_ratings.db"
                if not xbmcvfs.exists(db_path):
                    xbmcgui.Dialog().ok(addonName, "Local dataset not found.\n\nRun scheduled update using 'Local copy of IMDb Ratings dataset' \nor run 'Update local dataset now'")
                    continue
            run_collection_update(set_name, source_override)
            continue
        elif option == dataset_update_option:
        # UPDATE LOCAL DATASET NOW
            try:
                # BLOCK: update already running
                if addonSettings.getSetting("PerformingUpdate") == "true":
                    xbmcgui.Dialog().ok(addonName, "Another update is already running.\n\nPlease wait until it finishes.")
                    continue
                # BLOCK: scheduled update soon
                from core.imdb_dataset import is_scheduled_update_soon
                if is_scheduled_update_soon(10):
                    xbmcgui.Dialog().ok(addonName, "Scheduled dataset update will run shortly.\n\nManual update blocked to avoid duplication.")
                    continue
                # CHECK: already up-to-date
                from core.imdb_dataset import is_dataset_up_to_date
                up_to_date, msg = is_dataset_up_to_date()
                if up_to_date:
                    xbmcgui.Dialog().ok(addonName, "Dataset is already up to date.\n\nNo download needed.")
                    continue
                # CONFIRMATION
                confirm = xbmcgui.Dialog().yesno(
                    addonName,
                    "This will download and rebuild the local IMDb dataset.\n"
                    "It may take few seconds or minutes.\n\nContinue?"
                )
                if not confirm:
                    continue
                # RUN UPDATE
                addonSettings.setSetting("PerformingUpdate", "true")
                progress = xbmcgui.DialogProgressBG()
                progress.create("IMDb Dataset", "Updating local dataset...")
                logInfo("Context", "Starting dataset update")
                from core.imdb_dataset import check_dataset_update
                check_dataset_update()
                progress.close()
                addonSettings.setSetting("PerformingUpdate", "false")
                xbmcgui.Dialog().ok(addonName, "Local dataset update completed.")
            except Exception as e:
                addonSettings.setSetting("PerformingUpdate", "false")
                logError("Context", "Dataset update failed: %s" % str(e))
                xbmcgui.Dialog().ok(addonName, "Dataset update failed.")
            continue
        elif option == timestamp_option:
            show_dataset_history_log()
            continue
        elif option == Top250_timestamp_option:
            show_Top250_history_log()
            continue
        elif option == Library_health_report_option:
            show_Library_health_report()
            continue
        elif option == log_option:
            show_log()
            continue
        elif option == activity_log_option:
            show_activity_log()
            continue

def run_collection_update(set_name, source_override):
    from core.update_main import thread_parse_IMDb_page
    from _thread import allocate_lock
    if not wait_for_internet(wait=0, retry=1):
        xbmcgui.Dialog().ok(addonName, addonLanguage(32257))
        return
    if addonSettings.getSetting("PerformingUpdate") == "true":
        xbmcgui.Dialog().ok(addonName, addonLanguage(32251))
        return
    addonSettings.setSetting("PerformingUpdate", "true")
    safe_name = set_name.replace("'", "")
    statusLog("[Context] Updating ratings on all movies in '%s', source: %s" % (safe_name, source_override))
    progress = xbmcgui.DialogProgressBG()
    progress.create(get_progress_title(source_override), set_name)
    lock = allocate_lock()
    flock = allocate_lock()
    query = (
        '{"jsonrpc":"2.0","method":"VideoLibrary.GetMovies",'
        '"params":{"filter":{"field":"set","operator":"is","value":"%s"},'
        '"properties":["uniqueid","title"]},"id":1}'
    ) % set_name
    response = jSon.loads(xbmc.executeJSONRPC(query))
    movies = response.get("result", {}).get("movies", [])
    total = len(movies)
    count = 0
    for item in movies:
        movieid = item.get("movieid")
        title = item.get("title")
        unique = item.get("uniqueid", {})
        IMDb, TVDB, TMDB = normalize_IDs(
            unique.get("imdb"),
            unique.get("tvdb"),
            unique.get("tmdb")
        )
        count += 1
        percentage = int((count / float(total)) * 100)
        progress.update(percentage, get_progress_title(source_override), "%s (%d/%d)" % (set_name, count, total))
        thread_parse_IMDb_page(
            "movie",
            movieid,
            IMDb,
            TVDB,
            TMDB,
            title,
            -1,
            None,
            progress,
            percentage,
            lock,
            flock,
            source_override
        )
    progress.close()
    addonSettings.setSetting("PerformingUpdate", "false")

def show_log():
    try:
        log_file = get_current_log_path()
        if not xbmcvfs.exists(log_file):
            xbmcgui.Dialog().ok(addonName, "Log file not found.")
            return
        with open(log_file, "r", encoding="utf-8") as f:
            content = f.read()
        f.close()
        lines = content.splitlines()
        last_lines = lines[-20:] if len(lines) >= 20 else lines
        formatted_lines = []
        for line in last_lines:
            line = re.sub(r",\s*(TVDB|TMDB) ID:\s*[^,\)]+", "", line)
            line = line.replace("Votes:", "")
            line = line.replace("-->", "->")
            line = re.sub(r"\s+", " ", line)
            line = line.replace("( ", "(").replace(" )", ")").strip()
            formatted_lines.append(line)
        text = "=== Last 20 log lines ===\n\n" + "\n".join(formatted_lines)
        xbmcgui.Dialog().textviewer("Today's Smart IMDb Log", text)
    except Exception as e:
        logError("Context", "Failed to read log: %s" % str(e))
        xbmcgui.Dialog().ok(addonName, "Failed to read log file.")

def show_activity_log():
    try:
        activity_log_file = xbmcvfs.translatePath(addonSettings.getAddonInfo("profile")) + "/logs/_smartIMDb_activity.log"
        if not xbmcvfs.exists(activity_log_file):
            xbmcgui.Dialog().ok(addonName, "Activity log file not found.")
            return
        with open(activity_log_file, "r", encoding="utf-8") as f:
            content = f.read()
        lines = content.splitlines()
        last_lines = lines[-40:] if len(lines) >= 40 else lines
        text = "=== Last 40 lines of the activity log ===\n\n" + "\n".join(last_lines)
        xbmcgui.Dialog().textviewer("Smart IMDb Activity Log", text)
    except Exception as e:
        logError("Context", "Failed to read log: %s" % str(e))
        xbmcgui.Dialog().ok(addonName, "Failed to read log file.")

def show_dataset_history_log():
    try:
        dataset_history_log_file = addonProfile + "/logs/_ratings_dataset.timestamp.history.log"
        if not xbmcvfs.exists(dataset_history_log_file):
            xbmcgui.Dialog().ok(addonName, "Dataset timestamp log file not found.")
            return
        with open(dataset_history_log_file, "r", encoding="utf-8") as f:
            content = f.read()
        lines = content.splitlines()
        last_lines = lines[-20:] if len(lines) >= 20 else lines
        text = ("=== IMDb Dataset Publication History (last 20 entries) ===\n\n" + "\n".join(last_lines))
        xbmcgui.Dialog().textviewer("IMDb Dataset Timestamp History", text)
    except Exception as e:
        logError("Context", "Failed to read log: %s" % str(e))
        xbmcgui.Dialog().ok(addonName, "Failed to read log file.")

def show_Top250_history_log():
    try:
        Top250_history_log_file = addonProfile + "/logs/_top250_html.timestamp.history.log"
        if not xbmcvfs.exists(Top250_history_log_file):
            xbmcgui.Dialog().ok(addonName, "Top250 timestamp log file not found.")
            return
        with open(Top250_history_log_file, "r", encoding="utf-8") as f:
            content = f.read()
        lines = content.splitlines()
        last_lines = lines[-20:] if len(lines) >= 20 else lines
        text = ("=== Top250 Publication History (last 20 entries) ===\n\n" + "\n".join(last_lines))
        xbmcgui.Dialog().textviewer("Top250 Timestamp History", text)
    except Exception as e:
        logError("Context", "Failed to read log: %s" % str(e))
        xbmcgui.Dialog().ok(addonName, "Failed to read log file.")

def show_Library_health_report():
    try:
        Library_health_report_log_file = addonProfile + "/logs/_smartIMDb_libraryHealth.log"
        if not xbmcvfs.exists(Library_health_report_log_file):
            xbmcgui.Dialog().ok(addonName, "Library health report log file not found.")
            return
        with open(Library_health_report_log_file, "r", encoding="utf-8") as f:
            content = f.read()
        lines = content.splitlines()
        text = ("=== Library Health Report ===\n\n" + "\n".join(lines))
        xbmcgui.Dialog().textviewer("Library Health Report", text)
    except Exception as e:
        logError("Context", "Failed to read log: %s" % str(e))
        xbmcgui.Dialog().ok(addonName, "Failed to read log file.")







if __name__ == "__main__":
    UpdateMovieSet()